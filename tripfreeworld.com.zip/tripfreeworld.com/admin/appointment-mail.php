<?php 
include"include/config.php";
include"include/menu.php";

$select_about = "SELECT * FROM about";
$query_about = mysqli_query($conn,$select_about);
$row_about= mysqli_fetch_array($query_about);

error_reporting(0);
if(isset($_GET['id'])) {
  $get_id = mysqli_real_escape_string($conn,$_GET['id']);
  $query = "DELETE FROM `appointment` WHERE `id`= '$get_id'";
  $delte_query = mysqli_query($conn, $query);
  if ($delte_query) {
    echo "<script>window.location='appointment-mail.php'</script>";
  }
}

// DELETE THROUGH MULTIPLE CHECKBOX
if(isset($_POST['delete_row'])) {
  $checkarr = $_POST['checkbox'];
  foreach($checkarr as $value) {
    $select1 = "DELETE FROM `appointment` WHERE `id`='$value'";
    $query1 = mysqli_query($conn,$select1) or mysqli_error($conn);
    if($query1) {
      echo "<script>window.location='appointment-mail.php'</script>";
    }
  }
}
?>
<style>
  .modal .modal-body p {
    border-bottom: 1px solid #ddd;
    padding-bottom: 8px;
  }
</style>
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
			<div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> All Appointment Enquiry</div>
            <div class="card-body">
              <form method="post">
              <!-- <input type="submit" name="delete_row" class="btn btn-danger float-right" value="Delete Row"> -->
              <div class="table-responsive">
              <table id="" class="table table-bordered">
                <thead>
                    <tr>
                        <th>S. No.</th>
                        <th>Date</th>
                        <th>Name</th>
                        <th>Mobile No.</th>
                        <th>Full Msg.</th>
						<th>Action</th>
                    </tr>
                </thead>
                <tbody>
				
				 <?php 
		$number = 1;  
    $query = "SELECT * FROM `appointment` order by id desc";
    $Product_data = mysqli_query($conn, $query);

if(mysqli_num_rows($Product_data) > 0 ) {
    
    while ($row = mysqli_fetch_assoc($Product_data)) {
     
        $name=$row['name'];
		$phone=$row['phone'];
        $message=$row['message'];
		$id=$row['id'];
?>
<!-- The Modal -->
<div class="modal" id="myModal<?=$id;?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">View Enquiry</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="background: #fff;">
        
        <form method="post">

          <p><b>Date</b> : <?=$row['date'];?></p>
          <p><b>Name</b> : <?=$name;?></p>
          <p><b>Mobile No.</b> : <?=$phone;?></p>
          <p><b>Service</b> : <?=$row['service'];?></p>
          <p><b>Appointment Date</b> : <?=$row['appoint_date'];?></p>
          <p style="white-space: pre-line;"><b>Message</b> : <?=$message;?></p>
        </form>

      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
                    <tr>
                        <td><?=$number++;?>
                         <td><?=$row['date'];?></td>
                         <td><?=$name;?></td>
                         <td><?=$phone;?></td>
                         <td><a href="#myModal<?=$id;?>" data-toggle="modal" class="btn btn-primary">View</a></td>
                        <td>
						            <a href="#" onclick="deleteMe('appointment-mail.php',<?=$id;?>)"><i class="fa fa-trash-o"></i></a>
                        </td>
                      </tr>
                    <?php
              }
}
	
	?>   
                    
                </tbody>
                
            </table>
            </div>
          </form>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
			</div>


<?php 
    if(isset($_POST['admin_submit'])) {
        $price=mysqli_real_escape_string($conn,$_POST['price']);
        $admin_msg=mysqli_real_escape_string($conn,$_POST['admin_msg']);
        $hidden_id=mysqli_real_escape_string($conn,$_POST['hidden_id']);
         
        $to = $row['email'];
        $subject = "Price Estimate Quotation From ". $row_about['title'];
        $txt = "Hello ".$name."\r\n"."Your Estimate Price: ".$price ."\r\n"."Reply: ".$admin_msg;

        $headers = "From: ".$row_about['email'];
         $sql = mysqli_query($conn,"UPDATE enquires SET `price`='$price',`admin_msg`='$admin_msg' WHERE id='$hidden_id'");
         if($sql) {
            if(mail($to,$subject,$txt,$headers)) {
                echo "<script>
                        alert('Reply Submited');
                        window.location='';
                    </script>";
            } 
        }
         else {
            echo "Message could not be sent...";
         }
    }
?>
	
<?php include"include/footer.php"?>
		</div>