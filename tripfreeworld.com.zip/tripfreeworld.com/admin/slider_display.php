<?php 
include"include/config.php";
include"include/menu.php";
error_reporting(0);
if(isset($_GET['id'])) {
  $get_id = mysqli_real_escape_string($conn,$_GET['id']);
  $q="SELECT * FROM `banner` WHERE `id`='$get_id'";
  $r=mysqli_query($conn,$q);
  $col=mysqli_fetch_assoc($r);
    $fetch_img = $col['image'];    

  $query = "DELETE FROM `banner` WHERE `id`= '$get_id'";
  $delte_query = mysqli_query($conn, $query);
  if ($delte_query) {
    unlink("assets/images/slider/".$fetch_img);
    header('location:slider_display.php');
  }
}
?>
<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">

      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
              <a href="slider.php" class="btn btn-success" style="float:right;">Insert Banner</a>
              <i class="fa fa-table"></i> Sliders
            </div>
            <div class="card-body"> 
              <div class="table-responsive">
              <table id="" class="table table-bordered">
                <thead>
                    <tr>
                        <th>S No.</th>
                        <th>Image</th>
                        <th>Heading</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
        
         <?php 
    $i = 1;
    $db = $GLOBALS['conn'];
    $sql = "SELECT * FROM `banner` order by id desc";
    $query = mysqli_query($db, $sql) or die(mysqli_error($conn));
if(mysqli_num_rows($query) > 0 )
  {
    
    while ($row = mysqli_fetch_array($query))
    {   
      $id=$row['id'];
      $img=$row['image'];
      $head=$row['head'];
      $des=$row['des'];
?>
                    <tr>
            <td><?=$i++;?></td>
            <td><img src="assets/images/slider/<?php echo $img; ?>" width="100px" height="70px"></td>
            <td><?=$head?></td>
            <td><?=strip_tags(substr($des,0,30));?>...</td>
            <?php echo'
                        <td>   
                        <a href="slider.php?id='.$id.'"><i class="fa fa-pencil"></i></a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;                     
            <a href="#" onclick="delete_confirm('.$id.')"><i class="fa fa-trash-o"></a></td>
                    </tr>';
              }
}
  
  ?>   
                    
                </tbody>
            </table>
            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
      </div>
  
<?php include "include/footer.php" ?>

<script>
function delete_confirm(id) {
    if (confirm("Do You want a Delete!") == true) {
        window.location='slider_display.php?id='+id+''; // not sure which link should be placed here
        return true;
    } else {
        window.location="";
        return true;
    }
    document.getElementById("demo").innerHTML = x;
}
</script>

    </div>