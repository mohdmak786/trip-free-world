<?php 
include"include/config.php";
include"include/menu.php";
error_reporting(0);
if(isset($_GET['id'])) {
  $get_id = mysqli_real_escape_string($conn,$_GET['id']);
  $q="SELECT * FROM `destination` WHERE `id`='$get_id'";
  $r=mysqli_query($conn,$q);
  $col=mysqli_fetch_assoc($r);
    $fetch_img = $col['image'];    

  $query = "DELETE FROM `destination` WHERE `id`= '$get_id'";
  $delte_query = mysqli_query($conn, $query);
  if ($delte_query) {
    unlink("assets/images/destination/".$fetch_img);
    //header('location:blog_table.php');
    echo "<script>window.location='destination_table.php'</script>";
  }
}
?>
<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">


      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
                <a href="insert_destination.php" class="btn btn-success" style="float:right;">Add Destination</a>
              <i class="fa fa-table"></i> All Destination
            </div>
            <div class="card-body">
              <div class="table-responsive">
              <table id="" class="table table-bordered">
                <thead>
                    <tr>
                         <th>S.No.</th>
                         <th>Title</th>
                        <th>Image</th>
                        <th>Location</th>
                        <th>Time Period</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
        
         <?php 
      $number =1;
    $query = "SELECT * FROM `destination` order by id ASC";
    $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
        while ($row = mysqli_fetch_array($Product_data))
      {
        $id=$row['id'];
        $title=$row['title'];
        $img=$row['image'];
        $location=$row['location'];
        $time=$row['time'];
        $price=$row['price'];
?>
                    <tr>
                        <td><?=$number++;?></td>
                         <td ><?php echo $title; ?></td>
                        <td><img src="assets/images/destination/<?php echo $img;?>" style="height:50px;"></td>
                        <td><?=$location?></td>
                        <td><?=$time?></td>
                        <td><?=$price?></td>
            <?php echo'
                        <td><a href="insert_destination.php?id='.$id.'"><i class="fa fa-pencil"></i></a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
            <a href="#" onclick="delete_confirm('.$id.')"><i class="fa fa-trash-o"></i></a>
            </td>
                    </tr>';
              
}
  
  ?>   
                    
                </tbody>
            </table>
            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
      </div>
  
<?php include"include/footer.php"?>
    </div>
    <script>
function delete_confirm(id) {
if (confirm("Do You want a Delete!") == true) {
    window.location='destination_table.php?id='+id+''; // not sure which link should be placed here
    return true;
} else {
    window.location="";
    return true;
}
document.getElementById("demo").innerHTML = x;
}
</script>