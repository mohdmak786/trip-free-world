<!doctype html>
<html lang="en">
	
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<title>Contact Us - Trip Free World Tour & Travel</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-touch-fullscreen" content="yes">
		<meta name="HandheldFriendly" content="True">
		
		 <!--General Meta Start-->
    	<meta name="description" content="You Can Contact Us or Mail Us.If you have any questions call 9906830446, please do not hesitate to contact us."/>
        <meta name="keywords" content=" contact tour and travel,Contact tour and travel in srinagar,"/>
	    <meta name="author" content="Tour and Travels"/>
	    <meta name="robots" content="index, follow" />
	    <meta name="distribution" content="global" />
	    <meta name="coverage" content="india" />
	    <meta name="object" content="document"/>
	    <meta name="audience" content="All" />
	    <meta name="revisit-after" content="1 day"/>
	    <meta name="language" content="en"/>
	    <meta name="rating" content="general"/>
     	<meta name="copyright" content="Copyright Trip Free World 2023"/>
	<!--General Meta End-->
	
	    <!--OG Meta Start-->
	    <meta property="og:type" content="website" />
    	<meta property="og:title" content="Contact Us - Trip Free World" />
    	<meta property="og:url" content="https://www.tripfreeworld.com/contact-us" />
    	<meta property="og:description" content="Thank you for your interest in Trip Free World. If you have any questions call 9906830446, please do not hesitate to contact us." />
    	<meta property="og:image" content="https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp" />
    	<!--OG Meta end-->
		
		  <!--canonical tag-->
            <link rel="canonical" href="https://www.tripfreeworld.com/contact-us"/>
            <!--schema markup--->
     
            <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Trip Free World",
  "image": "https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp",
 
  "url": "https://www.tripfreeworld.com/",
  "telephone": "+91 9906830446",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Naidkhai, Amberhrah Sopore, Parraypora",
    "addressLocality": "Srinagar",
    "postalCode": "193501",
    "addressCountry": "IN"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 34.2867629,
    "longitude": 74.4624013
  },
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday"
    ],
    "opens": "00:00",
    "closes": "23:59"
  } 
}
</script>
		
        <?php include "include/header-file.php"?>
        
	</head>
	<body class="default">

        <?php include "include/header.php"?>

      <!-- Content  -->
       <style>
            .privacy{
                margin-top:90px;
            }
                @media only screen and (max-width: 600px) {
                    .privacy{
                               margin-top:50px;
                         }
                           }
                   
            </style>
      <section id="get-in-touch">
    <div class="container privacy">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h1>Get in Touch</h1>
          <h2>Fill out the form below to send us a message</h2>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <form id="contact-form" action="<?=$site_url?>form" method="post" role="form">
            <div class="form-group">
              <input type="text" name="name" class="form-control" placeholder="Your Name" required>
            </div>
            <div class="form-group">
              <input type="email" name="email" class="form-control" placeholder="Your Email" required>
            </div>
            <div class="form-group">
              <textarea name="message" class="form-control" placeholder="Your Message" rows="5" required></textarea>
            </div>
            <button type="submit" name="send_message" class="btn btn-primary btn-block">Send Message</button>
          </form>
        </div>
      </div>
    </div>
  </section>
      <!-- .Content  -->
      <section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="contact-info">
            <h3>Address</h3>
            <p><?=$About_rows['address']?></p>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="contact-info">
            <h3>Mobile Numbers</h3>
            <p>+91 <?=$About_rows['phone']?><br>
            <?php
                if($About_rows['phone2']) { echo '+91 '.$About_rows['phone2'].'</p>'; }
            ?>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="contact-info">
            <h3>E-mail ID</h3>
            <p><?=$About_rows['email']?><br></p>
            <p>info@tripfreeworld.com<br></p>
          </div>
        </div>
      </div>
    </div>
  </section>
  
    <iframe src="<?=$About_rows['map']?>" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title= "Location"></iframe>
  
			<?php include "include/footer.php"?>
    </body>
  
  
</html>