<?php include('admin/include/config.php');?>
<?php
    if(isset($_POST['inquiry'])) {
        $name=$_POST['username'];
        $email=$_POST['email'];
        $phone=$_POST['phone'];
        $notes=$_POST['notes'];
        
        $sql = "INSERT INTO `enquiry`(`name`, `phone`,`email`,`message`) VALUES ('$name','$phone','$email','$notes')";
        $query = mysqli_query($conn,$sql);
        		 
        $to = "tripfreeworld@gmail.com";
        $subject = "Enquiry From ". $About_rows['title'];
        $txt = "Name: ".$name."\r\n" ."Mobile No.: ".$phone ."\r\n"."Email: ".$email."\r\n"."Message: ".$notes ;
        
        $headers = "From: enquiry@tripfreeworld.com";
        if($sql) {
            if(mail($to,$subject,$txt,$headers)) {
                echo "<script>
                    alert('Mail has been Sent We will contact you soon');
                    window.location='$site_url';
                </script>";
            }
        }
        else {
            echo "<script>
                alert('Mail has not been Sent.');
                window.location='$site_url';
            </script>";
        }
    }
?>
<?php
    if(isset($_POST['send_message'])) {
        $name=$_POST['name'];
        $email=$_POST['email'];
        $msg=$_POST['message'];
        
        $sql = "INSERT INTO `enquiry`(`name`, `email`,`message`) VALUES ('$name','$email','$msg')";
        $query = mysqli_query($conn,$sql);
        		 
        $to = "enquiry@tripfreeworld.com";
        $subject = "Enquiry From ". $About_rows['title'];
        $txt = "Name: ".$name."\r\n" ."Email: ".$email."\r\n"."Message: ".$notes ;
        
        $headers = "From: enquiry@tripfreeworld.com";
        if($sql) {
            if(mail($to,$subject,$txt,$headers)) {
                echo "<script>
                    alert('Mail has been Sent We will contact you soon');
                    window.location='$site_url';
                </script>";
            }
        }
        else {
            echo "<script>
                alert('Mail has not been Sent.');
                window.location='$site_url';
            </script>";
        }
    }
?>
<?php
    if(isset($_POST['sub_package'])) {
        $name=$_POST['name'];
        $phone=$_POST['phone'];
        $email=$_POST['email'];
        $package=$_POST['package'];
        
        $to = "enquiry@tripfreeworld.com";
        $subject = "Email From ". $About_rows['title'];
        $txt = "Name: ".$name."\r\n" ."Mobile No.: ".$phone ."\r\n"."Email: ".$email."\r\n"."Package: ".$package ;
        
        $sql = "INSERT INTO `enquiry`(`name`, `phone`,`email`,`package`) VALUES ('$name','$mobile','$email','$package')";
        $query = mysqli_query($conn,$sql);
        		 
        $headers = "From: enquiry@tripfreeworld.com";
        if($sql) {
            if(mail($to,$subject,$txt,$headers)) {
                echo "<script>
                    alert('Mail has been Sent We will contact you soon');
                    window.location='$site_url';
                </script>";
            }
        }
        else {
            echo "<script>
                alert('Mail has not been Sent.');
                window.location='$site_url';
            </script>";
        }
    }
?>


<?php
    if(isset($_POST['book'])) {
        $name=$_POST['name'];
        $phone=$_POST['phone'];
        $email=$_POST['email'];
        $car=$_POST['car'];
        $pickup=$_POST['pickup'];
        $dropoff=$_POST['dropoff'];
        $date=$_POST['date'];
        $time=$_POST['time'];
        
        $to = "enquiry@tripfreeworld.com";
        $subject = "Email From ". $About_rows['title'];
        $txt = "Name: ".$name."\r\n" ."Mobile No.: ".$phone ."\r\n"."Email: ".$email."\r\n"."Selected Car: ".$car ."\r\n" ."Pick-up Location: ".$pickup ."\r\n"."Drop-off: ".$dropoff."\r\n"."Date: ".$date."\r\n"."time: ".$time ;
        
        $sql = "INSERT INTO `enquiry`(`name`, `phone`,`email`,`car`,`pickup`,`dropoff`,`date`,`time`) VALUES ('$name','$phone','$email','$car','$pickup','$dropoff','$date','$time')";
        $query = mysqli_query($conn,$sql);
        		 
        $headers = "From: enquiry@tripfreeworld.com";
        if($sql) {
            if(mail($to,$subject,$txt,$headers)) {
                echo "<script>
                    alert('Mail has been Sent We will contact you soon');
                    window.location='$site_url';
                </script>";
            }
        }
        else {
            echo "<script>
                alert('Mail has not been Sent.');
                window.location='$site_url';
            </script>";
        }
    }
?>