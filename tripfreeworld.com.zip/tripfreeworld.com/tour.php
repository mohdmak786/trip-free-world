<!doctype html>
<html lang="en">
	
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<title>Kashmir Tour Packages - Trip Free World Tour & Travel</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-touch-fullscreen" content="yes">
		<meta name="HandheldFriendly" content="True">
		
		 <!--General Meta Start-->
    	<meta name="description" content="Popular kashmir tour Packages; Rs 30,200 6 Night 7 days in Kashmir; Vaishno Devi- 40,800, 8Night 9Days; Tulip- 4Night 5Days 18,500 etc."/>
        <meta name="keywords" content="Tour packages of srinagar,Trip free world tour packages,Tour packages jammu & kashmir  "/>
	    <meta name="author" content="Tour and Travels"/>
	    <meta name="robots" content="index, follow" />
	    <meta name="distribution" content="global" />
	    <meta name="coverage" content="india" />
	    <meta name="object" content="document"/>
	    <meta name="audience" content="All" />
	    <meta name="revisit-after" content="1 day"/>
	    <meta name="language" content="en"/>
	    <meta name="rating" content="general"/>
     	<meta name="copyright" content="Copyright Trip Free World 2023"/>
    	<!--General Meta End-->
    	
    	<!--OG Meta Start-->
    	<meta property="og:type" content="website" />
    	<meta property="og:title" content="Tour Packages - Trip Free World Tour & Travel" />
    	<meta property="og:url" content="https://www.tripfreeworld.com/tour" />
    	<meta property="og:description" content="Popular kashmir tour Packages; Rs 30,200 6Night 7days in Kashmir; Vaishno Devi- 40,800, 8Night 9Days; Tulip- 4Night 5Days 18,500 etc." />
    	<meta property="og:image" content="https://tripfreeworld.com/admin/assets/images/tour/1.jpg" />
    	<!--OG Meta end-->
    	
		
			  <!--canonical tag-->
             <link rel="canonical" href="https://www.tripfreeworld.com/tour"/>
             
             <!---schema markup--->
             <script type="application/ld+json">
{
  "@context": "https://schema.org/", 
  "@type": "BreadcrumbList", 
  "itemListElement": [{
    "@type": "ListItem", 
    "position": 1, 
    "name": "Home",
    "item": "https://www.tripfreeworld.com"  
  },{
    "@type": "ListItem", 
    "position": 2, 
    "name": "Tour Packages",
    "item": "https://www.tripfreeworld.com/tour"  
  }]
}
</script>
             
		
        <?php include "include/header-file.php"?>
        
	</head>
	<body class="default">

        <?php include "include/header.php"?>

      <!-- Content  -->
      <div id="content">
        <div class="content-wrap page-destination-list">
          <div class="subsite-banner">
            <img src="img/subsite-banner-3.jpg" alt="image">
          </div>
          <div class="container subsite subsite-with-banner">
            <div class="row">
              <div class="col-md-12">
                <div class="subsite-heading">
                  <h1 style="font-size:20px;font-weight:600;">Best Kashmir Tour Packages</h1>
                 </div>
                   <p style="text-align:justify;">
Kashmir is located in the northern India also known as the "Paradise On Earth" and it is famous for its breathtaking natural beauty, rich cultural heritage and warm hospitality. This is the place which attracts travellers from all over the world.  The natural beauty, Dal lake and decorated houseboats, adventures, rich cultural heritage, and monasteries you will going to explore in 7 days kashmir tour packages at Trip Free World.
We ensure that you will defintely enjoy our services and it will be memorable to you. We have a diverse tour package of Kashmir according to your interest and preferrence. We include in our Kashmir Tour Packages:-</p>
           <div style="text-align:justify;">
             <p><b>Natural Beauty Of Kashmir:-</b> Kashmir is famous for its natural beauty with stunning landscapes, snow-cappde Himalayan Peaks, Lakes, lush green valleys, and meadows filled with colorful flowers. And Trip Free World is here to feels you the natural beauty of kashmir. 
            </p> 
            <p><b>Dal Lake and Houseboats:-</b> You can enjoy the Dal lake and Houseboats in Srinagar, where tourist can experience a memorable stay in decorated houseboats. These houseboats offer a chance to live on the water, enjoy beautiful views, and savor delicious Kashmiri cuisine prepared by skilled chefs.</p>
            <p><b>Adventures and Fun Activities:-</b> The trip-free world offers numerous adventure activities for thrill-seekers. You can experience trekking in the region of mountains and valleys with routes like the Great Lakes trek and the Amarnath yatra pilgrimage adventurers from far and wide.</p>
            <p><b>Cultural Heritage of Kashmir:-</b> As we all know Kashmir is known for its diverse cultural heritage influenced by Hindu, Buddhist, and Islamic traditions. You can explore historic sites like Shankaracharya Temple, Jamia Masjid, and various Sufi shrines. The region is also famous for its handicrafts, including exquisite Pashmina shawls, and traditional Kashmiri carpets. You can explore the streets of Kashmir as well. </p>
            <p><b>Delicious Cuisine:-</b> Kashmiri cuisine is known for its aromatic and flavorful dishes, often infused with spices like saffron and dry fruits. When visiting Kashmir your Must-try dishes include Rogan Josh, Dum Aloo, Yakhni, and the famous Wazwan feast, which features a grand spread of traditional delicacies.</p>
            <p><b>Monasteries of Kashmir:-</b> In the Ladakh region of Kashmir, you can explore ancient Buddhist monasteries like Hemis, Thiksey, and Diskit. These monasteries not only offer spiritual experiences but also provide insight into the unique Ladakhi culture. We include your complete trip in our Kashmir tour package. You will expolre each tradition and custom of kashmir. </p>   
            <p><b>Kashmir Pilgrim Tour Package:-</b> We also offer a complete pilgrime tour package For pilgrims, Kashmir is significant due to its many temples and shrines. The Amarnath Cave Temple, Vaishno Devi Temple, and Charar-e-Sharif are prominent pilgrimage destinations.</p>  
               </div>
               </div>
            </div>
            
            
					<!-- section 3 -->
					<div class="container heading-section">
						<div class="sa-title popcat"> <h2 style="font-size:18px;font-weight:600;"> Popular Tour Packages</h2>  
						</div>
						<div class="heading-info">
							Memorable romantic vacation
						</div>
						<div class="clear"></div>
					</div>
					<div class="container section-home home-news">
						
						<div class="home-news-wrap">
						    
						    <?php
                            $query = "SELECT * FROM `tour` order by id ASC";
                                $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                while ($row = mysqli_fetch_array($Product_data))
                                {
                                    $id=$row['id'];
                                    $url=$row['url'];
                                    $title=$row['title'];
                                    $img=$row['image'];
                                    $desc=$row['des'];
                                    $location=$row['location'];
                                    $price=$row['price'];
                                    $time=$row['time'];
                                    $link=$row['link'];
                            ?>
							<a href="<?=$link?>">
								<div class="news-item">
									<div class="news-content">
										<div class="hnw-img">
											<img src="<?=$site_url?>admin/assets/images/tour/<?=$img?>" alt="<?=$title?>">
										</div>
										<div class="hnw-desc">
											<div class="hnw-title"><h3 style="font-size:14px;font-weight:700;"><?=$title?></h3></div>
											<div class="hnw-text">
												<?=$desc?><a href="<?=$link?>" class="more">Book Now</a>
											</div>
										</div>
									</div>
								</div>
							</a>
							<?php } ?>
						</div>
					</div>
					<!-- .section 3 -->
            
            
          </div>
          
        </div>
      </div>
      <!-- .Content  -->
      
			<?php include "include/footer.php"?>
    </body>
  
  
</html>