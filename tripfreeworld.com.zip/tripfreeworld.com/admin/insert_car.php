<?php 
include"include/config.php";
include"include/menu.php";

error_reporting(0);

if(isset($_GET['id'])) {
  $get_id = mysqli_real_escape_string($conn,$_GET['id']);
  $q="SELECT * FROM `car` WHERE id='$get_id'";
  $r=mysqli_query($conn,$q);
  $col=mysqli_fetch_array($r);
    $title = $col['title'];
    $old_img = $col['image'];
    $type = $col['type'];
    $seat = $col['seat'];
    $bags = $col['bags'];
    $price = $col['price'];
?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
		<div class="row">
		<div class="col-lg-12">
		<div class="card">
			   <div class="card-body">
			   <div class="card-header">Update Service</div>
			   <hr>
			<form action="" method="POST" enctype="multipart/form-data">
			    <div class="form-group row">
				<label for="input-26" class="col-sm-2 col-form-label">Title</label>
				<div class="col-sm-10">
				 	<input type="text" name="title" class="form-control" value="<?=$title;?>" id="title">
				</div>
			  </div>
			  
			<div class="form-group row">
              <label for="input-8" class="col-sm-2 col-form-label">Image</label>
              <div class="col-sm-4">
                <input type="file" class="form-control" name="image">
               </div>
              <div class="col-sm-4">
                <img src="assets/images/car/<?=$old_img;?>" style="height:50px;">
              </div>
            </div>

            <div class="form-group row">
				<label for="input-26" class="col-sm-2 col-form-label">Type</label>
				<div class="col-sm-10">
				 	<input type="text" name="type" class="form-control" value="<?=$type;?>" id="title">
				</div>
			  </div>

            <div class="form-group row">
				<label for="input-26" class="col-sm-2 col-form-label">Seats</label>
				<div class="col-sm-10">
				 	<input type="text" name="seat" class="form-control" value="<?=$seat;?>" id="title">
				</div>
			  </div>

            <div class="form-group row">
				<label for="input-26" class="col-sm-2 col-form-label">Bags</label>
				<div class="col-sm-10">
				 	<input type="text" name="bags" class="form-control" value="<?=$bags;?>" id="title">
				</div>
			  </div>

            <div class="form-group row">
				<label for="input-26" class="col-sm-2 col-form-label">Price</label>
				<div class="col-sm-10">
				 	<input type="text" name="price" class="form-control" value="<?=$price;?>" id="title">
				</div>
			  </div>
			  
			   <div class="form-group row">
				<label class="col-sm-2 col-form-label"></label>
				<div class="col-sm-10">
				<button name="services_update" type="submit" class="btn btn-dark btn-round px-5"><i class="icon-lock"></i>Submit</button>
				</div>
			  </div>
			   </form>
			 </div>
			</div>
		</div>
		</div>
	</div>
</div>

<?php 


if(isset($_POST['services_update']))
{
    $title=mysqli_real_escape_string($conn,$_POST['title']);
    $type=mysqli_real_escape_string($conn,$_POST['type']);
    $seat=mysqli_real_escape_string($conn,$_POST['seat']);
    $bags=mysqli_real_escape_string($conn,$_POST['bags']);
    $price=mysqli_real_escape_string($conn,$_POST['price']);
	 
	$image_name = $_FILES['image']['name'];
	$final_img = time().$image_name;
	$image_tmp = $_FILES['image']['tmp_name'];
	$logo_path = "assets/images/car/".$final_img;
	$old_img = $col['image'];
    $extensions_arr = array("jpg","jpeg","png","gif","webp");
    $file_extension = pathinfo($image_name, PATHINFO_EXTENSION);
  
  if($image_name) {
    if(in_array($file_extension,$extensions_arr)) {
      unlink('assets/images/car/'.$old_img);
      move_uploaded_file($image_tmp, $logo_path);
    }
    else {
      echo "<script>
          alert('Image Should be Valid Extension');
          window.location='insert_car.php?id=".$get_id."';
        </script>";
      exit;
    } 
  }
  else {
    $final_img=$old_img;
  }


  $sql="UPDATE `car` SET `title`='$title',`image`='$final_img',`type`='$type',`seat`='$seat',`bags`='$bags',`price`='$price' WHERE id='$get_id'";
  $query=mysqli_query($conn,$sql) or die(mysqli_error($conn));  
  if($query)
  {
	move_uploaded_file($image_tmp,$logo_path);
	echo "<script>alert('update succesfully');window.location='car_table.php';</script>";
  }
}

}  // IF ISSET END
else {

?>	
  <div class="content-wrapper">
    <div class="container-fluid">

			<div class="row">
			<div class="col-lg-12">
			<div class="card">
				   <div class="card-header">
				   		<a href="car_table.php" class="btn btn-success" style="float:right;">All Cars</a>
				   		Add Car
				   </div>
				   <div class="card-body">
				   <hr>
				<form action="" method="POST" enctype="multipart/form-data">
				    <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Title</label>
					<div class="col-sm-10">
					 	<input type="text" name="title" class="form-control" id="title" placeholder="Car Name">
					</div>
				  </div>
				  
				<div class="form-group row">
                  <label for="input-8" class="col-sm-2 col-form-label">Image (<abbr title="Image Format Should be jpg,jpeg,png,gif">Format</abbr>)</label>
                  <div class="col-sm-4">
                    <input type="file" class="form-control" name="image" required>
                  </div>
                </div>
                
                <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Type</label>
					<div class="col-sm-10">
					 	<input type="text" name="type" class="form-control" id="title" placeholder="Car type like Sedan, SUV, Compact etc">
					</div>
				  </div>
                
                <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Seat</label>
					<div class="col-sm-10">
					 	<input type="text" name="seat" class="form-control" id="title" placeholder="Number of Seats">
					</div>
				  </div>

                <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Bags</label>
					<div class="col-sm-10">
					 	<input type="text" name="bags" class="form-control" id="title" placeholder="Number of Bags">
					</div>
				  </div>

                <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Price</label>
					<div class="col-sm-10">
					 	<input type="text" name="price" class="form-control" id="title" placeholder="Enter Price">
					</div>
				  </div>
				 
				<div class="form-group row">
					<label class="col-sm-2 col-form-label"></label>
					<div class="col-sm-10">
					<button name="services_submit" type="submit" class="btn btn-dark btn-round px-5"><i class="icon-lock"></i>Submit</button>
					</div>
				</div>
				   </form>
				 </div>
				</div>
			</div>
			</div>
			<?php

if(isset($_POST['services_submit']))
{
    $title=mysqli_real_escape_string($conn,$_POST['title']);
    $type=mysqli_real_escape_string($conn,$_POST['type']);
    $seat=mysqli_real_escape_string($conn,$_POST['seat']);
    $bags=mysqli_real_escape_string($conn,$_POST['bags']);
    $price=mysqli_real_escape_string($conn,$_POST['price']);
	 
	$image_name = $_FILES['image']['name'];
	$final_img = time().$image_name;
	$image_tmp = $_FILES['image']['tmp_name'];
	$logo_path = "assets/images/car/".$final_img;

	$extensions_arr = array("jpg","jpeg","png","gif","webp");
	$file_extension = pathinfo($image_name, PATHINFO_EXTENSION);	

	if(in_array($file_extension,$extensions_arr)) {
		if ($image_name!="") {
			$sql="INSERT INTO `car`(`title`,`image`,`type`,`seat`,`bags`,`price`) VALUES ('$title','$final_img','$type','$seat','$bags','$price')";
			$query=mysqli_query($conn,$sql) or die(mysqli_error($conn));
			if($query)
			{
				move_uploaded_file($image_tmp,$logo_path);
				 echo("<script>alert('Insert succesfully');window.location='car_table.php';</script>");
			}
		}
  	}
	else {
	   echo("<script>alert('Image Should be Valid Extension');</script>");
	}		
}

}  // ELSE CONDITION END

?>		
<?php include"include/footer.php"?>
		</div>
		
 
		
	