<!doctype html>
<html lang="en">
	
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<title>Trip Free World Tour & Travels</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-touch-fullscreen" content="yes">
		<meta name="HandheldFriendly" content="True">
       
			<meta name="description" content="Jammu and Kashmir are some of the top honeymoon destinations in Kashmir. The valleys here are beautiful with lakes and colorful."/>
        <meta name="keywords" content="Tour Details, "/>
	    <meta name="author" content="Tour and Travels"/>
	    <meta name="robots" content="index, follow" />
	    <meta name="distribution" content="global" />
	    <meta name="coverage" content="india" />
	    <meta name="object" content="document"/>
	    <meta name="audience" content="All" />
	    <meta name="revisit-after" content="1 day"/>
	    <meta name="language" content="en"/>
	    <meta name="rating" content="general"/>
     	<meta name="copyright" content="Copyright Trip Free World 2023"/>
	
		
        <?php include "include/header-file.php"?>
        <style>
            .icon{
                font-size: 30px;
                font-weight: 900;
                margin-right: 1rem;
            }
            .single-nav{
                background-color: #2450a6;
                color: #fff;
                border-radius: 10px;
                padding: 10px;
                font-size: 18px;
            }
            .form-head{
                background-color: #2450a6;
                color: #fff;
                margin-bottom: -5px;
                border-radius: 15px 15px 0 0;
                font-weight: 600;
            }
            .card-header{
                background: #df9403;
                color: #fff;
            }
            .card-header .btn-link{
                color: #fff;
                font-size: 18px;
                font-weight: 700;
                text-decoration: none;
                text-align: left;
            }
            .card-header .heading{
                font-size: 25px;
                font-weight: 800;
                color: #2450a6;
            }
            ul.breadcrm{}
            ul.breadcrm li a, ul.breadcrm li a:hover{
                text-decoration: none;
                color: #2450a6;
            }
        </style>
	</head>
	<body class="default">

        <?php include "include/header.php"?>


    <section class="bread1">      
      <div class="container-fluid m-0 p-0">
          <div class="row">
              <div class="col-12">
                    <ul class="breadcrumb breadcrm">
                  <li><a href="#">Home</a></li>
                  <li><a href="#">Tour Package</a></li
                <li>*</li>
                </ul>
                <img src="img/news2.jpg" alt="image" class="w-100" style="width:100%; height:450px; margin-top:-20px;">
              </div>
          
      </div>
      </section>
      <!-- .Content  -->
  
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12 order-md-1 order-2">
                <div class="row">
                    <div class="col-md-9 col-sm-12 ">
                        <h1 class="st-heading">Trip Free World with Vaishno Devi &#8211; Summer</h1>
                    </div>
                    <div class="col-md-3 col-sm-12 mt-3">
                        <span class="head-rating">Excellent</span>
                        <div class="st-stars style-2" style="color: #df9403;">
                            <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>
                        </div>
                        <p class="st-link">from 5 reviews</p>
                    </div>
                </div>
                <div class="row single-nav">
                    <div class="col-6 col-sm-3">
                        <div class="item d-flex align-items-center">
                            <div class="icon">
                                <i class="far fa-clock"></i>
                            </div>
                            <div class="info">
                                <div class="name">Duration</div>
                                <p class="value">
                                    8 Nights 9 Days </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-3">
                        <div class="item d-flex align-items-center">
                            <div class="icon">
                                <i class="fas fa-shoe-prints"></i>
                            </div>
                            <div class="info">
                                <div class="name">Tour Type</div>
                                <p class="value">
                                    Specific Tour </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-3">
                        <div class="item d-flex align-items-center">
                            <div class="icon">
                                <i class="fas fa-user-friends"></i>
                            </div>
                            <div class="info">
                                <div class="name">Group Size</div>
                                <p class="value">
                                    25 people </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-3">
                        <div class="item d-flex align-items-center">
                            <div class="icon">
                                <i class="fas fa-language"></i>
                            </div>
                            <div class="info">
                                <div class="name">Languages</div>
                                <p class="value">
                                    ___ </p>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Tour Overview-->
                <div class="">
                    <h3 class="mt-3">Highlights</h3>
                    <p class="mt-2" style="font-size:13px; color:#5E6D77;"> Lorem ipsum dolor sit amet, consectetur
                        adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                        minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        <br><br>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat
                        nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                        deserunt mollit anim id est laborum.</p>

                </div>
                <div class="accordion" id="accordionExample">
                    <div class="card">
                        <div class="card-header" id="headingOne">
                            <h2 class="mb-0">
                                <h3 class="heading float-left">Heading1</h3>
                                <button class="btn btn-link float-right" type="button" data-toggle="collapse"
                                    data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    <i class="fa fa-arrow-down" aria-hidden="true"></i>
                                </button>
                            </h2>
                        </div>

                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                            data-parent="#accordionExample">
                            <div class="card-body" style="font-size: 13px">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad
                                squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck
                                quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it
                                squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica,
                                craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur
                                butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth
                                nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingTwo">
                            <h2 class="mb-0">
                                <h3 class="heading float-left">Heading2</h3>
                                <button class="btn btn-link collapsed float-right" type="button" data-toggle="collapse"
                                    data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    <i class="fa fa-arrow-down" aria-hidden="true"></i>
                                </button>
                            </h2>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                            data-parent="#accordionExample">
                            <div class="card-body" style="font-size: 13px">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad
                                squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck
                                quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it
                                squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica,
                                craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur
                                butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth
                                nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingThree">
                            <h2 class="mb-0">
                                <h3 class="heading float-left">Heading3</h3>
                                <button class="btn btn-link collapsed float-right" type="button" data-toggle="collapse"
                                    data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    <i class="fa fa-arrow-down" aria-hidden="true"></i>
                                </button>
                            </h2>
                        </div>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                            data-parent="#accordionExample">
                            <div class="card-body" style="font-size: 13px">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad
                                squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck
                                quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it
                                squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica,
                                craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur
                                butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth
                                nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                            </div>
                        </div>
                    </div>
                </div>
                 
                <div class="row mt-5">
                   
                    <div class="col-md-6 col-sm-12 include1" style="">
                        <h2 class="text-center mb-3">Included</h2>
                         <ul style="padding-inline-start: 0">
                                <li><i class="fa fa-check" style="font-size:16px;color:green"></i>&nbsp;Spiritual pilgrimage to Vaishno Devi
                                </li>
                                <li><i class="fa fa-check" style="font-size:16px;color:green"></i>&nbsp;Beautiful Mughal Gardens
                                </li>
                                <li><i class="fa fa-check" style="font-size:16px;color:green"></i>&nbsp;Enchanting Dal Lake
                                </li>
                                <li><i class="fa fa-check" style="font-size:16px;color:green"></i>&nbsp;Alpine beauty of Gulmarg and Pahalgam
                                </li>
                                <li><i class="fa fa-check" style="font-size:16px;color:green"></i>&nbsp;Comfortable and hassle-free journey</li>
                            </ul>
                    </div>
                    <div class="col-md-6 col-sm-12 include1" style="padding:30px;font-size:18px;">
                        <h2 class="text-center mb-3">Excluded</h2>
                          <ul style="padding-inline-start: 0">
                                <li><i class="fa fa-times" style="font-size:16px;color:red"></i>&nbsp; Spiritual pilgrimage to Vaishno Devi
                                </li>
                                <li><i class="fa fa-times" style="font-size:16px;color:red"></i>&nbsp; Beautiful Mughal Gardens
                                </li>
                                <li><i class="fa fa-times" style="font-size:16px;color:red"></i>&nbsp; Enchanting Dal Lake
                                </li>
                                <li><i class="fa fa-times" style="font-size:16px;color:red"></i>&nbsp; Alpine beauty of Gulmarg and Pahalgam
                                </li>
                                <li><i class="fa fa-times" style="font-size:16px;color:red"></i>&nbsp; Comfortable and hassle-free journey</li>
                            </ul>
                    </div>
                    
                </div>
            </div>
            <div class="col-md-3 col-sm-12 order-md-2 order-1">
                <div class="wrapper">

                    <form class="" style="margin-top:-50px;">
                        
                        <h6 class="p-3 form-head">Get In Touch <span style="font-size:20px;"> ₹0</span></h6>
                                <div class="form-signin">
                        <h3 class="form-signin-heading">INQUIRY</h3>
                        <input type="text" class="form-control inpo" name="username" placeholder="Name" required=""
                            autofocus="" />
                        <input type="email" class="form-control mb-1" name="emsil" placeholder="Email Address" required=""
                            autofocus="" />
                        <input type="text" class="form-control" name="phone" placeholder="Phone..." required="" />
                        <textarea type="text" name="notes" class="form-control" rows="3" cols="40"
                            placeholder="Notes..."></textarea>

                        <button class="btn btn-lg btn-primary btn-block mt-2" type="submit">Sand</button>
                        </div>
                    </form>
                </div>

                <div style="padding:20px; margin-bottom:10px; border: 1px solid rgba(0,0,0,0.1);">
                    <h3>Tour Package</h3>
                    <div class="d-flex justify-content-center align-items-center">
                        <img alt='Go Any Where'
                            src='https://secure.gravatar.com/avatar/0c848be03946339218b06ce8731ca6af?s=60&#038;d=robohash&#038;r=g'
                            srcset='https://secure.gravatar.com/avatar/0c848be03946339218b06ce8731ca6af?s=120&#038;d=robohash&#038;r=g 2x'
                            class='avatar avatar-60 photo' height='60' width='60' loading='lazy' decoding='async' />
                        <p>Member Since 2023</p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>           
                        
      
      <!--End Tour info-->
      
      
      
      
      
      
      
            
      <div class="container pb-5">
        <div class="content-wrap page-news">
          
          <div class="subsite">
					<!-- section 3 -->
					<div class="heading-section">
						<div class="sa-title popcat">Popular destinations
						</div>
						<div class="heading-info">
							Memorable romantic vacation
						</div>
						<div class="clear"></div>
					</div>
					<div class="section-home vacation-destination">
						<div class="default-carousel vs-carousel">
							
							<?php 
                                $query = "SELECT * FROM `gallery`";
                                $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                while ($row = mysqli_fetch_array($Product_data))
                                {
                                    $id=$row['id'];
                                    $title=$row['title'];
                                    $img=$row['image'];
                            ?>
							<!-- item -->
							<div class="item">
								<div class="vs-box">
									<div class="vsb-top">
										<div class="vsbt-img">
											<img src="<?=$site_url?>admin/assets/images/gallery/<?=$img?>" alt="<?=$title?>">
										</div>
									</div>
								</div>
							</div>
							<!-- .item -->
							<?php } ?>
						</div>
					</div>
					<!-- .section 3 -->
					
					<!-- section 3 -->
					<div class="heading-section">
						<div class="sa-title popcat">Location
						</div>
						<div class="heading-info">
							Tour Location
						</div>
						<div class="clear"></div>
					</div>
					<div class="section-home vacation-destination">
						<div class="map">
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1695378.5370929837!2d72.67145646094822!3d33.908032767542025!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38e1092499ffa89d%3A0x6567a6d4697e7f1!2sJammu%20and%20Kashmir!5e0!3m2!1sen!2sin!4v1679470470925!5m2!1sen!2sin"></iframe>
						</div>
					</div>
					<!-- .section 3 -->
					
					
            
          </div>
          
        </div>
      </div>
      <!-- .Content  -->
      
      	<!-- section 3 -->
					<div class="container heading-section">
						<div class="sa-title popcat text-center">Testimonials
						</div>
						<div class="heading-info text-center">
							What clients say about us
						</div>
						<div class="clear"></div>
					</div>
					<div class="container reviews-container vacation-destination mt-4" style="overflow: hidden;">
						<div class="default-carousel vs-carousel">
							
							<?php
                                $query = "SELECT * FROM `review` order by id ASC";
                                $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                while ($row = mysqli_fetch_array($Product_data))
                                {
                                    $id=$row['id'];
                                    $title=$row['title'];
                                    $desc=$row['des'];
                                    $location=$row['location'];
                                    $time=$row['time'];
                                    $price=$row['price'];
                            ?>
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img src="img/testimonial.png" alt="<?=$title?>" />
                                    </div>
                                    <div class="review-details">
                                        <h3 class="review-title"><?=$title?></h3>
                                        <p class="review-description"><?=$desc?></p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<?php } ?>
						</div>
					</div>
					<!-- .section 3 -->
					
					<!-- FAQs Section Start -->
					<div class="container heading-section pt-5">
						<div class="sa-title popcat text-center">Frequently Ask Questions
						</div>
						<div class="heading-info text-center">
							Some frequently ask questions for you
						</div>
						<div class="clear"></div>
					</div>
					<div class="container">
					    
					    <div class="row">
					        <div class="col-lg-12 py-5">
					            
                <div class="accordion" id="faqs">
                    <div class="card">
                        <div class="card-header" id="heading1">
                            <h2 class="mb-0">
                                <h3 class="heading float-left">Heading1</h3>
                                <button class="btn btn-link float-right" type="button" data-toggle="collapse"
                                    data-target="#faq1" aria-expanded="true" aria-controls="faq1">
                                    <i class="fa fa-arrow-down" aria-hidden="true"></i>
                                </button>
                            </h2>
                        </div>

                        <div id="faq1" class="collapse show" aria-labelledby="heading1"
                            data-parent="#faqs">
                            <div class="card-body" style="font-size: 13px">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad
                                squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck
                                quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it
                                squid single-origin coffee nulla assumenda shoreditch et.
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="heading2">
                            <h2 class="mb-0">
                                <h3 class="heading float-left">Heading2</h3>
                                <button class="btn btn-link collapsed float-right" type="button" data-toggle="collapse"
                                    data-target="#faq2" aria-expanded="false" aria-controls="faq2">
                                    <i class="fa fa-arrow-down" aria-hidden="true"></i>
                                </button>
                            </h2>
                        </div>
                        <div id="faq2" class="collapse" aria-labelledby="heading2"
                            data-parent="#faqs">
                            <div class="card-body" style="font-size: 13px">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad
                                squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck
                                quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it
                                squid single-origin coffee nulla assumenda shoreditch et.
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="heading3">
                            <h2 class="mb-0">
                                <h4 class="heading float-left">Heading3</h4>
                                <button class="btn btn-link collapsed float-right" type="button" data-toggle="collapse"
                                    data-target="#faq3" aria-expanded="false" aria-controls="faq3">
                                    <i class="fa fa-arrow-down" aria-hidden="true"></i>
                                </button>
                            </h2>
                        </div>
                        <div id="faq3" class="collapse" aria-labelledby="heading3"
                            data-parent="#faqs">
                            <div class="card-body" style="font-size: 13px">
                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad
                                squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck
                                quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it
                                squid single-origin coffee nulla assumenda shoreditch et.
                            </div>
                        </div>
                    </div>
                </div>
					        </div>
					    </div>
					</div>
					<!-- FAQs Section End -->
			<?php include "include/footer.php"?>
			
		</body>
	
</html>