<?php include "../admin/include/config.php" ?>
<!doctype html>
<html lang="en">
	
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<title>Kashmir Tulip Tour Package - Trip Free World</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-touch-fullscreen" content="yes">
		<meta name="HandheldFriendly" content="True">
		
		<!--General Meta Start-->
    	<meta name="description" content="The Kashmir Tulip Package is the perfect opportunity for nature lovers to witness the stunning beauty of the blooming tulips.Contact Us Now.">
        <meta name="keywords" content="4 Nights 5 Days kashmir,kashmir tulip package"/>
    	<meta name="author" content="Travel Agency"/>
    	<meta name="robots" content="index, follow" />
    	<meta name="distribution" content="global" />
    	<meta name="coverage" content="india" />
    	<meta name="object" content="document"/>
    	<meta name="audience" content="All" />
    	<meta name="revisit-after" content="1 day"/>
    	<meta name="language" content="en"/>
    	<meta name="rating" content="general"/>
    	<meta name="copyright" content="Copyright Trip Free World 2023"/>
    	<!--General Meta end-->
    	
    	<!--OG Meta Start-->
    	<meta property="og:type" content="website" />
    	<meta property="og:title" content="Kashmir Tulip Tour Package - Trip Free World" />
    	<meta property="og:url" content="https://www.tripfreeworld.com/tour-package/kashmir-tulip-package" />
    	<meta property="og:description" content="The Kashmir Tulip Package is the perfect opportunity for nature lovers to witness the stunning beauty of the blooming tulips in the picturesque Kashmir valley." />
    	<meta property="og:image" content="https://www.tripfreeworld.com/admin/assets/images/tour/4.webp" />
    	<!--OG Meta end-->
		
		
		<!--canonical tag-->
             <link rel="canonical" href="https://www.tripfreeworld.com/tour-package/kashmir-tulip-package"/>
		<!--- Breadcrumb schema strat--->
		<script type="application/ld+json">
{
  "@context": "https://schema.org/", 
  "@type": "BreadcrumbList", 
  "itemListElement": [{
    "@type": "ListItem", 
    "position": 1, 
    "name": "Home",
    "item": "https://www.tripfreeworld.com/"  
  },{
    "@type": "ListItem", 
    "position": 2, 
    "name": "Tour Packages",
    "item": "https://www.tripfreeworld.com/tour"  
  },{
    "@type": "ListItem", 
    "position": 3, 
    "name": "kashmir-Tulip-Package",
    "item": "https://www.tripfreeworld.com/tour-package/kashmir-tulip-package"  
  }]
}
</script>
	<!--- Breadcrumb schema end--->	
	
	<!--Reviews Schema Start-->
    		<script type="application/ld+json">
    	{
    	  "@context": "https://schema.org/", 
    	  "@type": "Product", 
    	  "name": "Trip Free World",
    	  "image": "https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp",
    	  "description": "Best Travel Agency in kashmir",
    	  "brand": {
    		"@type": "Brand",
    		"name": "Trip Free World"
    	  },
    	  "aggregateRating": {
    		"@type": "AggregateRating",
    		"ratingValue": "5",
    		"bestRating": "5",
    		"worstRating": "1",
    		"ratingCount": "4.9",
    		"reviewCount": "21"
    	  },
    	  "review": [{
    		"@type": "Review",
    		"name": "Ramesh Kumar",
    		"reviewBody": "I recently booked a trip to Kashmir with Trip Free World Tour and Travels, and I have to say it was one of the most memorable experiences of my life. The entire trip was well-organized, and the guides were knowledgeable and friendly.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Ramesh Kumar"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Anjali Sharma",
    		"reviewBody": "I highly recommend Trip Free World Tour and Travels for anyone planning a trip to Kashmir. They offer a wide range of packages to suit all budgets, and the customer service is top-notch. I can't wait to book my next trip with them.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Anjali Sharma"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Amit Patel",
    		"reviewBody": "I had a fantastic time exploring Kashmir with Trip Free World. Their package was not only affordable but also packed with incredible experiences. From the houseboat stay on Dal Lake to the breathtaking Gulmarg Gondola ride, every moment was memorable. I'm grateful for the wonderful memories I've made.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Amit Patel"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Sanjay Sharma",
    		"reviewBody": "I went to gulmarg with my family and I booked a tour package from Trip free world. I must say it was an amazing experience with Trip free world.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Sanjay Sharma"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Ravi Singh",
    		"reviewBody": "One of the best travel company for kashmir trips. Highly Reccommend!",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Ravi Singh"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Rahul Mehta",
    		"reviewBody": "The entire seven-day vacation in Kashmir was enjoyable for us. They made excellent arrangements for hotels, houseboats, and taxis. In particular, the taxi driver (Mr. Tanveer) was very kind, which we greatly appreciated.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Rahul Mehta"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Arjun Verma",
    		"reviewBody": "An outstanding travel company for excursions to Kashmir is Trip Free World. They deliver first-rate assistance. They offer accommodations and equipment in accordance with your budget. They recently sent us a travel itinerary for Kashmir. It was special, and the agent there, Hansa, was outstanding. She was available around the clock and offered outstanding support. ",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Arjun Verma"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Vikram Gupta",
    		"reviewBody": "Amarnath + Leh Ladakh travel package recently purchased for a fair price. Excellent lodging options, including tents and cottages, were available.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Vikram Gupta"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Anil Choudhary",
    		"reviewBody": "I'm going on a seven-day journey to Kashmir with Trip Free World Tour & Travels that will include the BABA AMARNATH YATRA. The only person who can claim credit for making my vacation the best and most unforgettable for me is Miss Ruhi Jaan, the marketing executive of this firm, who has personally taken care of all of my day-to-day needs. Thanks to Ruhi madam and the travel agency, my trip was successful.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Anil Choudhary"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Priya Mishra",
    		"reviewBody": "Excellent experience with trip-free world tours and travels to discover Kashmir's true beauty, as well as the greatest hotel and transportation options. This company's employees have a good work ethic and are qualified tour guides thus far.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Priya Mishra"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Neha Gupta",
    		"reviewBody": "We had a wonderful time on our trip, and our tour guide, Miss Shaista, was very helpful and accommodating. I had a great time. Thank you Shaista and her crew.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Neha Gupta"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Aarti Reddy",
    		"reviewBody": "Excellent tour operator, and their arrangements for tour packages are extremely excellent. My thanks to Miss Hansa for the efficient planning.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Aarti Reddy"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Meena Sahu",
    		"reviewBody": "I liked it. Trip Free World Tour and Travels' Miss. Hansa, our tour guide, made thoughtful arrangements.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Meena Sahu"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  } ,{
    		"@type": "Review",
    		"name": "Rajesh Singh",
    		"reviewBody": "I have been using Trip Free World Tour and Travels for all my travel needs for years now, and they never disappoint. The prices are reasonable, and the service is excellent. I highly recommend them to anyone looking for a hassle-free travel experience.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Rajesh Singh"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Pooja Gupta",
    		"reviewBody": "My family and I had an amazing time on our recent trip to Kashmir with Trip Free World Tour and Travels. The itinerary was well-planned, and the guides were informative and friendly. I would definitely book with them again.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Pooja Gupta"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Sunita Patel",
    		"reviewBody": "If you're looking for a reliable and affordable travel agency, Trip Free World Tour and Travels is the way to go. Their packages are well-priced, and the customer service is excellent. Highly recommended.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Sunita Patel"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Aarti Patel",
    		"reviewBody": "I booked a trip to Kashmir with Trip Free World Tour and Travels, and I have to say it was one of the best decisions I've ever made. The guides were knowledgeable, and the itinerary was well-planned. I will definitely book with them again.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Aarti Patel"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Ajay Kumar",
    		"reviewBody": "I recently booked a package tour to Kashmir with Trip Free World Tour and Travels, and I couldn't be happier with the experience. The guides were friendly and informative, and the accommodations were top-notch. I highly recommend them.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Ajay Kumar"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Nidhi Gupta",
    		"reviewBody": "Trip Free World Tour and Travels exceeded all my expectations on my recent trip to Kashmir. The guides were knowledgeable and friendly, and the itinerary was well-planned. I will definitely book with them again in the future.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Nidhi Gupta"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Manoj Sharma",
    		"reviewBody": "I had a great experience booking my trip to Kashmir with Trip Free World Tour and Travels. They were responsive to all my queries and helped me plan the perfect itinerary for my needs. Highly recommended",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Manoj Sharma"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Ritu Singh",
    		"reviewBody": "If you're looking for a travel agency that offers excellent service and value for money, look no further than Trip Free World Tour and Travels. I had an amazing time on my trip to Kashmir, and the guides were knowledgeable and friendly. I will definitely be booking with them again.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Ritu Singh"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  }]
    	}
    	</script>
    	<!--Reviews Schema End-->
		
	
		
        <?php include "../include/header-file.php"?>
        <style>
         	/*costume tour scc*/
	   .icon{
                font-size: 13px;
                font-weight: 600;
                margin-right: 1rem;
            }
            .single-nav{
                background-color: #2450a6;
                color: #fff;
                border-radius: 10px;
                padding: 5px;
                font-size: 18px;
            }
            .form-head{
                background-color: #2450a6;
                color: #fff;
                margin-bottom: -5px;
                border-radius: 15px 15px 0 0;
                font-weight: 600;
            }
            .card-header{
                background: #df9403;
                color: #fff;
            }
            .card-header .btn-link{
                color: #fff;
                font-size: 11px;
                font-weight: 500;
                text-decoration: none;
                text-align: left;
            }
            .card-header .heading{
                font-size: 16px;
                font-weight: 600;
                color: #393939;
            }
            ul.breadcrm{}
            ul.breadcrm li a, ul.breadcrm li a:hover{
                text-decoration: none;
                color: #2450a6;
            }
        </style>
	</head>
	<body class="default">

        <?php include "../include/header.php"?>


    <section class="bread1">      
      <div class="container-fluid m-0 p-0">
          <div class="row">
              <div class="col-12">
                    <ul class="breadcrumb breadcrm">
                  <li><a href="<?=$site_url?>">Home</a></li>
                  <li><a href="<?=$site_url?>tour">Tour Package</a></li>
                  <li>Kashmir Tulip Package</li>
                </ul>
                <img class="lazyload w-100" data-src="<?=$site_url?>img/kashmir-tulip-min.jpg" alt="image" style="width:100%; height:450px; margin-top:-20px;">
              </div>
          
      </div>
      </section>
      <!-- .Content  -->
  
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-12 order-md-1 order-2">
                <div class="row">
                    <div class="col-md-9 col-sm-12 ">
                        <h1 class="st-heading">4 Nights 5 Days Kashmir Tulip Tour Package</h1>
                    </div>
                    <div class="col-md-3 col-sm-12 mt-3">
                        <span class="head-rating">Excellent</span>
                        <div class="st-stars style-2" style="color: #df9403;">
                            <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>
                        </div>
                        <p class="st-link">from 21 reviews</p>
                    </div>
                </div>
                <div class="row single-nav">
                    <div class="col-6 col-sm-3">
                        <div class="item d-flex align-items-center">
                            <div class="icon">
                                <i class="far fa-clock"></i>
                            </div>
                            <div class="info">
                                <div class="name">Duration</div>
                                <p class="value">
                                   4 Nights 5 Days </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-3">
                        <div class="item d-flex align-items-center">
                            <div class="icon">
                                <i class="fas fa-shoe-prints"></i>
                            </div>
                            <div class="info">
                                <div class="name">Tour Type</div>
                                <p class="value">
                                    Specific Tour </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-3">
                        <div class="item d-flex align-items-center">
                            <div class="icon">
                                <i class="fas fa-user-friends"></i>
                            </div>
                            <div class="info">
                                <div class="name">Group Size</div>
                                <p class="value">
                                    25 people </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-3">
                        <div class="item d-flex align-items-center">
                            <div class="icon">
                                <i class="fas fa-language"></i>
                            </div>
                            <div class="info">
                                <div class="name">Languages</div>
                                <p class="value">
                                    ___ </p>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Tour Overview-->
                <div class="">
                    <h2 class="mt-3" style="font-size:24px;font-weight:400;">Kashmir Tulip Package</h2>
                    <p class="mt-2" style="font-size:13px; color:#5E6D77;text-align:justify;">The Kashmir Tulip Package is 4 nights and 5-day tour package specially designed for nature lovers and photography enthusiasts.  In this package, we offer tourists an opportunity to immerse themselves in the stunning beauty of  Kashmir during this magical time of the year. You can expect Tulip Garden visits, 
traditional Kashmiri culture, Shikara rides, Photography opportunities, and trekking and nature walks from Our Kashmir Tulip Package.</p>
<div class="">


          <div style="text-align:justify;">
<p><b>Visit the Famous Tulip Gardens:-</b>Tulip Gardens Of Kashmir Makes You Feel Like Heaven On Earth. If you visit these gardens during the Tulip festival then it will be an experience that will itself your memory, and leave you with a deep appreciation for the artistry of nature and the rich cultural heritage of this region. You will also get to see the tulip varieties, scenic views, and cultural attractions.</p>
<p><b>Experience the beauty of Gulmarg:-</b>Gulmarg is famous for many reasons as it offers natural beauty, world-class skiing, adventure activities, botanical gardens, rich cultural heritage, and Alpather Lake, which makes it an outstanding location for tourists. It is one of the most attractive places for filmmakers around the world. And a Trip-free world with all of the famous spots of Gulmarg.</p>
<p><b>Visit the Historic Shankaracharya Temple:-</b>Shankaracharya Temple is also famous for those who want to explore the blend of architecture and pilgrimage site. This temple is also known as the Jyeshteshwara temple and one of the iconic religious sites in the region of Kashmir That's why we have covered this religious temple in our Package. This Hindu temple offers not only spiritual significance but also amazing views of the Kashmir valley.</p>
<p><b>Chance to indulge in local Kashmiri Cuisine and Shopping:-</b>Kashmir has a rich cultural heritage. You will get a chance to indulge in the local cuisine and vibrant shopping areas. The local cuisine of Kashmir is wazwan, rice dishes, Kashmiri dum aloo, Kashmiri kahwa, and bakery items. In Shopping items Pashmina Shawls, Kashmiri carpets, handicrafts, embroidery, saffron, and dry fruits are the most famous. You can explore all of these in our package.</p>

</div>



                </div>

                </div>
                <div class="accordion" id="accordionExample">
                    <div class="card">
                        <div class="card-header" id="headingOne">
                            <h3 class="mb-0">
                                <h3 class="heading float-left">Day 1</h3>
                                <button class="btn btn-link float-right" type="button" data-toggle="collapse"
                                    data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </button>
                            </h3>
                        </div>

                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                            data-parent="#accordionExample">
                            <div class="card-body" style="font-size: 13px">Arrival in Srinagar and transfer to the hotel
On the first day, you will arrive at the Srinagar airport and our representative will receive you and transfer you to the hotel. You can rest and relax in your room for the day or explore the local markets nearby.
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingTwo">
                            <h3 class="mb-0">
                                <h3 class="heading float-left">Day 2</h3>
                                <button class="btn btn-link collapsed float-right" type="button" data-toggle="collapse"
                                    data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </button>
                            </h3>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                            data-parent="#accordionExample">
                            <div class="card-body" style="font-size: 13px">Sightseeing in Srinagar - Visit to Tulip Gardens, Mughal Gardens, and Shankaracharya Temple
After breakfast, you will visit the famous Tulip Gardens and witness the stunning display of colorful tulips. </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingThree">
                            <h3 class="mb-0">
                                <h3 class="heading float-left">Day 3</h3>
                                <button class="btn btn-link collapsed float-right" type="button" data-toggle="collapse"
                                    data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </button>
                            </h3>
                        </div>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                            data-parent="#accordionExample">
                            <div class="card-body" style="font-size: 13px"> Transfer to Gulmarg - Gondola ride and leisure time to explore the beautiful meadows
On the third day, you will move to Gulmarg, which is known for its scenic beauty and snow-capped mountains. You will take a gondola ride, which will take you to the top of the mountain and you can see the scenic landscapes of Gulmarg. You can also explore the beautiful meadows and be in various activities such as skiing, horse riding, and more.</div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingFour">
                            <h3 class="mb-0">
                                <h3 class="heading float-left">Day 4</h3>
                                <button class="btn btn-link collapsed float-right" type="button" data-toggle="collapse"
                                    data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </button>
                            </h3>
                        </div>
                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour"
                            data-parent="#accordionExample">
                            <div class="card-body" style="font-size: 13px">Day trip to Sonamarg - Visit to Thajiwas Glacier and enjoy the scenic beauty
On the fourth day, you will take a day trip to Sonamarg, which is known for its pristine landscapes and natural beauty. You will visit the Thajiwas Glacier, which is a popular tourist attraction and offers stunning views of the surrounding snow-capped mountains.</div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingFive">
                            <h3 class="mb-0">
                                <h3 class="heading float-left">Day 5</h3>
                                <button class="btn btn-link collapsed float-right" type="button" data-toggle="collapse"
                                    data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </button>
                            </h3>
                        </div>
                        <div id="collapseFive" class="collapse" aria-labelledby="headingFive"
                            data-parent="#accordionExample">
                            <div class="card-body" style="font-size: 13px">Departure from Srinagar
On the fifth day, you will check out from the hotel and our representative will drop you off at the Srinagar airport for your onward journey.</div>
                        </div>  
                        </div>
                </div>
                 
                <div class="row mt-5">
                   
					<!-- section 3 -->
					<div class="heading-section">
						<div class="sa-title popcat">Popular destinations
						</div>
				
						<div class="clear"></div>
					</div>
					<div class="section-home vacation-destination">
						<div class="img-hero vs-carousel">
							
							<?php 
                                $query = "SELECT * FROM `gallery`";
                                $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                while ($row = mysqli_fetch_array($Product_data))
                                {
                                    $id=$row['id'];
                                    $title=$row['title'];
                                    $img=$row['image'];
                            ?>
							<!-- item -->
							<div class="item">
								<div class="vs-box">
									<div class="vsb-top">
										<div class="vsbt-img">
											<img class="lazyload" data-src="<?=$site_url?>admin/assets/images/gallery/<?=$img?>" alt="<?=$title?>">
										</div>
									</div>
								</div>
							</div>
							<!-- .item -->
							<?php } ?>
						</div>
					</div>
					<!-- .section 3 -->
                </div>
            </div>
            <div class="col-md-3 col-sm-12 order-md-2 order-1">
                <div class="wrapper">

                    <form action="<?=$site_url?>form" method="post" style="margin-top:-50px;">
                        
                        <h6 class="p-3 form-head">Get In Touch <span style="font-size:20px;"> ₹0</span></h6>
                                <div class="form-signin">
                        <h3 class="form-signin-heading">INQUIRY</h3>
                        <input type="text" class="form-control inpo" name="username" placeholder="Name" required=""
                            autofocus="" />
                        <input type="email" class="form-control mb-1" name="email" placeholder="Email Address" required=""
                            autofocus="" />
                        <input type="text" class="form-control" name="phone" placeholder="Phone..." required="" />
                        <textarea type="text" name="notes" class="form-control" rows="3" cols="40"
                            placeholder="Notes..."></textarea>

                        <button class="btn btn-lg btn-primary btn-block mt-2" name="inquiry" type="submit">Submit</button>
                        </div>
                    </form>
                </div>

                <div style="padding:20px; margin-bottom:10px; border: 1px solid rgba(0,0,0,0.1);">
                    <h3>Tour Package</h3>
                    <div class="row d-flex justify-content-center align-items-center">
                        
					<div class="container section-home home-news">
						
						<div class="home-news-wrap">
						    
						    <?php
                            $query = "SELECT * FROM `tour` order by id ASC limit 3";
                                $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                while ($row = mysqli_fetch_array($Product_data))
                                {
                                    $id=$row['id'];
                                    $url=$row['url'];
                                    $title=$row['title'];
                                    $img=$row['image'];
                                    $desc=$row['des'];
                                    $location=$row['location'];
                                    $price=$row['price'];
                                    $time=$row['time'];
                                    $link=$row['link'];
                            ?>
							<a href="<?=$link?>">
								<div class="news-item">
									<div class="news-content">
										<div class="hnw-img">
											<img class="lazyload" data-src="<?=$site_url?>admin/assets/images/tour/<?=$img?>" alt="<?=$title?>">
										</div>
										<div class="hnw-desc">
											<div class="hnw-title"><?=$title?></div>
										</div>
									</div>
									<div class="news-content1">
									    <div class="hnw-desc">
									        <div class="hnw-text">
												<?=strip_tags(substr($desc,0,100));?>...<a href="<?=$link?>" class="more">Book Now</a>
											</div>
									    </div>
									</div>
								</div>
							</a>
							<?php } ?>
						</div>
					</div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>           
                        
      
      <!--End Tour info-->
       	<div id="content">
				<!-- Content Wrap  -->
				<div class=" container content-wrap">
      	<!-- section 3 -->
					<div class="container heading-section">
						<div class="sa-title popcat text-center">Testimonials
						</div>
					
						<div class="clear"></div>
					</div>
					<div class="container reviews-container vacation-destination mt-4" style="overflow: hidden;">
						<div class="img-hero vs-carousel">
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="<?=$site_url?>img/testimonial.webp" alt="img1" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h3 class="review-title">Ramesh Kumar</h3>
                                        <p class="review-description">I recently booked a trip to Kashmir with Trip Free World Tour and Travels, and I have to say it was one of the most memorable experiences of my life. The entire trip was well-organized, and the guides were knowledgeable and friendly.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="<?=$site_url?>img/testimonial.webp" alt="img2" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h3 class="review-title">Anjali Sharma</h3>
                                        <p class="review-description">I highly recommend Trip Free World Tour and Travels for anyone planning a trip to Kashmir. They offer a wide range of packages to suit all budgets, and the customer service is top-notch. I can't wait to book my next trip with them</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="<?=$site_url?>img/testimonial.webp" alt="img3" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h3 class="review-title">Rajesh Singh</h3>
                                        <p class="review-description">I have been using Trip Free World Tour and Travels for all my travel needs for years now, and they never disappoint. The prices are reasonable, and the service is excellent. I highly recommend them to anyone looking for a hassle-free travel experience</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="<?=$site_url?>img/testimonial.webp" alt="img4" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h3 class="review-title">Pooja Gupta</h3>
                                        <p class="review-description">My family and I had an amazing time on our recent trip to Kashmir with Trip Free World Tour and Travels. The itinerary was well-planned, and the guides were informative and friendly. I would definitely book with them again.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="<?=$site_url?>img/testimonial.webp" alt="img5" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h3 class="review-title">Sanjay Verma</h3>
                                        <p class="review-description">If you're looking for a reliable and affordable travel agency, Trip Free World Tour and Travels is the way to go. Their packages are well-priced, and the customer service is excellent. Highly recommended</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="<?=$site_url?>img/testimonial.webp" alt="img6" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h3 class="review-title">Aarti Patel</h3>
                                        <p class="review-description">I booked a trip to Kashmir with Trip Free World Tour and Travels, and I have to say it was one of the best decisions I've ever made. The guides were knowledgeable, and the itinerary was well-planned. I will definitely book with them again.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="<?=$site_url?>img/testimonial.webp" alt="img7" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h3 class="review-title">Ajay Kumar</h3>
                                        <p class="review-description">I recently booked a package tour to Kashmir with Trip Free World Tour and Travels, and I couldn't be happier with the experience. The guides were friendly and informative, and the accommodations were top-notch. I highly recommend them.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="<?=$site_url?>img/testimonial.webp" alt="img8" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h3 class="review-title">Nidhi Gupta</h3>
                                        <p class="review-description">Trip Free World Tour and Travels exceeded all my expectations on my recent trip to Kashmir. The guides were knowledgeable and friendly, and the itinerary was well-planned. I will definitely book with them again in the future.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="<?=$site_url?>img/testimonial.webp" alt="img9" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h3 class="review-title">Manoj Sharma</h3>
                                        <p class="review-description">I had a great experience booking my trip to Kashmir with Trip Free World Tour and Travels. They were responsive to all my queries and helped me plan the perfect itinerary for my needs. Highly recommended</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="<?=$site_url?>img/testimonial.webp" alt="img10" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h3 class="review-title">Ritu Singh</h3>
                                        <p class="review-description">If you're looking for a travel agency that offers excellent service and value for money, look no further than Trip Free World Tour and Travels. I had an amazing time on my trip to Kashmir, and the guides were knowledgeable and friendly. I will definitely be booking with them again.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
						</div>
					</div>
					<!-- .section 3 -->
						</div>
			</div>
			<!-- .Content  -->
					
					<!-- FAQs Section Start -->
					<div class="container heading-section pt-5">
						<div class="sa-title popcat text-center">Frequently Ask Questions
						</div>
						<div class="heading-info text-center">
							Some frequently ask questions for you
						</div>
						<div class="clear"></div>
					</div>
					<div class="container">
					    
					    <div class="row">
					        <div class="col-lg-12 py-5">
					            
                <div class="accordion" id="faqs">
                    <div class="card">
                        <div class="card-header" id="heading1">
                            <h3 class="mb-0">
                                <h3 class="heading float-left">What type of services are included in the package?</h3>
                                <button class="btn btn-link float-right" type="button" data-toggle="collapse"
                                    data-target="#faq1" aria-expanded="true" aria-controls="faq1">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </button>
                            </h3>
                        </div>

                        <div id="faq1" class="collapse show" aria-labelledby="heading1"
                            data-parent="#faqs">
                            <div class="card-body" style="font-size: 13px">The package includes comfortable and well-appointed hotel accommodations.
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="heading2">
                            <h3 class="mb-0">
                                <h3 class="heading float-left">Is airfare included in the package?</h3>
                                <button class="btn btn-link collapsed float-right" type="button" data-toggle="collapse"
                                    data-target="#faq2" aria-expanded="false" aria-controls="faq2">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </button>
                            </h3>
                        </div>
                        <div id="faq2" class="collapse" aria-labelledby="heading2"
                            data-parent="#faqs">
                            <div class="card-body" style="font-size: 13px">No, airfare is not included in the package. However, our travel experts can assist you with booking flights at an additional cost.
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="heading3">
                            <h3 class="mb-0">
                                <h3 class="heading float-left">Are meals included in the package?</h3>
                                <button class="btn btn-link collapsed float-right" type="button" data-toggle="collapse"
                                    data-target="#faq3" aria-expanded="false" aria-controls="faq3">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </button>
                            </h3>
                        </div>
                        <div id="faq3" class="collapse" aria-labelledby="heading3"
                            data-parent="#faqs">
                            <div class="card-body" style="font-size: 13px">The package includes breakfast and dinner at the hotel. Lunch and additional meals can be purchased separately at local restaurants.
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header" id="heading4">
                            <h3 class="mb-0">
                                <h3 class="heading float-left">What should I pack for a trip to Kashmir?</h3>
                                <button class="btn btn-link collapsed float-right" type="button" data-toggle="collapse"
                                    data-target="#faq4" aria-expanded="false" aria-controls="faq4">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </button>
                            </h3>
                        </div>
                        <div id="faq4" class="collapse" aria-labelledby="heading4"
                            data-parent="#faqs">
                            <div class="card-body" style="font-size: 13px">Depending on the season, you may need warm clothing, comfortable walking shoes, sunscreen, sunglasses, and personal items. It's advisable to pack layers to accommodate varying temperatures.
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
					        </div>
					    </div>
					</div>
					<!-- FAQs Section End -->
			<?php include "../include/footer.php"?>
			
		</body>
	
</html>