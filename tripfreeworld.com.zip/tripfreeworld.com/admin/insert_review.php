<?php 
include"include/config.php";
include"include/menu.php";

error_reporting(0);

if(isset($_GET['id'])) {
  $get_id = mysqli_real_escape_string($conn,$_GET['id']);
  $q="SELECT * FROM review WHERE id='$get_id'";
  $r=mysqli_query($conn,$q);
  $col=mysqli_fetch_array($r);
    $title = $col['title']; 
    $location = $col['location'];
    $des = $col['des'];
?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
		<div class="row">
		<div class="col-lg-12">
		<div class="card">
			   <div class="card-body">
			   <div class="card-header">Update Review</div>
			   <hr>
			<form action="" method="POST" enctype="multipart/form-data">
			    <div class="form-group row">
				<label for="input-26" class="col-sm-2 col-form-label">User Name</label>
				<div class="col-sm-10">
				 	<input type="text" name="title" class="form-control" value="<?=$title;?>">
				</div>
			  </div>

			    <div class="form-group row">
				<label for="input-26" class="col-sm-2 col-form-label">Location</label>
				<div class="col-sm-10">
				 	<input type="text" name="location" class="form-control" value="<?=$location;?>">
				</div>
			  </div>
			  

            <div class="form-group row">
				<label for="input-29" class="col-sm-2 col-form-label">Description</label>
				<div class="col-sm-10">
				<textarea class="form-control" name="des"><?php echo $des; ?></textarea>
				</div>
			  </div>
            
			   <div class="form-group row">
				<label class="col-sm-2 col-form-label"></label>
				<div class="col-sm-10">
				<button name="blog_update" type="submit" class="btn btn-dark btn-round px-5"><i class="icon-lock"></i>Submit</button>
				</div>
			  </div>
			   </form>
			 </div>
			</div>
		</div>
		</div>
	</div>
</div>

<?php 


if(isset($_POST['blog_update']))
{
    $title=mysqli_real_escape_string($conn,$_POST['title']);
    $location=mysqli_real_escape_string($conn,$_POST['location']);
    $des=mysqli_real_escape_string($conn,$_POST['des']);
	

  $sql="UPDATE `review` SET `title`='$title',`location`='$location',`des`='$des' WHERE id='$get_id'";
  $query=mysqli_query($conn,$sql) or die(mysqli_error($conn));  
  if($query)
  {
	echo "<script>alert('update succesfully');window.location='review_table.php';</script>";
  }
}

}  // IF ISSET END
else {

?>	
  <div class="content-wrapper">
    <div class="container-fluid">

			<div class="row">
			<div class="col-lg-12">
			<div class="card">
				   <div class="card-header">
				   		<a href="review_table.php" class="btn btn-success" style="float:right;">All Review</a>
				   		Add Review
				   </div>
				   <div class="card-body">
				   <hr>
				<form action="" method="POST" enctype="multipart/form-data">
				    <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">User Name</label>
					<div class="col-sm-10">
					 	<input type="text" name="title" class="form-control">
					</div>
				  </div>
				    <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Location</label>
					<div class="col-sm-10">
					 	<input type="text" name="location" class="form-control">
					</div>
				  </div>
				  

                <div class="form-group row">
					<label for="input-29" class="col-sm-2 col-form-label">Description</label>
					<div class="col-sm-10">
						<textarea class="form-control" name="des"></textarea>
					</div>
				 </div>	  
				 
				<div class="form-group row">
					<label class="col-sm-2 col-form-label"></label>
					<div class="col-sm-10">
					<button name="blog_submit" type="submit" class="btn btn-dark btn-round px-5"><i class="icon-lock"></i>Submit</button>
					</div>
				</div>
				   </form>
				 </div>
				</div>
			</div>
			</div>
			<?php

if(isset($_POST['blog_submit']))
{
    $title=mysqli_real_escape_string($conn,$_POST['title']);
    $location=mysqli_real_escape_string($conn,$_POST['location']);
    $des=mysqli_real_escape_string($conn,$_POST['des']);

	$sql="INSERT INTO `review`(`title`,`location`,`des`) VALUES ('$title','$location','$des')";
	$query=mysqli_query($conn,$sql) or die(mysqli_error($conn));
	if($query)
	{
		echo("<script>alert('Insert succesfully');window.location='review_table.php';</script>");
	}
	else {
	   echo("<script>alert('Review not inserted!');window.location='insert_review.php';</script>");
	}		
}

}  // ELSE CONDITION END

?>		
<?php include"include/footer.php"?>
		</div>
		
 
		
	