<html lang="en">
	
<head>
		
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<title>Discover Budget-Friendly and Best Tour Packages In Kashmir</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
	<!--General Meta Start-->
    <meta name="description"content="Discover the heaven of kashmir with the best tour packages in kashmir.Immerse yourself in the breathtaking beauty with your couples, families, and friends."/> 
    <meta name="keywords" content="Kashmir tour operators, Cheap kashmir tour packages, Srinagar tour packages from all over india, Kashmir trip, kashmir tour pacakges, srinagar holidays trip from delhi, best tour packages in kashmir"/>
	<meta name="author" content="Tour and Travels"/>
	<meta name="robots" content="index, follow" />
	<meta name="distribution" content="global" />
	<meta name="coverage" content="india" />
	<meta name="object" content="document"/>
	<meta name="audience" content="All" />
	<meta name="revisit-after" content="1 day"/>
	<meta name="language" content="en"/>
	<meta name="rating" content="general"/>
	<meta name="copyright" content="Copyright Trip Free World 2023"/>
	<!--General Meta End-->
	
	<!--canonical tag-->
     <link rel="canonical" href="https://www.tripfreeworld.com/"/>
     
    <!--OG Meta Start-->
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Discover the Best Tour Packages In Kashmir" />
    <meta property="og:url" content="https://www.tripfreeworld.com/"/>
    <meta property="og:description" content="Discover the heaven of kashmir with the best tour packages in kashmir. Immerse yourself in the breathtaking beauty with your couples, families, and friends." />
    <meta property="og:image" content="https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp" />
    <!--OG Meta end-->
    
    <!---Schema markup start--->
    <script type="application/ld+json">
    
{
  "@context": "https://schema.org",
  "@type": "TravelAgency",
  "name": "Trip Free World",
  "image": "https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp",
  "@id": "",
  "url": "https://www.tripfreeworld.com/",
  "telephone": "9906830446",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Naidkhai, Amberhrah Sopore, Parraypora",
    "addressLocality": "srinagar",
    "postalCode": "193201",
    "addressCountry": "IN"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 34.2867629,
    "longitude": 74.4624013
  },
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Thursday",
      "Wednesday",
      "Friday",
      "Saturday",
      "Sunday"
    ],
     "opens": "09:00",
    "closes": "17:00"
   
  } 
}
  </script>		
  
  <!--Reviews Schema Start-->
    		<script type="application/ld+json">
    	{
    	  "@context": "https://schema.org/", 
    	  "@type": "Product", 
    	  "name": "Trip Free World",
    	  "image": "https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp",
    	  "description": "Best Travel Agency in kashmir",
    	  "brand": {
    		"@type": "Brand",
    		"name": "Trip Free World"
    	  },
    	  "aggregateRating": {
    		"@type": "AggregateRating",
    		"ratingValue": "5",
    		"bestRating": "5",
    		"worstRating": "1",
    		"ratingCount": "4.9",
    		"reviewCount": "21"
    	  },
    	  "review": [{
    		"@type": "Review",
    		"name": "Ramesh Kumar",
    		"reviewBody": "I recently booked a trip to Kashmir with Trip Free World Tour and Travels, and I have to say it was one of the most memorable experiences of my life. The entire trip was well-organized, and the guides were knowledgeable and friendly.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Ramesh Kumar"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Anjali Sharma",
    		"reviewBody": "I highly recommend Trip Free World Tour and Travels for anyone planning a trip to Kashmir. They offer a wide range of packages to suit all budgets, and the customer service is top-notch. I can't wait to book my next trip with them.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Anjali Sharma"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Amit Patel",
    		"reviewBody": "I had a fantastic time exploring Kashmir with Trip Free World. Their package was not only affordable but also packed with incredible experiences. From the houseboat stay on Dal Lake to the breathtaking Gulmarg Gondola ride, every moment was memorable. I'm grateful for the wonderful memories I've made.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Amit Patel"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Sanjay Sharma",
    		"reviewBody": "I went to gulmarg with my family and I booked a tour package from Trip free world. I must say it was an amazing experience with Trip free world.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Sanjay Sharma"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Ravi Singh",
    		"reviewBody": "One of the best travel company for kashmir trips. Highly Reccommend!",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Ravi Singh"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Rahul Mehta",
    		"reviewBody": "The entire seven-day vacation in Kashmir was enjoyable for us. They made excellent arrangements for hotels, houseboats, and taxis. In particular, the taxi driver (Mr. Tanveer) was very kind, which we greatly appreciated.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Rahul Mehta"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Arjun Verma",
    		"reviewBody": "An outstanding travel company for excursions to Kashmir is Trip Free World. They deliver first-rate assistance. They offer accommodations and equipment in accordance with your budget. They recently sent us a travel itinerary for Kashmir. It was special, and the agent there, Hansa, was outstanding. She was available around the clock and offered outstanding support. ",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Arjun Verma"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Vikram Gupta",
    		"reviewBody": "Amarnath + Leh Ladakh travel package recently purchased for a fair price. Excellent lodging options, including tents and cottages, were available.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Vikram Gupta"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Anil Choudhary",
    		"reviewBody": "I'm going on a seven-day journey to Kashmir with Trip Free World Tour & Travels that will include the BABA AMARNATH YATRA. The only person who can claim credit for making my vacation the best and most unforgettable for me is Miss Ruhi Jaan, the marketing executive of this firm, who has personally taken care of all of my day-to-day needs. Thanks to Ruhi madam and the travel agency, my trip was successful.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Anil Choudhary"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Priya Mishra",
    		"reviewBody": "Excellent experience with trip-free world tours and travels to discover Kashmir's true beauty, as well as the greatest hotel and transportation options. This company's employees have a good work ethic and are qualified tour guides thus far.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Priya Mishra"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Neha Gupta",
    		"reviewBody": "We had a wonderful time on our trip, and our tour guide, Miss Shaista, was very helpful and accommodating. I had a great time. Thank you Shaista and her crew.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Neha Gupta"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Aarti Reddy",
    		"reviewBody": "Excellent tour operator, and their arrangements for tour packages are extremely excellent. My thanks to Miss Hansa for the efficient planning.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Aarti Reddy"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Meena Sahu",
    		"reviewBody": "I liked it. Trip Free World Tour and Travels' Miss. Hansa, our tour guide, made thoughtful arrangements.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Meena Sahu"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  } ,{
    		"@type": "Review",
    		"name": "Rajesh Singh",
    		"reviewBody": "I have been using Trip Free World Tour and Travels for all my travel needs for years now, and they never disappoint. The prices are reasonable, and the service is excellent. I highly recommend them to anyone looking for a hassle-free travel experience.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Rajesh Singh"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Pooja Gupta",
    		"reviewBody": "My family and I had an amazing time on our recent trip to Kashmir with Trip Free World Tour and Travels. The itinerary was well-planned, and the guides were informative and friendly. I would definitely book with them again.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Pooja Gupta"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Sunita Patel",
    		"reviewBody": "If you're looking for a reliable and affordable travel agency, Trip Free World Tour and Travels is the way to go. Their packages are well-priced, and the customer service is excellent. Highly recommended.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Sunita Patel"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Aarti Patel",
    		"reviewBody": "I booked a trip to Kashmir with Trip Free World Tour and Travels, and I have to say it was one of the best decisions I've ever made. The guides were knowledgeable, and the itinerary was well-planned. I will definitely book with them again.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Aarti Patel"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Ajay Kumar",
    		"reviewBody": "I recently booked a package tour to Kashmir with Trip Free World Tour and Travels, and I couldn't be happier with the experience. The guides were friendly and informative, and the accommodations were top-notch. I highly recommend them.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Ajay Kumar"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Nidhi Gupta",
    		"reviewBody": "Trip Free World Tour and Travels exceeded all my expectations on my recent trip to Kashmir. The guides were knowledgeable and friendly, and the itinerary was well-planned. I will definitely book with them again in the future.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Nidhi Gupta"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Manoj Sharma",
    		"reviewBody": "I had a great experience booking my trip to Kashmir with Trip Free World Tour and Travels. They were responsive to all my queries and helped me plan the perfect itinerary for my needs. Highly recommended",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Manoj Sharma"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  },{
    		"@type": "Review",
    		"name": "Ritu Singh",
    		"reviewBody": "If you're looking for a travel agency that offers excellent service and value for money, look no further than Trip Free World Tour and Travels. I had an amazing time on my trip to Kashmir, and the guides were knowledgeable and friendly. I will definitely be booking with them again.",
    		"reviewRating": {
    		  "@type": "Rating",
    		  "ratingValue": "5",
    		  "bestRating": "5",
    		  "worstRating": "1"
    		},
    		"author": {"@type": "Person", "name": "Ritu Singh"},
    		"publisher": {"@type": "Organization", "name": "Trip Free World"}
    	  }]
    	}
    	</script>
    	<!--Reviews Schema End-->
	  
	    <?php include "include/header-file.php"?>
         
	</head>
	<body class="default">
	     <?php include "include/header.php"?>

        <!-- Header  -->
		<nav class="navbar navbar-expand-lg navbar-light bg-header">
		    <div class="container-fluid">
				<button type="button" id="sidebarleftbutton" class="btn" name="Trip Free World Logo" aria-label="Logo">
					<i class="fas fa-align-left"></i>
				</button>
				<div class="logo">
				    <img class="lazyload" data-src="<?$site_url?>admin/assets/images/logo/<?=$About_rows['logo']?>" alt="image">
				    Trip Free World Tour & Travels
				</div>
				<button type="button" id="sidebarrightbutton" class="btn">
					<div class="notif">
						<i class="fas fa-bell"></i>
						<i class="fas fa-circle "></i>
					</div>
				</button>
			</div>
		</nav>
		<!-- .Header  -->
		
				    
				    <section class="hero" id="video-background">
				        <video kind="about tour and travels" srclang="en" label="english_captions" id="bg-video" autoplay muted loop>
				            <source src="img/about.mp4">
				        </video>
    <div class="container content">
      <h1 class="h1">Explore the Best Tour Packages In Kashmir Now!</h1>
      <div class="hero-tabs">
        <div class="tab-links">
          <button class="tab-link active">Tour Package</button>
          <button class="tab-link">Book Car</button>
        </div>
        <div class="tab-content">
          <form class="active" action="<?=$site_url?>form" method="post">
            <div class="row">
            <div class="col-md-3 col-sm-6 form-group">
              <label for="name">Customer Name</label>
              <input type="text" id="name" name="name" required placeholder="Customer Name">
            </div>
            <div class="col-md-3 col-sm-6 form-group">
              <label for="phone">Mobile Number</label>
              <input type="number" id="phone" name="phone" required placeholder="Mobile Number">
            </div>
            <div class="col-md-3 col-sm-6 form-group">
              <label for="email">Email</label>
              <input type="email" id="email" name="email" required placeholder="Email">
            </div>
            <div class="col-md-3 col-sm-6 form-group">
              <label for="tour">Select Tour Package</label>
              <select id="tour" name="package" required>
                <option value="0">Select Tour Package</option>
                <?php
                    $query = "SELECT * FROM `tour` order by id ASC";
                    $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                    while ($row = mysqli_fetch_array($Product_data))
                    {
                        $id=$row['id'];
                        $title=$row['title'];
                ?>
                <option value="<?=$id?>"><?=$title?></option>
                <?php } ?>
              </select>
            </div>
          </div>
          <div class="row mt-md-3 justify-content-center">
            <button class="col-md-3 col-sm-6 button" name="sub_package" type="submit">Send</button>
          </div>
          </form>
          <form action="<?=$site_url?>form" method="post">
            <div class="row">
            <div class="col-md-3 col-sm-6 form-group">
              <label for="name">Customer Name</label>
              <input type="text" id="name" name="name" required placeholder="Customer Name">
            </div>
            <div class="col-md-3 col-sm-6 form-group">
              <label for="phone">Mobile Number</label>
              <input type="number" id="phone" name="phone" required placeholder="Mobile Number">
            </div>
            <div class="col-md-3 col-sm-6 form-group">
              <label for="email">Email</label>
              <input type="email" id="email" name="email" required Placeholder="Email">
            </div>
              <div class="col-md-3 col-sm-6 form-group">
                <label for="tour">Select Car</label>
              <select id="tour" name="car" required>
                <option value="0">Select Car</option>
                <?php
                    $query = "SELECT * FROM `car` order by id ASC";
                    $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                    while ($row = mysqli_fetch_array($Product_data))
                    {
                        $id=$row['id'];
                        $title=$row['title'];
                ?>
                <option value="<?=$id?>"><?=$title?></option>
                <?php } ?>
              </select>
            </div>
          </div>
          <div class="row mt-md-3">
            <div class="col-md-3 col-sm-6 form-group">
              <label for="pick-up">Pick-up Location</label>
              <input type="text" id="pick-up" name="pickup" required placeholder="Enter Your Current Location">
            </div>
            <div class="col-md-3 col-sm-6 form-group">
              <label for="drop-off">Drop-off Location</label>
              <input type="text" id="drop-off" name="dropoff" required placeholder="Where Wanted to Go">
            </div>
            <div class="col-md-3 col-sm-6 form-group">
              <label for="date">Pick-up Date</label>
              <input type="date" id="date" name="date" required>
            </div>
            <div class="col-md-3 col-sm-6 form-group">
              <label for="time">Pick-up Time</label>
              <input type="time" id="time" name="time" required>
            </div>
            
          </div>
          <div class="row mt-md-3 justify-content-center">
            <button class="col-md-3 col-sm-6 button" name="book" type="submit">Send</button>
          </div>
          </form>
        </div>
      </div>
    </div>
  </section>
				    
					
			<!-- Content  -->
			<div id="content">
				<!-- Content Wrap  -->
				<div class=" container content-wrap">
				    
					<!-- section 1 -->
					<div class="home-icon">
						<div class="section-home">
							<div class="container">
								<div class="row">
									<div class="col s-icon homepage-icon-menu">
										<img class="lazyload" data-src="img/icons/cab.webp" alt="icon">
											<div class="s-icon-text">
												car
											</div>
									</div>
									<div class="col s-icon homepage-icon-menu">
											<img class="lazyload" data-src="img/icons/hotel.webp" alt="icon">
											<div class="s-icon-text">
												Hotel
											</div>
										
									</div>
									<div class="col s-icon homepage-icon-menu">
										<img class="lazyload" data-src="img/icons/takeoff.webp" alt="icon">
											<div class="s-icon-text">
												Flight
											</div>
									</div>
									<div class="col s-icon homepage-icon-menu">
										<img class="lazyload" data-src="img/icons/cultures.webp" alt="icon">
											<div class="s-icon-text">
												House Boat
											</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- .section 1 -->
					
                    <!-- Content  -->
                    <div id="content">
                        <div class="content-wrap">
                            <div class="container subsite">
                                <div class="row">
                                    <div class="col-md-12 pb-3">
                                        <div class="subsite-heading">
                                           <h2 style="font-size:24px;font-weight:600;">Find The Best Tour Packages In Kashmir</h2>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <img data-src="<?=$site_url?>admin/assets/images/logo/<?=$About_rows['image']?>" alt="image" class="lazyload border-radius">
                                    </div>
                                    <div class="col-md-6">
                                    <p style="text-align:justify;">
                                        Trip free world Tour operators offer Kashmir and Srinagar Tour packages at very affordable prices. If you want to travel to a pilgrimage place, a romantic destination, or a cool place, Trip Free world  offers you the most exotic travel destinations in Jammu Kashmir,  Srinagar, Pahalgam, Ladakh, Vashno Devi , Katra, Sanasar and more. 
Our packages cover famous tourist destinations of kashmir and Srinagar, Sonmarg, and Pahalgam. Transportation, accommodation, guided tours and other amenities are included in our services. We value our travelers' interest. We include tour packages by their interest including adventure, nature, history and culture. Also, we provide a wide range of travel services, including customized tour packages, hotel bookings, transportation and guided tours.
Our Jammu and Kashmir Tourism Packages and Srinagar Trips are the best and will be loved by your family and friends if you are planning to give them a vacation treat. We offer the most affordable Srinagar travel packages in the Jammu & Kashmir tourism sector. Check out our special Mumbai, Maharashtra, Kashmir tour packages.
Kashmir is a destination for adventure seekers, newlywed couples, friends, and people who enjoy romance. In case you have decided to take a tour of Jammu and Kashmir, Trip Free World is the best tour operator in the region and will offer you the most affordable Vaishno Devi Guided Tour and travel packages. If you have never been to Kashmir, you are truly missing out on something very special in your life. Our Pune To Kashmir Tour Packages have great deals to meet your budget and pricing range while giving you a once-in-a-lifetime experience. From Delhi, Bangalore, West Bengal, Gujarat, and other states and towns in India as well as from outside, we offer Srinagar trip packages for Kashmir.

                                    </p>  
                                     </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- .Content  -->
                    
                    
                    <h3 style="text-align:center;color:#2450a6;"><b>Why To Choose Trip Free World</b></h3><br>
      <p style="text-align:justify;">Trip Free World Offers you Tour and holiday Package for Jammu & Kashmir includes gulmarg adventure, Amarnath yatra packages, srinagar tour packages. Because we have many options so you can choose according to your preference. We provide you with the best and safe tour packages. We have been in this business for over 10+ years  and we have a team of experienced travel agents who can help to plan your perfect trip according to your needs and budget. We have a wide range of destinations so you can find the perfect trip for your dream vacation. Whether you want to relax on a beach, go on an adventure, or experience a new culture, Trip Free World can help you find the perfect destination for you.

Our knowledgeable travel specialists will assist you with all aspects of your trip and provide you the best package trips to Jammu, Srinagar, and Leh Ladakh. We assist you in finding the finest offers and prices for Leh Ladakh vacation packages or Kashmir tour packages from Mumbai in order to make your trip to Kashmir one to remember. Trip Free World (Tour Operator in Kashmir), a renowned tour operator and travel agency in Kashmir, is based in Srinagar, Kashmir, India.  A tourism company in Kashmir with its main office  in Srinagar gives us the advantage of being able to offer you better services, deals, and discounts all year long for any services that you may need, such as car rental in Srinagar, Gulmarg gondola reservations, houseboat reservations on Dal Lake, hotel reservations in Srinagar, Pahalgam, or a cup of Kashmiri green tea kahwa.


</p>
      
					<!-- section 2 -->
					<div class="container heading-section">
						<div class="sa-title popcat"><h4 style="font-size:20px;font-weight:600;">Car Available </h4></div>
						<div class="heading-info">
							Choose your favorite car
						</div>
						<div class="clear"></div>
					</div>
					<div class="section-home container available-car">
						
						<div class="row car-carousel">
						    
						    <?php
                            $query = "SELECT * FROM `car` order by id ASC";
                            $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                            while ($row = mysqli_fetch_array($Product_data))
                            {
                                $id=$row['id'];
                                $title=$row['title'];
                                $type=$row['type'];
                                $img=$row['image'];
                                $seat=$row['seat'];
                                $bags=$row['bags'];
                                $price=$row['price'];
                            ?>
							<!-- item -->
							<div class="col-md-4 col-12 item pb-3">
								<div class="acr-box">
									<div class="acr-box-in">
										<div class="acr-img">
											<img class="lazyload" data-src="<?=$site_url?>admin/assets/images/car/<?=$img?>" alt="<?=$title?>">
										</div>
										<div class="acr-content">
											<div class="ct-name"><h4 style="font-size:18px;font-weight:600;"><?=$title?></h4></div>
											<div class="ct-cost"><span class="cprice"> ₹<?=$price?> </span><span class="perday">rent per day</span></div>
											
											<div class="ct-reserve">
												<a href="tel:9906830446" class="theme-button">
													Call Now
												</a>
											</div>
										</div>
									</div>
									<div class="acr-bg">
										<img class="lazyload" data-src="img/bgcar.webp" alt="car1">
									</div>
								</div>
							</div>
							<!-- .item -->
							<?php } ?>
						</div>
					</div>
					<!-- .section 2-->
					<!-- section 3 -->
					<div class="container heading-section">
						<div class="sa-title popcat"><h3 style="font-size:20px;font-weight:600;">Popular destinations</h3>
						</div>
						<div class="heading-info">
							Memorable romantic vacation
						</div>
						<div class="clear"></div>
					</div>
					<div class="section-home container vacation-destination">
						<div class="row vs-carousel">
							
							<?php
                                $query = "SELECT * FROM `destination` order by id ASC";
                                $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                while ($row = mysqli_fetch_array($Product_data))
                                {
                                    $id=$row['id'];
                                    $title=$row['title'];
                                    $img=$row['image'];
                                    $location=$row['location'];
                                    $time=$row['time'];
                                    $price=$row['price'];
                            ?>
							<!-- item -->
							<div class="col-md-4 col-12 item pb-3">
								<div class="vs-box">
									<div class="vsb-top">
										<div class="vsb-rating">
											5.0 <i class="fas fa-star"></i>
										</div>
										<div class="vsbt-img">
											<img class="lazyload" data-src="<?=$site_url?>admin/assets/images/destination/<?=$img?>" alt="<?=$title?>">
										</div>
									</div>
									<div class="vsb-middle">
										<div class="vsbm-left">
											<h4 style="font-size:18px;font-weight:600;"><?=$title?>, <?=$location?></h4>
										</div>
										<div class="vsbm-right">
											₹<?=$price?>
										</div>
									</div>
								</div>
							</div>
							<!-- .item -->
							<?php } ?>
						</div>
					</div>
					<!-- .section 3 -->
					<!-- section 4 -->
					<div class="container heading-section">
						<div class="sa-title popcat"><h3 style="font-size:18px;font-weight:600;">Popular Tour Packages</h3> </div>
						<div class="heading-info">
							Choose package which you like most
						</div>
						<div class="clear"></div>
					</div>
					<div class="container section-home home-news">
						
						<div class="home-news-wrap">
						    
						    <?php
						    $number=1;
                            $query = "SELECT * FROM `tour` order by id ASC";
                                $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                while ($row = mysqli_fetch_array($Product_data))
                                {
                                    $id=$row['id'];
                                    $url=$row['url'];
                                    $title=$row['title'];
                                    $img=$row['image'];
                                    $desc=$row['des'];
                                    $location=$row['location'];
                                    $price=$row['price'];
                                    $time=$row['time'];
                                    $link=$row['link'];
                            ?>
							<a href="<?=$link?>">
								<div class="news-item">
									<div class="news-content">
										<div class="hnw-img">
											<img class="lazyload" data-src="<?=$site_url?>admin/assets/images/tour/<?=$img?>" alt="<?=$title?>">
										</div>
										
										<div class="hnw-desc">
										  
											<a href="<?=$link?>" class="hnw-title" aria-label="Image-<?=$number++?>"><?=$title?></a>
										 	
											<div class="hnw-text">
											   	<?=$desc?><a href="<?=$link?>" class="more">Book Now</a>
											</div>
										</div>
									</div>
								</div>
							</a>
							<?php } ?>
						
						</div>
					</div>
					<!-- .section 4 -->
					
					<div class="container subsite">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="subsite-heading">
                                    <h3 style="font-size:20px;font-weight:600;">Gallery</h3>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="gallery-section">
                                    <div class="row-gallery">
                                        <div class="wrap-gallery">
                                            <?php
                                            $num = 1;
                                            $query = "SELECT * FROM `gallery` order by id ASC";
                                            $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                            while ($row = mysqli_fetch_array($Product_data))
                                                {
                                                $id=$row['id'];
                                                $title=$row['title'];
                                                $img=$row['image'];
                                            ?>
                                            <div class="col-md-4 col-sm-6 col-12 gall-col gallery-img-box" data-category-image="hotel,city">
                                                <a class="gallery-list" href="<?=$site_url?>admin/assets/images/gallery/<?=$img?>" target="_blank" rel="noopener"><img alt="<?=$title?>" class="lazyload" data-src="<?=$site_url?>admin/assets/images/gallery/<?=$img?>"></a>
                                            </div>
                                            <?php 
                                            if($num%3 == 0) {
                                                echo '
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                                    
                        <div class="row">
                            <div class="col-md-12">
                                <div class="gallery-section">
                                    <div class="row-gallery">
                                        <div class="wrap-gallery">
                                                ';
                                            }
                                            $num++;
                                                }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					
					<!-- section 3 -->
					<div class="container heading-section">
						<div class="sa-title popcat"><h3 style="font-size:20px;font-weight:600;">Testimonials</h3>
						</div>
						<div class="heading-info">
							What clients say about us
						</div>
						<div class="clear"></div>
					</div>
					<div class="container reviews-container vacation-destination mt-4">
						<div class="img-hero vs-carousel">
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="img/testimonial.webp" alt="img1" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h4 class="review-title">Ramesh Kumar</h4>
                                        <p class="review-description">I recently booked a trip to Kashmir with Trip Free World Tour and Travels, and I have to say it was one of the most memorable experiences of my life. The entire trip was well-organized, and the guides were knowledgeable and friendly.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="img/testimonial.webp" alt="img2" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h4 class="review-title">Anjali Sharma</h4>
                                        <p class="review-description">I highly recommend Trip Free World Tour and Travels for anyone planning a trip to Kashmir. They offer a wide range of packages to suit all budgets, and the customer service is top-notch. I can't wait to book my next trip with them</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="img/testimonial.webp" alt="img3" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h4 class="review-title">Rajesh Singh</h4>
                                        <p class="review-description">I have been using Trip Free World Tour and Travels for all my travel needs for years now, and they never disappoint. The prices are reasonable, and the service is excellent. I highly recommend them to anyone looking for a hassle-free travel experience</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="img/testimonial.webp" alt="img4" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h4 class="review-title">Pooja Gupta</h4>
                                        <p class="review-description">My family and I had an amazing time on our recent trip to Kashmir with Trip Free World Tour and Travels. The itinerary was well-planned, and the guides were informative and friendly. I would definitely book with them again.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="img/testimonial.webp" alt="img5" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h4 class="review-title">Sanjay Verma</h4>
                                        <p class="review-description">If you're looking for a reliable and affordable travel agency, Trip Free World Tour and Travels is the way to go. Their packages are well-priced, and the customer service is excellent. Highly recommended</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="img/testimonial.webp" alt="img6" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h4 class="review-title">Aarti Patel</h4>
                                        <p class="review-description">I booked a trip to Kashmir with Trip Free World Tour and Travels, and I have to say it was one of the best decisions I've ever made. The guides were knowledgeable, and the itinerary was well-planned. I will definitely book with them again.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="img/testimonial.webp" alt="img7" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h4 class="review-title">Ajay Kumar</h4>
                                        <p class="review-description">I recently booked a package tour to Kashmir with Trip Free World Tour and Travels, and I couldn't be happier with the experience. The guides were friendly and informative, and the accommodations were top-notch. I highly recommend them.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="img/testimonial.webp" alt="img8" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h4 class="review-title">Nidhi Gupta</h4>
                                        <p class="review-description">Trip Free World Tour and Travels exceeded all my expectations on my recent trip to Kashmir. The guides were knowledgeable and friendly, and the itinerary was well-planned. I will definitely book with them again in the future.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="img/testimonial.webp" alt="img9" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h4 class="review-title">Manoj Sharma</h4>
                                        <p class="review-description">I had a great experience booking my trip to Kashmir with Trip Free World Tour and Travels. They were responsive to all my queries and helped me plan the perfect itinerary for my needs. Highly recommended</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
							<!-- item -->
							<div class="item">
                                <div class="review-card">
                                    <div class="review-image">
                                        <img class="lazyload" data-src="img/testimonial.webp" alt="img10" style="width: 100px" />
                                    </div>
                                    <div class="review-details">
                                        <h4 class="review-title">Ritu Singh</h4>
                                        <p class="review-description">If you're looking for a travel agency that offers excellent service and value for money, look no further than Trip Free World Tour and Travels. I had an amazing time on my trip to Kashmir, and the guides were knowledgeable and friendly. I will definitely be booking with them again.</p>
                                        <div class="review-rating">
                                            <span class="rating-number">5.0</span>
                                            <span class="rating-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                                        </div>
                                    </div>
                                </div>
							</div>
							<!-- .item -->
						</div>
					</div>
					<!-- .section 3 -->
					
				</div>
			</div>
			<!-- .Content  -->
			
			
			
			
			<?php include "include/footer.php"?>
            
			
		</body>
	
</html>