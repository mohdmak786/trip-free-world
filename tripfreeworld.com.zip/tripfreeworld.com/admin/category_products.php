<?php 
  include('include/config.php');

	$get_id = mysqli_real_escape_string($conn,$_POST['get_data']);
	$number = 1;
	$select = "SELECT * FROM products WHERE cat_id='$get_id'";
	$query = mysqli_query($conn,$select);
	$count = mysqli_num_rows($query);
	if($count>0) {
	$total = mysqli_num_rows($query);
	while($row = mysqli_fetch_array($query))  {	
		$id=$row['id'];
		$title=$row['title'];
        $image=$row['image'];
        $price=$row['price'];
        $cat_id=$row['cat_id'];    
        $sub_cat=$row['sub_cat'];    
		$status=$row['status']; 	
?>
<tr>
	<td><?=$number++;?>
	<td><?=$title; ?></td>
	<td><img src="assets/images/category/<?=$image;?>" width="100px"></td>
	<td>
      <?php 
      if($cat_id !="") {
          $select1 = "SELECT * FROM category WHERE id='$cat_id'";
          $query1 = mysqli_query($conn,$select1);
          $row1 = mysqli_fetch_array($query1);
            $cat_name = $row1['title'];
            echo $cat_name;
      }
      ?>
    </td>       
    <td>
      <?php 
        if($sub_cat !="") {
          $select1 = "SELECT * FROM sub_category WHERE id='$sub_cat'";
          $query1 = mysqli_query($conn,$select1);
          $row1 = mysqli_fetch_array($query1);
            $cat_name = $row1['title'];
            echo $cat_name;
        }
      ?>
    </td>     
    <td><?=$price ?></td> 
    <td>
      <?php
        if($status=="Active") {
          echo "<span class='badge badge-success'>".$status."</span>";
        }
        else {
          echo "<span class='badge badge-danger'>".$status."</span>";
        }
      ?>
    </td>       
		
		<?php echo'
        <td><a href="insert_products.php?id='.$id.'"><i class="fa fa-pencil"></i></a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
		<a href="product_table.php?id='.$id.'"><i class="fa fa-trash-o"></a></td>
    </tr>';
}

}  // IF COUNT END

else {
	echo '<tr>
		<th colspan="8">No Products Available at this Name</th>
	</tr>';	
}
?>

