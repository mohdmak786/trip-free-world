<?php
$conn =  mysqli_connect("cs3005", "sspdeygq", "retxFQ!J!PKV", "sspdeygq_trip_free_world");
// $conn =  mysqli_connect("localhost", "root", "", "venera_salon");

if(!$conn) {
	echo "<script>alert('Connection Failed". mysqli_connect_error()."')</script>";
}

// $site_url = "http://localhost/venera/";
$site_url = "https://tripfreeworld.com/";



    $query = "SELECT * FROM `about` order by id desc";
    $About_data = mysqli_query($conn, $query);
    $About_rows = mysqli_fetch_assoc($About_data);
    $id = $About_rows['id'];
    

?>