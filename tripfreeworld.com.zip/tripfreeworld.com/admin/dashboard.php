<?php 

include"include/menu.php";

?>
<div class="clearfix"></div>
	
<div class="content-wrapper">
    <div class="container-fluid">

		<div class="card mt-3">
			<div class="card-content">
				<div class="row row-group m-0">
					<?php
				      	$select2 = "SELECT * FROM banner";
				        $query2 = mysqli_query($conn,$select2);
				        $count = mysqli_num_rows($query2);
				      ?>
					<div class="col-12 col-lg-6 col-xl-3 border-light">
						<a href="slider_display.php">
							<div class="card-body large-font-size bg-success text-white">
							  <h5 class=" mb-0"> <span class="float-right"></span></h5>
								<p class="mb-0  float-left">Slider </p>
							  <p class="mb-0  float-right number"><span class="badge badge-danger"><?=$count;?></span></p>
							</div>
						</a>
					</div>
					<?php
				      	$select2 = "SELECT * FROM category";
				        $query2 = mysqli_query($conn,$select2);
				        $count = mysqli_num_rows($query2);
				      ?>
					<div class="col-12 col-lg-6 col-xl-3 border-light">
						<a href="category_table.php">
							<div class="card-body large-font-size bg-success text-white">
							  <h5 class=" mb-0"> <span class="float-right"></span></h5>
								<p class="mb-0  float-left">Category </p>
							  <p class="mb-0  float-right number"><span class="badge badge-danger"><?=$count;?></span></p>
							</div>
						</a>
					</div>
					
					<?php
				      	$select2 = "SELECT * FROM enquires";
				        $query2 = mysqli_query($conn,$select2);
				        $count = mysqli_num_rows($query2);
				      ?>
					<div class="col-12 col-lg-6 col-xl-3 border-light">
						<a href="mail.php">
							<div class="card-body large-font-size bg-success text-white">
							  <h5 class=" mb-0"> <span class="float-right"></span></h5>
								<p class="mb-0  float-left">Enquiry </p>
							  <p class="mb-0  float-right number"><span class="badge badge-danger"><?=$count;?></span></p>
							</div>
						</a>
					</div>				
								
				</div>
			</div>
		</div>  
		
	</div>
		
<?php 
include"include/footer.php";?>		

</div>