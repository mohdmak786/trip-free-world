<?php 
include"include/config.php";
include"include/menu.php";

error_reporting(0);

if(isset($_GET['id'])) {
  $get_id = mysqli_real_escape_string($conn,$_GET['id']);
  $q="SELECT * FROM category WHERE id='$get_id'";
  $r=mysqli_query($conn,$q);
  $col=mysqli_fetch_array($r);
    $cat_name = $col['title']; 
    $old_img = $col['image'];
    $sort = $col['sort'];
    $des = $col['des'];
    $meta = $col['meta'];
    $status = $col['status'];

?>
<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
      <div class="card">
           <div class="card-header">Update Category</div>
           <div class="card-body">
           <hr>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group row">
          <label for="input-26" class="col-sm-2 col-form-label">Category Name</label>
          <div class="col-sm-10">
            <input type="text" name="title" class="form-control" value="<?=$cat_name;?>">
          </div>
          </div>
          
        <div class="form-group row">
          <label for="input-8" class="col-sm-2 col-form-label">Image</label>
          <div class="col-sm-4">
            <input type="file" class="form-control" name="image">
          </div>
          <div class="col-sm-4">
            <img src="assets/images/<?=$old_img;?>" style="width:100px;">
          </div>
        </div>
        
        <div class="form-group row">
          <label for="input-8" class="col-sm-2 col-form-label">Descrption</label>
          <div class="col-sm-10">
            <textarea class="form-control" name="des" id="summernoteEditor"><?=$des;?></textarea>
          </div>
        </div>

        <!-- <div class="form-group row">
          <label for="input-8" class="col-sm-2 col-form-label">Meta Tags (SEO)</label>
          <div class="col-sm-10">
            <textarea class="form-control" name="meta" id="summernoteEditor1"><?=strip_tags($meta);?></textarea>
          </div>
        </div> -->

          <div class="form-group row">
            <label for="input-26" class="col-sm-2 col-form-label">Sort Number</label>
            <div class="col-sm-4">
              <input type="text" name="sort" class="form-control" value="<?=$sort;?>">
            </div>

            <label for="input-26" class="col-sm-1 col-form-label">Status</label>
            <div class="col-sm-5">
              <select name="status" class="form-control" required="">
                <?php 
                  if($status=="Active") {
                    echo "<option selected>Active</option>
                        <option>Deactive</option>";
                  }
                  else {
                    echo "<option>Active</option>
                        <option selected>Deactive</option>";
                  }
                ?>
              </select>
            </div>
          </div>

           <div class="form-group row">
          <label class="col-sm-2 col-form-label"></label>
          <div class="col-sm-10">
          <button name="Category_update" type="submit" class="btn btn-dark btn-round px-5"><i class="icon-lock"></i>Submit</button>
          </div>
          </div>
           </form>
         </div>
        </div>
      </div>
      </div>
    </div>
      <?php

if(isset($_POST['Category_update']))
{
  $title=$_POST['title'];
  $des = mysqli_real_escape_string($conn,$_POST['des']);
  $meta = mysqli_real_escape_string($conn,$_POST['meta']);
  $sort=mysqli_real_escape_string($conn,$_POST['sort']);
  $status=mysqli_real_escape_string($conn,$_POST['status']);
   
  $image_name = $_FILES['image']['name'];
  $final_img = time().$image_name;
  $image_tmp = $_FILES['image']['tmp_name'];
  $logo_path = "assets/images/".$final_img;
  $old_img = $col['image'];

  $extensions_arr = array("jpg","jpeg","png","gif","webp");
  $file_extension = pathinfo($image_name, PATHINFO_EXTENSION);
  
  if($image_name) {
    if(in_array($file_extension,$extensions_arr)) {
      unlink('assets/images/'.$old_img);
      move_uploaded_file($image_tmp, $logo_path);
    }
    else {
      echo "<script>
          alert('Image Should be Valid Extension');
          window.location='insert_category.php?id=".$get_id."';
        </script>";
      exit;
    } 
  }
  else {
    $final_img=$old_img;
  }

  $sql="UPDATE `category` SET `title`='$title',`image`='$final_img',`des`='$des',`meta`='$meta',`sort`='$sort',`status`='$status' WHERE id='$get_id'"; 
  $query=mysqli_query($conn,$sql) or die(mysqli_error($conn));  
  if($query)
  {
	move_uploaded_file($image_tmp,$logo_path);
    echo "<script>alert('Update Succesfull');window.location='category_table.php';</script>";
  }
}
        
}
else {
?>
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">

			<div class="row">
			<div class="col-lg-12">
			<div class="card">
				   <div class="card-header">
              <a href="category_table.php" class="btn btn-success" style="float:right;">All Category</a>
              Insert Category
            </div>
           <div class="card-body">
				   <hr>
				<form action="" method="POST" enctype="multipart/form-data">
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Category Name</label>
					<div class="col-sm-10">
					 	<input type="text" name="title" class="form-control">
					</div>
				  </div>
				  
					<div class="form-group row">
	                  <label for="input-8" class="col-sm-2 col-form-label">Image (<abbr title="Image Format Should be jpg,jpeg,png,gif">Format</abbr>)</label>
	                  <div class="col-sm-4">
	                    <input type="file" class="form-control" name="image" required>
	                  </div>
	                </div>

	                <div class="form-group row">
	                  <label for="input-8" class="col-sm-2 col-form-label">Descrption</label>
	                  <div class="col-sm-10">
	                    <textarea class="form-control" name="des" id="summernoteEditor"></textarea>
	                  </div>
	                </div>

	                <!-- <div class="form-group row">
	                  <label for="input-8" class="col-sm-2 col-form-label">Meta Tags (SEO)</label>
	                  <div class="col-sm-10">
	                    <textarea class="form-control" name="meta" id="summernoteEditor1"></textarea>
	                  </div>
	                </div> -->

	              <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Sort Number</label>
					<div class="col-sm-4">
					 	<input type="text" name="sort" class="form-control">
					</div>

					<label for="input-26" class="col-sm-1 col-form-label">Status</label>
					<div class="col-sm-5">
					 	<select name="status" class="form-control" required="">
					 		<!-- <option>--Select Status--</option> -->
					 		<option>Active</option>
					 		<option>Deactive</option>
					 	</select>
					</div>
				  </div>

	                <div class="form-group row">
						<label class="col-sm-2 col-form-label"></label>
						<div class="col-sm-10">
							<button name="Product_submit" type="submit" class="btn btn-dark btn-round px-5"><i class="icon-lock"></i>Submit</button>
						</div>
					</div>
	                	
				  </div>			  
					 
				   
				   </form>
				 </div>
				</div>
			</div>
			</div>
			<?php

if(isset($_POST['Product_submit']))
{
    $title=mysqli_real_escape_string($conn,$_POST['title']);
    $des = mysqli_real_escape_string($conn,$_POST['des']);
    $meta = mysqli_real_escape_string($conn,$_POST['meta']);
    $sort=mysqli_real_escape_string($conn,$_POST['sort']);
    $status=mysqli_real_escape_string($conn,$_POST['status']);
	 
	$image_name = $_FILES['image']['name'];
	$final_img = time().$image_name;
	$image_tmp = $_FILES['image']['tmp_name'];
	$logo_path = "assets/images/".$final_img;

  $extensions_arr = array("jpg","jpeg","png","gif","webp");
  $file_extension = pathinfo($image_name, PATHINFO_EXTENSION);

  if(in_array($file_extension,$extensions_arr)) {
    if ($image_name!="") {
    	$sql="INSERT INTO `category`(`title`,`image`,`sort`,`des`,`meta`,`status`) VALUES ('$title','$final_img','$sort','$des','$meta','$status')";
    	$query=mysqli_query($conn,$sql) or die(mysqli_error($conn));
    	if($query)
    	{
    		move_uploaded_file($image_tmp,$logo_path);
    		 echo("<script>alert('Insert succesfully');window.location='category_table.php';</script>");
    	}
    }
  }
  else {
    echo("<script>alert('Image Should be Valid Extension');</script>");
  }

}

?>

<?php } ?>	

<?php include"include/footer.php"?>
		</div>	
	