<?php 
include"include/config.php";
include"include/menu.php";
error_reporting(0);
if(isset($_GET['id'])) {
  $get_id = mysqli_real_escape_string($conn,$_GET['id']);
  $q="SELECT * FROM `category` WHERE `id`='$get_id'";
  $r=mysqli_query($conn,$q);
  $col=mysqli_fetch_assoc($r);
    $fetch_img = $col['image'];    

  $query = "DELETE FROM `category` WHERE `id`= '$get_id'";
  $delte_query = mysqli_query($conn, $query);
  if ($delte_query) {
    unlink("assets/images/".$fetch_img);
    echo "<script>window.location='category_table.php'</script>";
  }
}

// DELETE THROUGH MULTIPLE CHECKBOX
if(isset($_POST['delete_row'])) {
  $checkarr = $_POST['checkbox'];
  foreach($checkarr as $value) {
    $select="SELECT * FROM `category` WHERE `id`='$value'";
    $query=mysqli_query($conn,$select);
    $row=mysqli_fetch_assoc($query);
      $fetch_img = $row['image'];

    $select1 = "DELETE FROM `category` WHERE `id`='$value'";
    $query1 = mysqli_query($conn,$select1) or mysqli_error($conn);
    if($query1) {
      unlink("assets/images/".$fetch_img);
      echo "<script>window.location='category_table.php'</script>";
    }
  }
}

?>
<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">

      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
              <i class="fa fa-table"></i> All Category
              <a href="insert_category.php" class="btn btn-success" style="float:right;">Add Category</a>
            </div>
            <div class="card-body">
              <form method="post">
                <!-- <input type="submit" name="delete_row" class="btn btn-danger float-right" value="Delete Row"> -->
              <div class="table-responsive">
              <table id="" class="table table-bordered">
                <thead>
                    <tr>
                         <th>S.No.</th>
                         <th>Name</th>
                        <th>Image</th>
                        <th>Order No.</th>
                        <th>Status</th>
                        <th>Action</th>
                        <!-- <th><input type="checkbox" name="select_all" id="select_all"> All</th> -->
                    </tr>
                </thead>
                <tbody>
        
         <?php 
    $i = 1;
    $query = "SELECT * FROM `category` order by id DESC";
    $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
        while ($row = mysqli_fetch_array($Product_data))
      {
        $id=$row['id'];
        $title=$row['title'];
        $img=$row['image'];
        $sort=$row['sort'];
        $status=$row['status'];
?>
                    <tr>
                        <td><?=$i++;?>
                        <td><?php echo $title; ?></td>
                        <td><img src="assets/images/<?php echo $img;?>" style="width:100px;height:50px; object-fit: contain;"></td>
                        <td><?php echo $sort; ?></td>
                        <td>
                          <?php
                            if($status=="Active") {
                              echo "<span class='badge badge-success'>Active</span>";
                            }
                            else {
                              echo "<span class='badge badge-danger'>Deactive</span>";
                            }
                          ?>
                        </td>
                    <?php echo'
                        <td><a href="insert_category.php?id='.$id.'"><i class="fa fa-pencil"></i></a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                    <a href="#" onclick="delete_confirm('.$id.')"><i class="fa fa-trash-o"></a></td>
                    </td>
                      <!-- <td>
                        <input type="checkbox" name="checkbox[]" value="'.$id.'">
                      </td> -->
                    </tr>';
              
}
  
  ?>   
                    
                </tbody>
            </table>
            </div>
              </form>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
      </div>

<?php include"include/footer.php"?>
    </div>

    <script>
function delete_confirm(id) {
    if (confirm("Do You want a Delete!") == true) {
        window.location='category_table.php?id='+id+''; // not sure which link should be placed here
        return true;
    } else {
        window.location="";
        return true;
    }
    document.getElementById("demo").innerHTML = x;
}
</script>