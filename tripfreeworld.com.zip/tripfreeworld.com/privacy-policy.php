<!doctype html>
<html lang="en">
	
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<title>Privacy Policy- Trip Free World Tour & Travels</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-touch-fullscreen" content="yes">
		<meta name="HandheldFriendly" content="True">
		
		 <!--General Meta Start-->
    	<meta name="description" content="The Privacy Policy document contains types of information that are collected and recorded by Trip Free World."/>
        <meta name="keywords" content=" contact tour and travel,Contact tour and travel in srinagar,"/>
	    <meta name="author" content="Tour and Travels"/>
	    <meta name="robots" content="index, follow" />
	    <meta name="distribution" content="global" />
	    <meta name="coverage" content="india" />
	    <meta name="object" content="document"/>
	    <meta name="audience" content="All" />
	    <meta name="revisit-after" content="1 day"/>
	    <meta name="language" content="en"/>
	    <meta name="rating" content="general"/>
     	<meta name="copyright" content="Copyright Trip Free World 2023"/>
	<!--General Meta End-->
	
	  <!--OG Meta Start-->
	    <meta property="og:type" content="website" />
    	<meta property="og:title" content="Privacy Policy- Trip Free World Tour & Travels" />
    	<meta property="og:url" content="https://www.tripfreeworld.com/privacy-policy" /> 
    	<meta property="og:description" content="The Privacy Policy document contains types of information that are collected and recorded by Trip Free World." />
    	<meta property="og:image" content="https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp" />
    	<!--OG Meta end-->
		
		  <!--canonical tag-->
            <link rel="canonical" href="https://www.tripfreeworld.com/privacy-policy"/>
     
      
             <!---Schema marhup start--->
             <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Trip Free World",
  "image": "https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp",
  "url": "https://www.tripfreeworld.com/",
  "telephone": "+91 9906830446",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Naidkhai, Amberhrah Sopore, Parraypora",
    "addressLocality": "Srinagar",
    "postalCode": "193501",
    "addressCountry": "IN"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 34.2867629,
    "longitude": 74.4624013
  },
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday"
    ],
    "opens": "00:00",
    "closes": "23:59"
  } 
}
</script>
		
		
        <?php include "include/header-file.php"?>
        
	</head>
	<body class="default" style="background-color: lightblue;">

        <?php include "include/header.php"?>

        <section>
            <style>
            .privacy{
                margin-top:140px;
            }
                @media only screen and (max-width: 600px) {
                    .privacy{
                               margin-top:90px;
                         }
                           }
                   
            </style>
            <div class="container privacy">
                <div class="row">
                    <div class="col-12">
                        <h1><strong>Privacy Policy for Trip Free World</strong></h1>

                            <p>At Trip Free World, accessible from https://www.tripfreeworld.com, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that are collected and recorded by Trip Free World and how we use it.</p>
                            
                            <p>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.</p>
                            
                            <p>This Privacy Policy applies only to our online activities and is valid for visitors to our website with regards to the information that they shared and/or collect in Trip Free World. This policy is not applicable to any information collected offline or via channels other than this website.</p>
                            
                            <h2>Consent</h2>
                            
                            <p>By using our website, you hereby consent to our Privacy Policy and agree to its terms.</p>
                            
                            <h3>Information we collect</h3>
                            
                            <p>The personal information that you are asked to provide, and the reasons why you are asked to provide it, will be made clear to you at the point we ask you to provide your personal information.</p>
                            <p>If you contact us directly, we may receive additional information about you such as your name, email address, phone number, the contents of the message and/or attachments you may send us, and any other information you may choose to provide.</p>
                            
                            <p>When you register for an Account, we may ask for your contact information, including items such as name, company name, address, email address, and telephone number.</p>

                            <h3>How we use your information</h3>
                            
                            <p>We use the information we collect in various ways, including to:</p>
                            
                            <ul>
                            <li>Provide, operate, and maintain our website</li>
                            <li>Improve, personalize, and expand our website</li>
                            <li>Understand and analyze how you use our website</li>
                            <li>Develop new products, services, features, and functionality</li>
                            <li>Communicate with you, either directly or through one of our partners, including for customer service, to provide you with updates and other information relating to the website, and for marketing and promotional purposes</li>
                            <li>Send you emails</li>
                            <li>Find and prevent fraud</li>
                            </ul>
                            
                            <h3>Log Files</h3>
                            <p>Trip Free World follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this and a part of hosting services' analytics. The information collected by log files include internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any information that is personally identifiable. The purpose of the information is for analyzing trends, administering the site, tracking users' movement on the website, and gathering demographic information.</p>
                            <h3>Advertising Partners Privacy Policies</h3>
                            
                            <P>You may consult this list to find the Privacy Policy for each of the advertising partners of Trip Free World.</p>
                            
                            <p>Third-party ad servers or ad networks uses technologies like cookies, JavaScript, or Web Beacons that are used in their respective advertisements and links that appear on Trip Free World, which are sent directly to users' browser. They automatically receive your IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit.</p>
                            
                            <p>Note that Trip Free World has no access to or control over these cookies that are used by third-party advertisers.</p>
                            
                            <h3>Third Party Privacy Policies</h3>
                            <p>Trip Free World's Privacy Policy does not apply to other advertisers or websites. Thus, we are advising you to consult the respective Privacy Policies of these third-party ad servers for more detailed information. It may include their practices and instructions about how to opt-out of certain options. </p>

                            <p>You can choose to disable cookies through your individual browser options. To know more detailed information about cookie management with specific web browsers, it can be found at the browsers' respective websites.</p>
                            
                            <h3>CCPA Privacy Rights (Do Not Sell My Personal Information)</h3>
                            
                            <p>Under the CCPA, among other rights, California consumers have the right to:</p>
                            <p>Request that a business that collects a consumer's personal data disclose the categories and specific pieces of personal data that a business has collected about consumers.</p>
                            <p>Request that a business delete any personal data about the consumer that a business has collected.</p>
                            <p>Request that a business that sells a consumer's personal data, not sell the consumer's personal data.</p>
                            <p>If you make a request, we have one month to respond to you. If you would like to exercise any of these rights, please contact us.</p>
                            
                            <h3>GDPR Data Protection Rights</h3>
                            
                            <p>We would like to make sure you are fully aware of all of your data protection rights. Every user is entitled to the following:</p>
                            <p>The right to access – You have the right to request copies of your personal data. We may charge you a small fee for this service.</p>
                            <p>The right to rectification – You have the right to request that we correct any information you believe is inaccurate. You also have the right to request that we complete the information you believe is incomplete.</p>
                            <p>The right to erasure – You have the right to request that we erase your personal data, under certain conditions.</p>
                            <p>The right to restrict processing – You have the right to request that we restrict the processing of your personal data, under certain conditions.</p>
                            <p>The right to object to processing – You have the right to object to our processing of your personal data, under certain conditions.</p>
                            <p>The right to data portability – You have the right to request that we transfer the data that we have collected to another organization, or directly to you, under certain conditions.</p>
                            <p>If you make a request, we have one month to respond to you. If you would like to exercise any of these rights, please contact us.</p>
                            
                            <h3>Children's Information</h3>
                            
                            <p>Another part of our priority is adding protection for children while using the internet. We encourage parents and guardians to observe, participate in, and/or monitor and guide their online activity.</p>
                            
                            <p>Trip Free World does not knowingly collect any Personal Identifiable Information from children under the age of 13. If you think that your child provided this kind of information on our website, we strongly encourage you to contact us immediately and we will do our best efforts to promptly remove such information from our records.</p>
                            <h3>Changes to This Privacy Policy</h3>

                                <p>We may update our Privacy Policy from time to time. Thus, we advise you to review this page periodically for any changes. We will notify you of any changes by posting the new Privacy Policy on this page. These changes are effective immediately after they are posted on this page.</p>
                                
                                <h3>Contact Us</h3>
                                
                                <p>If you have any questions or suggestions about our Privacy Policy, do not hesitate to contact us.</p>






                    </div>
                </div>
            </div>
        </section>
        
        
   
			<?php include "include/footer.php"?>
    </body>
  
  
</html>