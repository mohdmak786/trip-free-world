<?php 
include"include/config.php";
include"include/menu.php";
?>
<style>
.note-editor.note-frame .note-editing-area .note-editable {
	height: 250px !important;
}
</style>
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">

			<div class="row">
			<div class="col-lg-12">
			<div class="card">
				   <div class="card-body">
				   <a href="track_table.php" class="btn btn-success float-right">All Items</a>
				   <div class="card-title">Insert Track Items</div>
				   <hr>
				<form method="POST" enctype="multipart/form-data">
				   <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Reffrence No.</label>
					<div class="col-sm-10">
					<input type="text" name="reff" class="form-control form-control" placeholder="Enter Unique Reff.">
					</div>
				  </div>
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Date</label>
					<div class="col-sm-4">
					<input type="text" name="date" class="form-control form-control" placeholder="Select Date">
					</div>
				  </div>
				  
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Location From</label>
					<div class="col-sm-10">
					<input type="text" name="from" class="form-control form-control" placeholder="From..">
					</div>
				  </div>
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Location To</label>
					<div class="col-sm-10">
					<input type="text" name="to" class="form-control form-control" placeholder="To..">
					</div>
				  </div>
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Type of Goods</label>
					<div class="col-sm-10">
					<input type="text" name="type" class="form-control form-control" placeholder="Type of Goods">
					</div>
				  </div>
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Current Location</label>
					<div class="col-sm-10">
					<input type="text" name="location" class="form-control form-control" placeholder="Current Location">
					</div>
				  </div>
					
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Expectation Date</label>
					<div class="col-sm-4">
					<input type="text" name="exp_date" class="form-control form-control" placeholder="Expecation Date">
					</div>
				  </div>
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Remarks </label>
					<div class="col-sm-10">
						<input type="text" name="status" class="form-control form-control" placeholder="Status...">
					</div>
				  </div>
				
				   <div class="form-group row">
					<label class="col-sm-2 col-form-label"></label>
					<div class="col-sm-10">
					<button name="About_submit" type="submit" class="btn btn-white btn-round px-5"><i class="icon-lock"></i> Submit</button>
					</div>
				  </div>
				   </form>
				 </div>
				</div>
			</div>
			</div>
			<?php

if(isset($_POST['About_submit']))
{
    $reff=mysqli_real_escape_string($conn,$_POST['reff']);
    $date=mysqli_real_escape_string($conn,$_POST['date']);
    $from=mysqli_real_escape_string($conn,$_POST['from']);
    $to=mysqli_real_escape_string($conn,$_POST['to']);
    $type=mysqli_real_escape_string($conn,$_POST['type']);
    $location=mysqli_real_escape_string($conn,$_POST['location']);
	$exp_date = mysqli_real_escape_string($conn,$_POST['exp_date']);
    $status=mysqli_real_escape_string($conn,$_POST['status']);
	
	$sql="INSERT INTO `track`(`reff`, `date`, `order_from`, `order_to`, `type`, `location`,`exp_date`, `status`) VALUES ('$reff','$date','$from','$to','$type','$location','$exp_date','$status')";
	$query=mysqli_query($conn,$sql) or die(mysqli_error($conn));
	if($query)
	{
		 echo("<script>alert('Insert succesfully');window.location='track_table.php';</script>");
	}
	else
	{
		echo("<script>alert('Not Inserted');window.location='insert_track.php';</script>");
	}

}
?>		
<?php include"include/footer.php"?>
		</div>
		
 
		
	