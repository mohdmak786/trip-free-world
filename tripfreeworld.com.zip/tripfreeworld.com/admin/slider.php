<?php 
include"include/menu.php";

if(isset($_GET['id'])) {
	$get_id = mysqli_real_escape_string($conn,$_GET['id']);
	$select1 = "SELECT * FROM banner WHERE id='$get_id'";
    $query1 = mysqli_query($conn,$select1);
    $row1 = mysqli_fetch_array($query1);
	$id = $row1['id'];
	$old_img = $row1['image'];
	$head = $row1['head'];
	$des = $row1['des'];
?>
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">

	<div class="row">
	<div class="col-lg-12">
	<div class="card">
		   <div class="card-header">Slider Update
		   	<a href="slider_display.php" class="btn btn-success" style="float:right;">All Slider</a>
		   </div>
		   <div class="card-body">

		   <hr>
		   	 <?php 		 
			$db = $GLOBALS['conn'];
			?>
		<form action="" method="POST" enctype="multipart/form-data">
						 
		  <div class="form-group row">
	          <label for="input-8" class="col-sm-2 col-form-label">Image (<abbr title="Image Format Should be jpg,jpeg,png,gif">Format</abbr>)</label>
	          <div class="col-sm-4">
	            <input type="file" class="form-control" name="image" id="validImage" onchange="return fileValidation()">
	          </div>
	          <div class="col-sm-4">
	          		<img src="assets/images/slider/<?=$old_img;?>" style="height:60px;">
	          </div>
	        </div>


            <div class="form-group row">
              <label for="input-8" class="col-sm-2 col-form-label">Heading</label>
              <div class="col-sm-6">
                <input type="text" class="form-control" name="head" value="<?=$head;?>">
              </div>
            </div>
            <div class="form-group row">
              <label for="input-8" class="col-sm-2 col-form-label">Heading</label>
              <div class="col-sm-6">
                <input type="text" class="form-control" name="des" value="<?=$des;?>">
              </div>
            </div>
        
		   <div class="form-group row">
			<label class="col-sm-2 col-form-label"></label>
			<div class="col-sm-10">
			<button name="Product_update" type="submit" class="btn btn-dark btn-round px-5"><i class="icon-lock"></i>Submit</button>
			</div>
		  </div>
		   </form>
			<?php // } ?>
		 </div>
		</div>
	</div>
	</div>
<?php
if(isset($_POST['Product_update'])) {
	$image_name1 = $_FILES['image']['name'];
	$final_img1 = time().$image_name1;
	$image_type1 = $_FILES['image']['type'];
	$image_size1 = $_FILES['image']['size'];
	$image_tmp1 = $_FILES['image']['tmp_name'];
	$logo_path1 = "assets/images/slider/".$final_img1;	

	$head=mysqli_real_escape_string($conn,$_POST['head']); 
	$des=mysqli_real_escape_string($conn,$_POST['des']); 

	$extensions_arr = array("jpg","jpeg","png","gif","webp");
	$file_extension = pathinfo($image_name1, PATHINFO_EXTENSION);

	if($image_name1) {
		if(in_array($file_extension,$extensions_arr)) {
			unlink('assets/images/slider/'.$old_img);
			move_uploaded_file($image_tmp1, $logo_path1);
		}
		else {
			echo "<script>
					alert('Image Should be Valid Extension');
					window.location='slider.php?id=".$get_id."';
	 			</script>";
	 		exit;
		}	
	}
	else {
		$final_img1=$old_img;
	}
	$sqlu="UPDATE banner SET `image`='$final_img1',`head`='$head',`des`='$des' WHERE id='$get_id'";
	$queryu=mysqli_query($conn,$sqlu) or die(mysqli_error($conn));			       
	if ($queryu) {			    			
	    echo("<script>alert('Update Successfull');
	    	window.location='slider_display.php';</script>");
		//}
	}
}
}	
else {
?>
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">

			<div class="row">
			<div class="col-lg-12">
			<div class="card">
			   <div class="card-header">Image Form
			   	<a href="slider_display.php" class="btn btn-success" style="float:right;">All Slider</a>
			   </div>
				<div class="card-body">

				   <hr>
				   	 <?php 
				 
					$db = $GLOBALS['conn'];
					?>
				<form action="" method="POST" enctype="multipart/form-data">
								 
				  <div class="form-group row">
	                  <label for="input-8" class="col-sm-2 col-form-label">Image</label>
	                  <div class="col-sm-4">
	                    <input type="file" class="form-control" name="image" required>
	                  </div>
	                </div>

	                <div class="form-group row">
	                  <label for="input-8" class="col-sm-2 col-form-label">Heading</label>
	                  <div class="col-sm-10">
	                    <input type="text" class="form-control" name="head">
	                  </div>
	                </div>
                
				   <div class="form-group row">
					<label class="col-sm-2 col-form-label"></label>
					<div class="col-sm-10">
					<button name="Product_submit" type="submit" class="btn btn-dark btn-round px-5"><i class="icon-lock"></i>Submit</button>
					</div>
				  </div>
				   </form>
					<?php // } ?>
				 </div>
				</div>
			</div>
			</div>
<?php
if(isset($_POST['Product_submit']))
{
   
   $head=mysqli_real_escape_string($conn,$_POST['head']);

	$image_name1 = $_FILES['image']['name'];
	$final_img1 = time().$image_name1;
	$image_type1 = $_FILES['image']['type'];
	$image_size1 = $_FILES['image']['size'];
	$image_tmp1 = $_FILES['image']['tmp_name'];
	$logo_path1 = "assets/images/slider/".$final_img1;

	$extensions_arr = array("jpg","jpeg","png","gif","webp");
	$file_extension = pathinfo($image_name1, PATHINFO_EXTENSION);	
	
	if(in_array($file_extension,$extensions_arr)) {
		if ($image_name1!="")
		{
			$sqlu="INSERT INTO banner (`image`,`head`) VALUES ('$final_img1','$head')";
			$queryu=mysqli_query($conn,$sqlu) or die(mysqli_error($conn));			       
			if ($queryu) {			    				
				move_uploaded_file($image_tmp1, $logo_path1);
			    echo("<script>alert('Update succesfully');window.location='slider_display.php';</script>");
			}
		}
	}
	else {
		echo("<script>alert('Image Should be Valid Extension');</script>");
	}
}
}   // ELSE CONDITION CLOSED	
?>


<?php include"include/footer.php"?>

</div>
		
 
		
	