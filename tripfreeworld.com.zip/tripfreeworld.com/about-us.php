<!doctype html>
<html lang="en">
	
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<title>About us - Trip Free World | Kashmir Trip Planner</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-touch-fullscreen" content="yes">
		<meta name="HandheldFriendly" content="True">
		
		 <!--General Meta Start-->
    	<meta name="description" content="Trip Free World is the best taxi service provider in Jammu kashmir from all over india | Best tour Operator"/>
        <meta name="keywords" content="About us trip free tour and travel, About Tour and travel, tour and travel"/>
	    <meta name="author" content="Tour and Travels"/>
	    <meta name="robots" content="index, follow" />
	    <meta name="distribution" content="global" />
	    <meta name="coverage" content="india" />
	    <meta name="object" content="document"/>
	    <meta name="audience" content="All" />
	    <meta name="revisit-after" content="1 day"/>
	    <meta name="language" content="en"/>
	    <meta name="rating" content="general"/>
     	<meta name="copyright" content="Copyright Trip Free World 2023"/>
	     <!--General Meta End-->
	    
    	<!--OG Meta Start-->
    	<meta property="og:type" content="website" />
    	<meta property="og:title" content="About us - Trip Free World Jammu and Kashmir" />
    	<meta property="og:url" content="https://www.tripfreeworld.com/about-us" />
    	<meta property="og:description" content="Explore Kashmir with us, Memorable trips in paradise, Journey through scenic Kashmir, Kashmir travel made easy." />
    	<meta property="og:image" content="https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp" />
    	<!--OG Meta end-->
    	
	   
		
		  <!--canonical tag-->
            <link rel="canonical" href="https://www.tripfreeworld.com/about-us"/>

        
             
             <!---Schema marhup start--->
            <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Trip Free World",
  "image": "https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp",
  "url": "https://www.tripfreeworld.com/",
  "telephone": "+91 9906830446",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Naidkhai, Amberhrah Sopore, Parraypora",
    "addressLocality": "Srinagar",
    "postalCode": "193501",
    "addressCountry": "IN"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 34.2867629,
    "longitude": 74.4624013
  },
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday"
    ],
    "opens": "00:00",
    "closes": "23:59"
  } 
}
</script>
        <?php include "include/header-file.php"?>
        
	</head>
	<body class="default">

        <?php include "include/header.php"?>

      <!-- Content  -->
      <div id="content">
        <div class="content-wrap page-destination-list">
          <div class="subsite-banner">
            <img src="img/subsite-banner-33333.jpg" alt="banner image">
          </div>
          <div class="subsite subsite-with-banner">
            
            
					<!-- Content  -->
                    <div id="content">
                        <div class="content-wrap">
                            <div class="container subsite">
                                <div class="row">
                                    <div class="col-md-12 pb-3">
                                        <h1 class="subsite-heading">
                                            About Us
                                        </h1>
                                        <h2 class="subsite-heading">Trip Free World Tour & Travels</h2>
                                    </div>
                                    <div class="col-md-6">
                                 <img src="<?=$site_url?>admin/assets/images/logo/<?=$About_rows['image']?>" alt="image" class="border-radius">
                                    </div>
                                    <div class="col-md-6">
                                   
                                   <p style="text-align:justify;">You can choose from a variety of packages from Kashmir Tour Operator, including package tours, adventure tours, and yatra tours, allowing you to book your ideal vacation in a matter of clicks from the comfort of your own home.The top app is Trip Free World. Srinagar-based tour operators for Kashmir Jammu and Kashmir's state of Kashmir is not the only place in India where Kashmir is a well-known brand in the travel and tourist sector. Additionally, Trip Free World has received excellent reviews on Google.
Your Kashmir vacation will be one to remember thanks to the assistance of our knowledgeable travel specialists, who will assist you with every aspect of your trip and give you the best Kashmir Tour package to suit your needs. 
Check out our Google reviews to see what our valued customers have to say about us as the top Kashmir tourism tour operator in Kashmir. Our staff is made up of highly skilled experts with extensive knowledge of the hospitality and tourism sectors. The group is dedicated to building a network with good public relations, appropriate obligations, and prompt delivery. Trip Free World, a company that offers fully led unique group trips as well as fully tailored private individual tours, specialized in catering to your discerning travel preferences.
Trip Free World, which was founded in 2008, provides tourists with unmatched service, ensuring that their trip is luxury. Being one of the largest travel companies in northern India, we take great pride in earning accolades for offering comprehensive services to our clients. 
</p>
                                     </div>
                                     
                                     <div class="col-md-12">
                                         <p style="text-align:justify;">
                                             With a head office in Srinagar, Kashmir, we can service a huge number of tourists in Jammu and Kashmir, but we also have satellite offices in Jammu and Ladakh that can help our visitors in all three of these locations so they won't encounter any problems.
In order to help you choose which tour package is best for you, we have created detailed itineraries for each one that include day-by-day travel plans, hotel details, and other services that are included in day trips. In addition, you can view comprehensive information about the top tourist attractions in Jammu and Kashmir. Along with information about Gulmarg, Phalagam, Sonamarg, Srinagar, Jammu, Katra, Patnitop, Leh, and Ladakh, you can also look for top-rated hotels in Kashmir that we recommend booking while you are in Srinagar.
With services like Same Day Srinagar Tour, Romanchak Kashmir Air InclusiveTour Package, Vaishno Devi Tour, Kashmir Extravaganza With Vaishno Devi, Honeymoon Kashmir Magic Moments with Gulmarg Excursions, Kashmir Tulip Package, Best of Kashmir With Gulmarg Excursion, Mystical Leh Ladakh, and others, we provide the best and most individualized services. All services are provided when you travel with us, so you are free to take in the beauty all around you and be warmly welcomed by people who have not forgotten to preserve the integrity of our natural environment. Through careful planning, we provide our clients with the best services possible.
Information on Kashmir's tourist attractions, forts and palaces, historical sites, and monuments is available from our tour and travel company. Wildlife tours and pilgrimage trip packages are available in Jammu & Kashmir to make travel there more convenient and pleasurable. From Delhi, Mumbai, Hyderabad, Gujarat, Chandigarh, West Bengal, Tamil Nadu, and other Indian states, we provide a range of travel alternatives to Kashmir.
                                         </p>
                                     </div>
                                     
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- .Content  -->
            
            
    <iframe src="<?=$About_rows['map']?>" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  
            
          </div>
          
        </div>
      </div>
      <!-- .Content  -->
      
			<?php include "include/footer.php"?>
    </body>
  
  
</html>