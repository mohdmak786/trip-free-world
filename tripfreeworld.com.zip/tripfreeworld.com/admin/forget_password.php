<?php
include"include/config.php";
session_start();
include"include/function.php";

$select_about = "SELECT * FROM about";
$query_about = mysqli_query($conn,$select_about);
$row_about = mysqli_fetch_array($query_about);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <title>Forget Password - <?=$row_about['title'];?></title>
  <!--favicon-->
  <link rel="icon" href="assets/images/logo/<?=$row_about['logo'];?>" type="image/x-icon">
  <!-- Bootstrap core CSS-->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="assets/css/app-style.css" rel="stylesheet"/>
  
</head>

<body class="bg-theme bg-theme2">

<!-- start loader -->
   <div id="pageloader-overlay" class="visible incoming"><div class="loader-wrapper-outer"><div class="loader-wrapper-inner" ><div class="loader"></div></div></div></div>
   <!-- end loader -->

<!-- Start wrapper-->
 <div id="wrapper" style="margin-top: 150px;">

 <div class="loader-wrapper"><div class="lds-ring"><div></div><div></div><div></div><div></div></div></div>
	<div class="card card-authentication1 mx-auto my-5">
		<div class="card-body">
		 <div class="card-content p-2">
		 	<div class="text-center">
		 		<img style="background: white;
height: 80px; padding: 15px;" src="assets/images/logo.png" alt="logo icon">
		 	</div>
		  <div class="card-title text-uppercase text-center py-3">Verify OTP</div>
		    <form method="POST">
			  <div class="form-group">
			  <label class="sr-only">Enter OTP</label>
			   <div class="position-relative has-icon-right">
				  <input type="text" name="email" class="form-control input-shadow" placeholder="Enter OTP" autocomplete="off">
				  <div class="form-control-position">
					  <i class="icon-user"></i>
				  </div>
			   </div>
			  </div>
			
			 <button type="submit" name="reset_password" class="btn btn-dark btn-block">Verify</button>
	 			<br>
	 			<p class="text-center"><a href="index.php">Go Back</a></p>
			 </form>
	 
		   </div>
		  </div>
		 
	     </div>



    
     <!--Start Back To Top Button-->
    
    <!--End Back To Top Button-->
	
	<!--start color switcher-->
   
  <!--end color cwitcher-->
	
	</div><!--wrapper-->
<footer class="footer" style="border-bottom: 1px solid rgba(255, 255, 255, 0.12);">
      <div class="container">
        <div class="text-center">
          Copyright © <?php echo date('Y')." " .$row_about['title'];?> | Designed & Developed By <a href="https://www.hyproweb.com/"> Hypro Web</a>
        </div>
      </div>
</footer> 
  <!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
	
  <!-- sidebar-menu js -->
  <script src="assets/js/sidebar-menu.js"></script>
  
  <!-- Custom scripts -->
  <script src="assets/js/app-script.js"></script>
  
</body>
</html>
