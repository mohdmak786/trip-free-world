<?php
session_start();
?>
<?php
include("include/config.php");

if(isset($_REQUEST['login_submit']))
{
    $a = $_REQUEST['email'];
    $b = $_REQUEST['password'];
    $res = mysqli_query($conn,"Select * FROM `admin` WHERE `email`='$a' AND `password`='$b'");
    $result=mysqli_fetch_array($res);
    if($result)
    {
	    $_SESSION["login"]=$a;
	    echo "<script>window.location='dashboard.php'</script>";
    }
    else
    {
        echo "<script>alert('Please Enter Valid Email or Password');window.location='index.php';</script>";
    }
}
else{
    echo "<script>alert('".$_REQUEST['login_submit']."Submit Button Not Clicked');window.location='index.php';</script>";
}
?>