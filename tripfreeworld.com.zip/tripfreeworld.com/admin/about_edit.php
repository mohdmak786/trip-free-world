<?php 
include"include/config.php";
include"include/menu.php";
?>
<?php
$get_id = mysqli_real_escape_string($conn,$_GET['id']);
$q="SELECT * FROM `about` WHERE `id`='$get_id'";
$r=mysqli_query($conn,$q);
$col=mysqli_fetch_assoc($r);
  	$title = $col['title'];
  	$des = $col['des'];
  	$phone = $col['phone'];
  	$phone2 = $col['phone2'];
  	$phone3 = $col['phone3'];
  	$email = $col['email'];
  	$address = $col['address'];
  	$address2 = $col['address2'];
  	$old_logo = $col['logo'];
  	$old_image = $col['image'];
  	$map = $col['map'];
?>
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">

			<div class="row">
			<div class="col-lg-12">
			<div class="card">
				   <div class="card-body">
				   <div class="card-title">About Us Update</div>
				   <hr>
				<form action="" method="POST" enctype="multipart/form-data">
				   <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Title</label>
					<div class="col-sm-10">
					<input type="text" name="title" value="<?=$title?>" class="form-control form-control" placeholder="Enter Your Name">
					</div>
				  </div>				
				
				  <div class="form-group row">
					<label for="input-29" class="col-sm-2 col-form-label">Description</label>
					<div class="col-sm-10">
					<textarea class="form-control" rows="3" name="des" placeholder="Paste HTML Iframe Map"><?=$des;?></textarea>
					</div>
				 </div>	
				  
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Phone No.</label>
					<div class="col-sm-10">
					<input type="text" name="phone" value="<?=$phone?>" class="form-control" placeholder="Enter Phone No.">
					</div>
				  </div>
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Phone No 2</label>
					<div class="col-sm-10">
					<input type="text" name="phone2" value="<?=$phone2?>" class="form-control" placeholder="Enter Alternate Phone No.">
					</div>
				  </div>
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Phone No 3</label>
					<div class="col-sm-10">
					<input type="text" name="phone3" value="<?=$phone3?>" class="form-control" placeholder="Enter Phone No.">
					</div>
				  </div>
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Email Id</label>
					<div class="col-sm-10">
					<input type="text" name="email" value="<?=$email?>" class="form-control" placeholder="Enter Your Email">
					</div>
				  </div>
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Address</label>
					<div class="col-sm-10">
					<textarea name="address" class="form-control" placeholder="Enter Your Address"><?=$address?></textarea>
					</div>
				  </div>
				  <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Address 2</label>
					<div class="col-sm-10">
					<textarea name="address2" class="form-control" placeholder="Enter Your Address"><?=$address2?></textarea>
					</div>
				  </div>
				  <div class="form-group row">
					<label for="input-29" class="col-sm-2 col-form-label">Map (Paste Iframe Tag)</label>
					<div class="col-sm-10">
					<textarea class="form-control" rows="3" name="map" placeholder="Paste HTML Iframe Map"><?=$map;?></textarea>
					</div>
				 </div>	


				  <div class="form-group row">				  
					<label for="input-26" class="col-sm-2 col-form-label">Website Logo</label>
					<div class="col-sm-4">
						<input type="file" name="logo" value="<?=$old_logo?>" class="form-control">
					</div>
					<div class="col-sm-4">
						<img src="assets/images/logo/<?=$old_logo?>" style="width:200px;">
					</div>
				  </div>
				  
				  <div class="form-group row">				  
					<label for="input-26" class="col-sm-2 col-form-label">About Image</label>
					<div class="col-sm-4">
						<input type="file" name="image" value="<?=$old_image?>" class="form-control">
					</div>
					<div class="col-sm-4">
						<img src="assets/images/logo/<?=$old_image?>" style="width:200px;">
					</div>
				  </div>
				 
				   <div class="form-group row">
					<label class="col-sm-2 col-form-label"></label>
					<div class="col-sm-10">
					<button name="About_update_submit" type="submit" class="btn btn-dark px-5"><i class="icon-lock"></i> Submit</button>
					</div>
				  </div>
				   
				   </form>
				 </div>
				</div>
			</div>
			</div>
			<?php

if(isset($_POST['About_update_submit']))
{
	$title=mysqli_real_escape_string($conn,$_POST['title']);
	$des=mysqli_real_escape_string($conn,$_POST['des']);
	$phone=mysqli_real_escape_string($conn,$_POST['phone']);
	$phone2=mysqli_real_escape_string($conn,$_POST['phone2']);
	$phone3=mysqli_real_escape_string($conn,$_POST['phone3']);
	$email=mysqli_real_escape_string($conn,$_POST['email']);
	$address=mysqli_real_escape_string($conn,$_POST['address']);
	$address2=mysqli_real_escape_string($conn,$_POST['address2']);
	$map=mysqli_real_escape_string($conn,$_POST['map']);

	$logo_name = $_FILES['logo']['name'];
	$final_logo = time().$logo_name;
	$logo_tmp = $_FILES['logo']['tmp_name'];
	$logo_path = "assets/images/logo/".$final_logo;
	
	$extensions_arr2 = array("jpg","jpeg","png","gif","webp");
	$file_extension2 = pathinfo($logo_name, PATHINFO_EXTENSION);

	// LOOG IMAGE FILTER
	if($logo_name) {
		if(in_array($file_extension2,$extensions_arr2)) {
			unlink('assets/images/logo/'.$old_logo);
			move_uploaded_file($logo_tmp, $logo_path);
		}
		else {
			echo "<script>
					alert('Image Should be Valid Extension');
					window.location='about_edit.php?id=".$get_id."';
	 			</script>";
	 		exit;
		}	
	}
	else {
		$final_logo=$old_logo;
	}
	
	$image_name = $_FILES['image']['name'];
	$final_image = time().$image_name;
	$image_tmp = $_FILES['image']['tmp_name'];
	$image_path = "assets/images/logo/".$final_image;
	
	$extensions_arr2 = array("jpg","jpeg","png","gif","webp");
	$file_extension2 = pathinfo($image_name, PATHINFO_EXTENSION);

	// LOOG IMAGE FILTER
	if($image_name) {
		if(in_array($file_extension2,$extensions_arr2)) {
			unlink('assets/images/logo/'.$old_image);
			move_uploaded_file($image_tmp, $image_path);
		}
		else {
			echo "<script>
					alert('Image Should be Valid Extension');
					window.location='about_edit.php?id=".$get_id."';
	 			</script>";
	 		exit;
		}	
	}
	else {
		$final_image=$old_image;
	}

 	$sql= "UPDATE `about` SET `title`='$title',`des`='$des',`phone`='$phone',`phone2`='$phone2',`phone3`='$phone3',`email`='$email', `address`='$address', `address2`='$address2',`logo`='$final_logo',`image`='$final_image',`map`='$map' WHERE id='$get_id' ";      
		 $run = mysqli_query($conn, $sql) or die(mysqli_error($conn)); 
		 if($run==true)
	{	    
		move_uploaded_file($logo_tmp, $logo_path);
		echo("<script>alert('update succesfully');window.location='about_table.php';</script>");
	}          
}

?>
<?php include"include/footer.php"?>
		</div>
		
 
		
	