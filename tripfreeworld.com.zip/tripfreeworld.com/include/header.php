

    <!-- Whatsapp and call now -->
	<a href="https://wa.me/91<?=$About_rows['phone'];?>" class="whatsapp-fixed" target="_blank">
        <img data-src="<?=$site_url?>img/whatsapp-icon.png" class="lazyload contact-whatsapp" alt="Whatsapp Icon">
    </a>
	<a href="tel:<?=$About_rows['phone'];?>" target="_blank" class="btn-sonar">
        <img class="lazyload" data-src="<?=$site_url?>img/call-icon.png" alt="Call Icon">
    </a>
			
			<header class="header">
    <nav class="navbar navbar-expand-lg navbar-light">
      <div class="container">
        <a class="navbar-brand" href="<?=$site_url?>">
          <img class="lazyload" data-src="<?=$site_url?>admin/assets/images/logo/<?=$About_rows['logo']?>" alt="Logo">
          <?=$About_rows['title']?>
        </a>
        <button class="navbar-toggler" name="Trip Free World Logo" aria-label="sidebar" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="<?=$site_url?>">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?=$site_url?>about-us">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?=$site_url?>tour">Tour Package</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?=$site_url?>destination">Destination</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?=$site_url?>car">Our Cars</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?=$site_url?>contact-us">Contact Us</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
  
  
  
<!-- The Modal -->
<div id="myModal" class="modal">
    <!-- Modal content -->
    <div class="modal-content">
        <div class="modal-header">
            <span class="close">&times;</span>
           Contact Us
        </div>
        <div class="modal-body">
            <span class="head">24x7 Assistance</span>
            <p>Talk to Tour Manager</p>
            <span class="call">Call <a href="tel:<?=$About_rows['phone']?>"><?=$About_rows['phone']?></a></span>
        </div>
    </div>
</div>
