<?php 
include"include/config.php";
include"include/menu.php";

?>
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">

			<div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> About Us</div>
            <div class="card-body">
              <div class="table-responsive">
              <table id="" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Phone</th>
                        <th>Phone 2</th>
                        <th>Phone 3</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Address 2</th>
                        <th>Map</th>
                        <th>Logo</th>
                        <th>Image</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
				
				 <?php 
				 
    $db = $GLOBALS['conn'];
    $query = "SELECT * FROM `about` order by id desc";
    $About_data = mysqli_query($db, $query);

if(mysqli_num_rows($About_data) > 0 ) {
    
    while ($About_rows = mysqli_fetch_assoc($About_data)) {
        $id = $About_rows['id'];
        $phone = $About_rows['phone'];
        $phone2 = $About_rows['phone2'];
        $phone3 = $About_rows['phone3'];
        $email = $About_rows['email'];
        $address = $About_rows['address'];
        $address2 = $About_rows['address2'];
        $map = $About_rows['map'];
        $title = $About_rows['title'];
        $des = $About_rows['des'];       
        $logo = $About_rows['logo'];     
        $image = $About_rows['image'];  
?>
                    <tr>
                        <td><?=$title;?></td>
                        <td><?=$phone;?></td>
                        <td><?=$phone2;?></td>
                        <td><?=$phone3;?></td>
                        <td><?=$email;?></td>
                        <td><?=strip_tags(substr($address,0,30));?>...</td>
                        <td><?=strip_tags(substr($address2,0,30));?>...</td>
                        <td><?=strip_tags(substr($map,0,30));?>...</td>
                        <td><img src="assets/images/logo/<?=$image?>" style="width:100px" ></td>
                        <td><img src="assets/images/logo/<?=$logo?>" style="width:100px" ></td>
                        <td><?=strip_tags(substr($des,0,30));?>...</td>
						<?php echo'
                        <td><a href="about_edit.php?id='.$id.'"><i class="fa fa-pencil"></i></a></td>
                    </tr>';
              }
}
	
	?>   
                    
                </tbody>
                
            </table>
            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
			</div>
	
<?php include"include/footer.php"?>
		</div>