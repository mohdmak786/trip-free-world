<?php 
include"include/config.php";
include"include/menu.php";
?>
<?php
	$q="SELECT *FROM `admin`";
	$r=mysqli_query($conn,$q);
	$col=mysqli_fetch_assoc($r);
?>
<style>
.note-editor.note-frame .note-editing-area .note-editable {
	height: 250px !important;
}
</style>
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">

			<div class="row">
			<div class="col-lg-12">
			<div class="card">
				   <div class="card-body">
				   <div class="card-title">Update Profile</div>
				   <hr>
				<form action="" method="POST">
				   <div class="form-group row">
						<label for="input-26" class="col-sm-2 col-form-label">Username (Email)</label>
						<div class="col-sm-10">
							<input type="text" name="email" value="<?php echo $col['email']?>" class="form-control form-control" placeholder="Enter Your Name">
						</div>
				  </div>
				  <div class="form-group row">
						<label for="input-26" class="col-sm-2 col-form-label">Password</label>
						<div class="col-sm-10">
							<input type="password" name="password" value="<?=$col['password']?>" class="form-control form-control">
						</div>
				  </div>
				  <div class="form-group row">
						<label for="input-26" class="col-sm-2 col-form-label">Theme Color</label>
						<div class="col-sm-4">
							<input type="color" name="color" value="<?php echo $col['color']?>" class="form-control form-control">
						</div>
				  </div>
				   <div class="form-group row">
					<label class="col-sm-2 col-form-label"></label>
					<div class="col-sm-10">
					<button name="profile_update" type="submit" class="btn btn-dark px-5"><i class="icon-lock"></i> Submit</button>
					</div>
				  </div>  
				   </form>
				 </div>
				</div>
			</div>
			</div>
			<?php

if(isset($_POST['profile_update']))
{
	$email=mysqli_real_escape_string($conn,$_POST['email']);
	$password=mysqli_real_escape_string($conn,md5($_POST['password']));
	$color=mysqli_real_escape_string($conn,$_POST['color']);
 	$sql= "UPDATE `admin` SET `email`='$email',`password`='$password',`color`='$color'";      
	 $run = mysqli_query($conn, $sql) or die(mysqli_error($conn)); 
	 if($run==true)
	{	    
		echo("<script>alert('Update Succesfully');window.location='dashboard.php';</script>");
	}          
	}

?>
<?php include"include/footer.php"?>
		</div>
		
 
		
	