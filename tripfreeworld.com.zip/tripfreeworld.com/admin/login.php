<html>
<head>
</head>
<center>
<fieldset>
<legend>Login </legend>
<form action="loginprocess.php" method="POST"><br><br>
Username:<input type="text" required="" name="email"><br><br>
Password:<input type="text" required="" name="password"><br><br>
<input type="submit" value="Login" name="login_submit">
<br>

<p style="color:red;">
<?php 
if(isset($msg))
{
	
    echo $msg;
}
?>

</p>

</form>

</fieldset>
</center>
</html>