<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © <?php echo date('Y')." " .$row_about['title'];?> | Designed & Developed By <a href="https://www.sspsoftproindia.com/"> SSP Soft Pro India</a>
        </div>
      </div>
</footer> 
<!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/sidebar-menu.js"></script>
  <script src="assets/js/app-script.js"></script>
  <!-- Chart js -->

	<script src="assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
  <script src="assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
 
 

  <script src="assets/plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
  
    <script>
     $(document).ready(function() {
      //Default data table
       $('#default-datatable').DataTable();


       var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'copy', 'excel', 'pdf', 'print', 'colvis' ]
      } );
 
     table.buttons().container()
        .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
      } );

    </script>
  <!-- Index js -->
  <script src="assets/js/index.js"></script>
<script src="assets/plugins/summernote/dist/summernote-bs4.min.js"></script>
<script src="assets/js/summernote-ext-browser.JS"></script>  
  <script>
    $('#summernoteEditor').summernote({
        height: 400,
        tabsize: 2,
        callbacks: {
          // Clear all formatting of the pasted text
          onPaste: function (e) {
            var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
            e.preventDefault();
            setTimeout( function(){
              document.execCommand( 'insertText', false, bufferText );
            }, 10 );
          }
        },
        toolbar: [
            ['style', ['style']],
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['font', ['strikethrough', 'superscript', 'subscript']],
            ['color', ['color']],
            ['insert', ['picture', 'link', 'video', 'table','filebrowser', 'hr']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['undo', ['undo', 'redo']],
            ['codeview', ['codeview']],
        ]
    });
   $('#summernoteEditor1').summernote({
      height: 400,
      tabsize: 2,
      callbacks: {
        // Clear all formatting of the pasted text
        onPaste: function (e) {
          var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
          e.preventDefault();
          setTimeout( function(){
            document.execCommand( 'insertText', false, bufferText );
          }, 10 );
        }
      },
      toolbar: [
          ['style', ['style']],
          ['style', ['bold', 'italic', 'underline', 'clear']],
          ['font', ['strikethrough', 'superscript', 'subscript']],
          ['color', ['color']],
          ['insert', ['picture', 'link', 'video', 'table','filebrowser', 'hr']],
          ['para', ['ul', 'ol', 'paragraph']],
          ['undo', ['undo', 'redo']],
          ['codeview', ['codeview']],
      ]
  });

// SELECT SUB CATEGORY THROUGH AJAX
function get_sub_cat(val) {
  $.ajax({
  type: "POST",
  url:"get_sub_category.php",
  data:'cat_id='+val,
  success: function(data){
    $("#subcategory-list").html(data);
  }
  });
}

// $(document).ready(function() {

  $('#search-btn').keyup(function() {
    // alert('work');
    var search = $(this).val();
    if(search.length>0) {
    $.ajax({
      type: "POST",
      url: "search_products.php",
      data: 'get_data=' + search,
      success: function(live_hint) {
        $('#products_data').html(live_hint);
        $('#all_products').hide();
      }
    })
  }
  else {
    $('#all_products').show();
    $('#products_data').html('');
  }

  });

  $('#select_all').click(function() {
    $("input[type=checkbox]").prop('checked', $(this).prop('checked'));
  })

  function deleteMe(pageurl,delid) {
    if(confirm('Do You want to Delete !')){
      var url = pageurl +'?id='+delid;
      window.location=url;
      return true;
    }
  }

  $('#title').keyup(function() {
    var title = $(this).val().toLowerCase().replace(/[\*\^\,\'\!\@\#\$\%\^\&\(\)\=\+\{\}\[\]]/g, '').split(' ').join('-').split('.').join('-');
    var page_url = $('#page_url');
    $(page_url).val(title);
  })
  
//   function fileValidation(){
//     var fileInput = document.getElementById('validImage');
//     var filePath = fileInput.value;
//     var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif|\.webp)$/i;
//     if(!allowedExtensions.exec(filePath)){
//         alert('Please upload valid image extensions only.');
//         fileInput.value = '';
//         return false;
//     }else{
//         //Image preview
//         if (fileInput.files && fileInput.files[0]) {
//             var reader = new FileReader();
//             reader.onload = function(e) {
//                 document.getElementById('imagePreview').innerHTML = '<img src="'+e.target.result+'"/>';
//             };
//             reader.readAsDataURL(fileInput.files[0]);
//         }
//     }
// }

// $('#filter_products').on('change', function() {
//     var value = $(this).val();
//     if(value.length>0) {
//     // alert(value);
//     $.ajax({
//       type: "POST",
//       url: "category_products.php",
//       data: 'get_data=' + value,
//       success: function(live_hint) {
//         $('#products_data').html(live_hint);
//         $('#all_products').hide();
//       }
//     })
//   }
//   else {
//     $('#all_products').show();
//     $('#products_data').html('');
//   }

//   });

  </script>
</body>
</html>