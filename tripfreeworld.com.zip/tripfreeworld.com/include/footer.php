
    <footer class="gradient-bg">
        <div class="container">
            <div class="row footer-row">
                <div class="col-md-3 col-sm-6 footer-col">
                    <img class="img" src="<?=$site_url?>admin/assets/images/logo/<?=$About_rows['logo']?>" alt="<?=$About_rows['title']?>">
                    <p>Contact Details:</p>
                    <p><strong>Head Office: </strong><?=$About_rows['address']?></p>
                    <p><strong>Branch Office: </strong><?=$About_rows['address2']?></p>
                    <p><strong>Email ID: </strong><?=$About_rows['email']?></p>
                    <p><strong>Mobile No: </strong>+91 <?=$About_rows['phone']?><br>
                    <?php
                        if($About_rows['phone2']) { echo '+91 '.$About_rows['phone2'].'</p>'; }
                    ?>
                </div>
                <div class="col-md-3 col-sm-6 footer-col">
                    <span style="color:white;font-size:22px;">Important Links</span>
                    <ul>
                        <li><a href="<?=$site_url?>">Home</a></li>
                        <li><a href="<?=$site_url?>about-us">About Us</a></li>
                        <li><a href="<?=$site_url?>destination">Destinations</a></li>
                        <li><a href="<?=$site_url?>tour">Tour Package</a></li>
                        <li><a href="<?=$site_url?>car">Our Cars</a></li>
                        <li><a href="<?=$site_url?>gallery">Gallery</a></li>
                        <li><a href="<?=$site_url?>contact-us">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 footer-col">
                   <span style="color:white;font-size:22px;">Tour Packages</span>
                    <ul>
                          <?php
                                            $query = "SELECT * FROM `tour` order by id ASC";
                                            $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                            while ($row = mysqli_fetch_array($Product_data))
                                            {
                                                $id=$row['id'];
                                                $link=$row['link'];
                                                $title=$row['title'];
                                            ?>
                        <li><a href="<?=$link?>"><?=$title?></a></li>
                         <?php
                           }
                        ?>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 footer-col">
                    <div class="footer-location">
                        <span style="color:white;font-size:22px;">Location</span>
                        <iframe src="<?=$About_rows['map']?>" frameborder="0" title="Location"></iframe>
                    </div>
                </div>
            </div>
            <div class="row footer-row" style="background: #df9403">
                <div class="col-md-6 col-sm-6 footer-col">
                    <div id="google_translate_element" class="custom"></div>
                    <script type="text/javascript">
                        function googleTranslateElementInit() {
                            new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
                        }
                    </script>
                    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                </div>
                <div class="col-md-6 col-sm-6 footer-col">
                    <div class="footer-social-media d-flex">
                        <ul class="list-unstyled d-flex">
                            <li><a class="facebook" href="https://www.facebook.com/tower2222?mibextid=ZbWKwL" aria-label="facebook" style="display:none;"><i class="fab fa-facebook-f"></i>Facebook</a></li>
                            </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <p>&copy; 2023 Trip Free World. All Rights Reserved.</p>
                    <p>Made and Designed By SSP Soft Pro India PVT LTD.</p>
                </div>
                <div class="col-lg-6 col-md-12">
                    <ul class="list-inline text-lg-right text-md-center">
                        <li class="list-inline-item"><a href="<?=$site_url?>privacy-policy">Privacy Policy</a></li>
                        <li class="list-inline-item"><a href="<?=$site_url?>term-condition">Terms and Conditions</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>


			<!-- Botom Panel  -->
			<div class="bottom-panel display-none">
				<div class="bp-col">
					<a href="<?=$site_url?>">
						<div class="bp-icon"><img class="lazyload" data-src="<?=$site_url?>img/iphome.webp" alt="icon"> </div>
						<div class="bp-text">Home</div>
					</a>
				</div>
				<div class="bp-col">
					<a href="<?=$site_url?>tour">
						<div class="bp-icon"><img class="lazyload" data-src="<?=$site_url?>img/ipcar.webp" alt="icon"></div>
						<div class="bp-text">Tour Packages</div>
					</a>
				</div>
				<div class="bp-col">
					<a href="<?=$site_url?>destination">
						<div class="bp-icon"><img class="lazyload" data-src="<?=$site_url?>img/ipoffer2.webp" alt="icon"></div>
						<div class="bp-text">Destination</div>
					</a>
				</div>
				<div class="bp-col">
					<a href="<?=$site_url?>car">
						<div class="bp-icon"><img class="lazyload" data-src="<?=$site_url?>img/ipaccount.webp" alt="icon"></div>
						<div class="bp-text">Our Cars</div>
					</a>
				</div>
			</div>
			<!-- .Bottom Panel  -->
			
			
			<div class="overlay"></div>
			
			<!-- Optional JavaScript -->
			<!-- jQuery v3.4.1 -->
			<script src="<?=$site_url?>lib/jquery/jquery-3.4.1.min.js" async></script>
			<!--  Bootstrap v4.3.1 JS -->
			<script src="<?=$site_url?>js/popper.min.js" async></script>
			<script src="<?=$site_url?>js/bootstrap.min.js" async></script>
			<!-- Magnific Popup core JS file -->
			<script src="<?=$site_url?>lib/Magnific-Popup-master/dist/jquery.magnific-popup.js" defer></script>
			<!-- Slick JS -->
			<script src="<?=$site_url?>lib/slick/slick/slick.min.js" defer></script>
			<!--  Custom JS -->
			<script src="<?=$site_url?>js/theme.js" defer></script>
            <script>
                const tabLinks = document.querySelectorAll('.tab-links .tab-link');
                const tabContent = document.querySelectorAll('.tab-content form');
                
                tabLinks.forEach((link, index) => {
                    link.addEventListener('click', () => {
                        tabLinks.forEach(link => link.classList.remove('active'));
                        link.classList.add('active');
                        tabContent.forEach(content => content.classList.remove('active'));
                        tabContent[index].classList.add('active');
                    });
                });
            </script>
			
<script>
    // Get the modal
    /*var modal = document.getElementById("myModal");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];


    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // When the page loaded, open the modal
    window.onload = function(event) {
        modal.style.display = "block";
    }*/
</script>   
