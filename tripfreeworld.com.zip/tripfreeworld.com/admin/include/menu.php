<?php
session_start();
?>
<?php 
include 'config.php';
if(!isset($_SESSION["login"])){
    // header('../index.php');
    echo "<script>alert('Session Login Failed');window.location='index.php';</script>";
}
	
	$select_about = "SELECT * FROM `about`";
	$query_about = mysqli_query($conn,$select_about);
	$row_about = mysqli_fetch_array($query_about);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?=$row_about['title'];?></title>
  <!--favicon-->
  <link rel="icon" href="assets/images/logo/<?=$row_about['logo'];?>" type="image/x-icon">
  <!-- Bootstrap core CSS-->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- Sidebar CSS-->
  <link href="assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="assets/css/app-style.css" rel="stylesheet"/>
   <link rel="stylesheet" href="assets/plugins/summernote/dist/summernote-bs4.css"/>
  
  <link href="assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
  <link href="assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  
  <style>
	.des p {width:50px; white-space:normal; }
	.note-editor.note-frame .note-editing-area .note-editable {color:#333;}
  </style>
  
</head>

<body class="bg-theme bg-theme2">
<!-- Start wrapper-->
<div id="wrapper">
 
  <!--Start sidebar-wrapper-->
   <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
      <a href="dashboard.php">
       <img style="background: white; width: 120px; padding:5px;" src="assets/images/logo/<?=$row_about['logo'];?>" class="logo-icon" alt="logo icon">
       
     </a>
	</div>
   <div class="user-details">
    <div class="media align-items-center user-pointer collapsed" data-toggle="collapse" data-target="#user-dropdown">
      
       <div class="media-body">
	   
       <h6 class="side-user-name"><?=$row_about['title'];?></h6>
      </div>
       </div>
    <!--<i class="fa fa-angle-left pull-right">-->
      </div>
   <ul class="sidebar-menu do-nicescrol">
   		<li class="sidebar-header">MAIN NAVIGATION</li> 
		<?php
	      	$select2 = "SELECT * FROM enquiry";
	        $query2 = mysqli_query($conn,$select2);
	        $count = mysqli_num_rows($query2);
	    ?>
		<li>
    		<a href="mail.php" class="waves-effect">
      		<i class="fa fa-tachometer"></i> <span>Customer Query <span class="badge badge-danger"><?=$count;?></span></span></span></a>
	    </li>
   		<?php
	      	$select2 = "SELECT * FROM banner";
	        $query2 = mysqli_query($conn,$select2);
	        $count = mysqli_num_rows($query2);
	    ?>
		<li>
    		<a href="slider_display.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>Sliders Manage <span class="badge badge-danger"><?=$count;?></span></span></a>
        </li>
        <?php
	      	// $select2 = "SELECT * FROM category";
	       //  $query2 = mysqli_query($conn,$select2);
	       //  $count = mysqli_num_rows($query2);
	    ?>		  	       
        <!-- <li><a href="category_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>Category Manage <span class="badge badge-danger"><?=$count;?></span></span></a>
		</li>   -->
        <?php
	      	/*$select2 = "SELECT * FROM services";
	        $query2 = mysqli_query($conn,$select2);
	        $count = mysqli_num_rows($query2);*/
	    ?>		  	       
        <!--<li><a href="services_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>Services <span class="badge badge-danger"><?=$count;?></span></span></a>
		</li>--> 
        <?php
	      	/*$select2 = "SELECT * FROM `hotel`";
	        $query2 = mysqli_query($conn,$select2);
	        $count = mysqli_num_rows($query2);*/
	    ?>		  	       
        <!--<li><a href="hotel_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>Hotels <span class="badge badge-danger"><?=$count;?></span></span></a>
		</li>--> 
        <?php
	      	$select2 = "SELECT * FROM `tour`";
	        $query2 = mysqli_query($conn,$select2);
	        $count = mysqli_num_rows($query2);
	    ?>		  	       
        <li><a href="tour_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>Tour Package <span class="badge badge-danger"><?=$count;?></span></span></a>
		</li>  
        <?php
	      	$select2 = "SELECT * FROM `car`";
	        $query2 = mysqli_query($conn,$select2);
	        $count = mysqli_num_rows($query2);
	    ?>		  	       
        <li><a href="car_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>All Cars <span class="badge badge-danger"><?=$count;?></span></span></a>
		</li>  
        <?php
	      	/*$select2 = "SELECT * FROM `team`";
	        $query2 = mysqli_query($conn,$select2);
	        $count = mysqli_num_rows($query2);*/
	    ?>		  	       
        <!--<li><a href="team_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>Team <span class="badge badge-danger"><?=$count;?></span></span></a>
		</li>--> 
        <?php
	      	$select2 = "SELECT * FROM destination";
	        $query2 = mysqli_query($conn,$select2);
	        $count = mysqli_num_rows($query2);
	    ?>		  	       
        <li><a href="destination_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>Destination <span class="badge badge-danger"><?=$count;?></span></span></a>
		</li> 
        <?php
	      	// $select2 = "SELECT * FROM partners";
	       //  $query2 = mysqli_query($conn,$select2);
	       //  $count = mysqli_num_rows($query2);
	    ?>		  	       
        <!-- <li><a href="partners_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>Partners <span class="badge badge-danger"><?=$count;?></span></span></a>
		</li>   -->
        <?php
	      	$select2 = "SELECT * FROM review";
	        $query2 = mysqli_query($conn,$select2);
	        $count = mysqli_num_rows($query2);
	    ?>		  	       
        <li><a href="review_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>Reviews <span class="badge badge-danger"><?=$count;?></span></span></a>
		</li>  
        <?php
	      	$select2 = "SELECT * FROM gallery";
	        $query2 = mysqli_query($conn,$select2);
	        $count = mysqli_num_rows($query2);
	    ?>		  	       
        <li><a href="gallery_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>Gallery <span class="badge badge-danger"><?=$count;?></span></span></a>
		</li> 
        <?php
	      	// $select2 = "SELECT * FROM blogs";
	       //  $query2 = mysqli_query($conn,$select2);
	       //  $count = mysqli_num_rows($query2);
	    ?>		  	       
        <!-- <li><a href="blog_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>Blogs <span class="badge badge-danger"><?=$count;?></span></span></a>
		</li>  	 -->
		<li>
        	<a href="about_table.php" class="waves-effect">
          	<i class="fa fa-tachometer"></i> <span>About Us</span></a>
		</li>
		<li>
    		<a href="change_profile.php" class="waves-effect">
      		<i class="fa fa-tachometer"></i> <span>Change Profile </span></a>
	    </li>
		<li>
    		<a href="logout.php" class="waves-effect">
      		<i class="fa fa-tachometer"></i> <span>Logout</span></a>
	    </li>
      
	    </ul>
   
   </div>
   
			<header class="topbar-nav">
				 <nav class="navbar navbar-expand fixed-top">
				  <ul class="navbar-nav mr-auto align-items-center">
					<li class="nav-item">
					  <a class="nav-link toggle-menu" href="javascript:void();">
					   <i class="fa fa-bars"></i>
					 </a>
					</li>
				   
				  </ul>
					 
				  <ul class="navbar-nav align-items-center right-nav-link">
					
					<li class="nav-item">
					  <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown" href="#">
						<span class="user-profile"><i class="fa fa-user" aria-hidden="true"></i>
				</span>
					  </a>

					 <?php
						$select_admin = "SELECT * FROM admin";
						$query_admin = mysqli_query($conn,$select_admin);
						$row_admin = mysqli_fetch_array($query_admin);
					?>
					  <ul class="dropdown-menu dropdown-menu-right">
					   <li class="dropdown-item user-details">
						<a href="javaScript:void();">
						   <div class="media">
							<div class="media-body">
							<h6 class="mt-2 user-title"><?=$row_about['title'];?></h6>
							<p class="user-subtitle"> <?=$row_admin['email'];?></p>
							</div>
						   </div>
						  </a>
						</li>
						<li class="dropdown-divider"></li>
						
						<li class="dropdown-divider"></li>
						<li class="dropdown-item"><i class="icon-power mr-2"></i><a class="btn btn-success" href="logout.php"> Logout</a></li>

					  </ul>
					</li>
				  </ul>
				</nav>
			</header>
	
	</div>   
  <!-- Bootstrap core JavaScript--> 
 
</body>


</html>
