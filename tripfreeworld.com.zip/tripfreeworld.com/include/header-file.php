		<?php include $site_url."admin/include/config.php" ?>
		<?php
		    $site_url= "https://tripfreeworld.com/";
		?>
		<link rel="icon" href="<?=$site_url?>admin/assets/images/logo/<?=$About_rows['logo']?>" type="image/x-icon">
		<!-- Bootstrap v4.3.1 CSS -->
		<link rel="stylesheet" href="<?=$site_url?>lib/bootstrap/css/bootstrap.min.css">
		<!-- Custom CSS -->
		<link rel="stylesheet" href="<?=$site_url?>css/normalize.css">
		<link rel="stylesheet" href="<?=$site_url?>css/theme.css">
		<!-- Slick CSS -->
		<link rel="stylesheet" type="text/css" href="<?=$site_url?>lib/slick/slick/slick.css">
		<link rel="stylesheet" type="text/css" href="<?=$site_url?>lib/slick/slick/slick-theme.css">
		<!-- Magnific Popup core CSS file -->
		<link rel="stylesheet" href="<?=$site_url?>lib/Magnific-Popup-master/dist/magnific-popup.css">
		<!-- Font Awesome Free 5.10.2 CSS JS -->
		<link href="<?=$site_url?>lib/fontawesome-free-5.10.2-web/css/all.css" rel="stylesheet">
		<script defer src="<?=$site_url?>lib/fontawesome-free-5.10.2-web/js/brands.js"></script>
		<script defer src="<?=$site_url?>lib/fontawesome-free-5.10.2-web/js/solid.js"></script>
		<script defer src="<?=$site_url?>lib/fontawesome-free-5.10.2-web/js/fontawesome.js"></script>
	
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WXKS4GW');</script>
<!-- End Google Tag Manager -->