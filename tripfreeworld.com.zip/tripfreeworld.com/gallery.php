<!doctype html>
<html lang="en">
	
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<title>Gallery - Trip Free World in Jammu and Kashmir</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
		<meta name="mobile-web-app-capable" content="yes"/>
		<meta name="apple-mobile-web-app-capable" content="yes"/>
		<meta name="apple-touch-fullscreen" content="yes"/>
		<meta name="HandheldFriendly" content="True">
		
		 <!--General Meta Start-->
    	<meta name="description" content="The Photo Gallery page is intended to be used for creating albums and image galleries for display on our site."/>
        <meta name="keywords" content= "Trip Free world images,Tour gallery"/>
	    <meta name="author" content="Tour and Travels"/>
	    <meta name="robots" content="index, follow" />
	    <meta name="distribution" content="global" />
	    <meta name="coverage" content="india" />
	    <meta name="object" content="document"/>
	    <meta name="audience" content="All" />
	    <meta name="revisit-after" content="1 day"/>
	    <meta name="language" content="en"/>
	    <meta name="rating" content="general"/>
     	<meta name="copyright" content="Copyright Trip Free World 2023"/>
	     <!--General Meta End-->
	     
	     <!--OG Meta Start-->
	     <meta property="og:type" content="website" />
    	<meta property="og:title" content="Gallery - Trip Free World in Jammu and Kashmir" />
    	<meta property="og:url" content="https://www.tripfreeworld.com/gallery" />
    	<meta property="og:description" content="The Photo Gallery page is intended to be used for creating albums and image galleries for display on our site." />
    	<meta property="og:image" content="https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp" />
    	<!--OG Meta end-->
	
		
		 
		  <!--canonical tag-->
            <link rel="canonical" href="https://www.tripfreeworld.com/gallery"/>
		     <!---Schema marhup start--->
             <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Trip Free World",
  "image": "https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp",
  "url": "https://www.tripfreeworld.com/",
  "telephone": "+91 9906830446",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Naidkhai, Amberhrah Sopore, Parraypora",
    "addressLocality": "Srinagar",
    "postalCode": "193501",
    "addressCountry": "IN"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 34.2867629,
    "longitude": 74.4624013
  },
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday"
    ],
    "opens": "00:00",
    "closes": "23:59"
  } 
}
</script>
<?php include "include/header-file.php"?>
        
	</head>
	<body class="default">

        <?php include "include/header.php"?>

      <!-- Content  -->
      <div id="content">
        <div class="content-wrap page-destination-list">
          <div class="subsite-banner">
            <img src="img/subsite-banner-3.jpg" alt="Banner image">
          </div>
          <div class="container subsite">
            <div class="row">
              <div class="col-md-12">
                  <h1 class="subsite-heading">
                  Trip Free World Tour & Travel
                </h1>
                <h2 class="subsite-heading">
                  Gallery
                </h2>
              </div>
            </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="gallery-section">
                                    <div class="row-gallery">
                                        <div class="wrap-gallery">
                                            <?php
                                            $query = "SELECT * FROM `gallery` order by id ASC";
                                            $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                            while ($row = mysqli_fetch_array($Product_data))
                                                {
                                                $id=$row['id'];
                                                $title=$row['title'];
                                                $img=$row['image'];
                                            ?>
                                            <div class="col-md-4 col-sm-6 col-12 gall-col gallery-img-box" data-category-image="hotel,city">
                                                <a class="gallery-list" href="<?=$site_url?>admin/assets/images/gallery/<?=$img?>" target="_blank" rel="noopener"><img alt="<?=$title?>" src="<?=$site_url?>admin/assets/images/gallery/<?=$img?>"></a>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
          </div>
          
        </div>
      </div>
      <!-- .Content  -->
      
			<?php include "include/footer.php"?>
    </body>
  
  
</html>