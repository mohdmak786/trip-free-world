<!doctype html>
<html lang="en">
	
<head>
		  <!--General Meta Start-->
		<meta charset="utf-8">
		<title>Best Tourist Destinations In Kashmir - Trip Free World</title>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-touch-fullscreen" content="yes">
		<meta name="HandheldFriendly" content="True">
		 <!--General Meta Start-->
    	<meta name="description" content="Srinagar, Mansar Lake, and Gulmarg, are the best tourist attractions in Kashmir. Book your trip now to experience the beauty of these breathtaking locations."/>
        <meta name="keywords" content="Best destination in srinagar, honeymoon destinations in kashmir, best tourist destinations in kashmir."/>
	    <meta name="author" content="Tour and Travels"/>
	    <meta name="robots" content="index, follow" />
	    <meta name="distribution" content="global" />
	    <meta name="coverage" content="india" />
	    <meta name="object" content="document"/>
	    <meta name="audience" content="All" />
	    <meta name="revisit-after" content="1 day"/>
	    <meta name="language" content="en"/>
	    <meta name="rating" content="general"/>
     	<meta name="copyright" content="Copyright Trip Free World 2023"/>
	     <!--General Meta End-->
	     
	     
	    <!--OG Meta Start-->
	    <meta property="og:type" content="website" />
    	<meta property="og:title" content="Best Tourist Destinations In Kashmir" />
    	<meta property="og:url" content="https://www.tripfreeworld.com/destination" />
    	<meta property="og:description" content="Srinagar, Mansar Lake, and Gulmarg, are the best tourist attractions in Kashmir. Book your trip now to experience the beauty of these breathtaking locations." />
    	<meta property="og:image" content="https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp" />
    	<!--OG Meta end--> 
		
		   <!--canonical tag-->
          <link rel="canonical" href="https://www.tripfreeworld.com/destination"/>
          <!---Schema marhup start--->
             <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Trip Free World",
  "image": "https://www.tripfreeworld.com/admin/assets/images/logo/logo.webp",
  "url": "https://www.tripfreeworld.com/",
  "telephone": "+91 9906830446",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Naidkhai, Amberhrah Sopore, Parraypora",
    "addressLocality": "Srinagar",
    "postalCode": "193501",
    "addressCountry": "IN"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 34.2867629,
    "longitude": 74.4624013
  },
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday"
    ],
    "opens": "00:00",
    "closes": "23:59"
  } 
}
</script>
		
		
        <?php include "include/header-file.php"?>
        
	</head>
	<body class="default">

        <?php include "include/header.php"?>

      <!-- Content  -->
      <div id="content">
        <div class="container content-wrap page-destination-list">
          <div class="subsite-banner">
            <img src="img/subsite-banner-31.jpg" alt="banner image">
          </div>
          <div class="container subsite subsite-with-banner">
            <div class="row">
              <div class="col-md-12">
                <div class="subsite-heading">
                  <h1 style="font-size:20px;font-weight:600;">Best Tourist Destinations In Kashmir</h1>
                 </div>
                  <p>Best Destinations</p>
              </div>
            </div>
            	<!-- section 3 -->
					<div class="container heading-section">
						<div class="sa-title popcat"><h2 style="font-size:18px;font-weight:600;"></h2>
						</div>
					<p>tourist</p>
						<div class="clear"></div>
					</div>
					<div class="container section-home container vacation-destination">
						<div class="row vs-carousel">
							
							<?php
                                $query = "SELECT * FROM `destination` order by id ASC";
                                $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                while ($row = mysqli_fetch_array($Product_data))
                                {
                                    $id=$row['id'];
                                    $title=$row['title'];
                                    $img=$row['image'];
                                    $location=$row['location'];
                                    $time=$row['time'];
                                    $price=$row['price'];
                            ?>
							<!-- item -->
							<div class="col-md-4 col-12 item pb-3">
								<div class="vs-box">
									<div class="vsb-top">
										<div class="vsb-rating">
											5.0 <i class="fas fa-star"></i>
										</div>
										<div class="vsbt-img">
											<img src="<?=$site_url?>admin/assets/images/destination/<?=$img?>" alt="<?=$title?>">
										</div>
									</div>
									<div class="vsb-middle">
										<div class="vsbm-left">
											<h3 style="font-size:16px;font-weight:600;"><?=$title?>, <?=$location?></h3>
										</div>
										<div class="vsbm-right">
											₹<?=$price?>
										</div>
									</div>
								</div>
							</div>
							<!-- .item -->
							<?php } ?>
						</div>
					</div>
					<!-- .section 3 -->
            
            
          </div>
          
        </div>
      </div>
      <!-- .Content  -->
      
			<?php include "include/footer.php"?>
    </body>
  
  
</html>