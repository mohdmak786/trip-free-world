<?php 
include"include/config.php";
include"include/menu.php";

error_reporting(0);

if(isset($_GET['id'])) {
  $get_id = mysqli_real_escape_string($conn,$_GET['id']);
  $q="SELECT * FROM blogs WHERE id='$get_id'";
  $r=mysqli_query($conn,$q);
  $col=mysqli_fetch_array($r);
    $title = $col['title']; 
    $old_img = $col['image'];
    $url = $col['url'];
    $meta = $col['meta'];
    $des = $col['des'];
    $status = $col['status'];
?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
		<div class="row">
		<div class="col-lg-12">
		<div class="card">
			   <div class="card-body">
			   <div class="card-header">Update Blog</div>
			   <hr>
			<form action="" method="POST" enctype="multipart/form-data">
			    <div class="form-group row">
				<label for="input-26" class="col-sm-2 col-form-label">Blog Name</label>
				<div class="col-sm-10">
				 	<input type="text" name="title" class="form-control" id="title" value="<?=$title;?>">
				</div>
			  </div>

			    <div class="form-group row">
				<label for="input-26" class="col-sm-2 col-form-label">Page URL</label>
				<div class="col-sm-10">
				 	<input type="text" name="url" class="form-control" value="<?=$url;?>" id="page_url">
				</div>
			  </div>
			  
			<div class="form-group row">
              <label for="input-8" class="col-sm-2 col-form-label">Image</label>
              <div class="col-sm-4">
                <input type="file" class="form-control" name="image">
               </div>
              <div class="col-sm-4">
                <img src="assets/images/<?=$old_img;?>" style="height:50px;">
              </div>
            </div>

            <div class="form-group row">
				<label for="input-29" class="col-sm-2 col-form-label">Description</label>
				<div class="col-sm-10">
				<textarea id="summernoteEditor" name="des"><?php echo $des; ?></textarea>
				</div>
			  </div>
            <div class="form-group row">
				<label for="input-29" class="col-sm-2 col-form-label">Meta Keywords</label>
				<div class="col-sm-10">
				<textarea class="form-control" rows="5" name="meta" placeholder="Enter Meta Tags,Keywords"><?=$meta;?></textarea>
				</div>
			 </div>

			  <div class="form-group row">
	            <label for="input-26" class="col-sm-2 col-form-label">Status</label>
	            <div class="col-sm-5">
	              <select name="status" class="form-control" required="">
	                <?php 
	                  if($status=="Active") {
	                    echo "<option selected>Active</option>
	                        <option>Deactive</option>";
	                  }
	                  else {
	                    echo "<option>Active</option>
	                        <option selected>Deactive</option>";
	                  }
	                ?>
	              </select>
	            </div>
	          </div>
            
			   <div class="form-group row">
				<label class="col-sm-2 col-form-label"></label>
				<div class="col-sm-10">
				<button name="blog_update" type="submit" class="btn btn-dark btn-round px-5"><i class="icon-lock"></i>Submit</button>
				</div>
			  </div>
			   </form>
			 </div>
			</div>
		</div>
		</div>
	</div>
</div>

<?php 


if(isset($_POST['blog_update']))
{
    $title=mysqli_real_escape_string($conn,$_POST['title']);
    $url=mysqli_real_escape_string($conn,$_POST['url']);
    $des=mysqli_real_escape_string($conn,$_POST['des']);
    $meta=mysqli_real_escape_string($conn,$_POST['meta']);
    $status=mysqli_real_escape_string($conn,$_POST['status']);
	 
	$image_name = $_FILES['image']['name'];
	$final_img = time().$image_name;
	$image_tmp = $_FILES['image']['tmp_name'];
	$logo_path = "assets/images/".$final_img;
	$old_img = $col['image'];

    $extensions_arr = array("jpg","jpeg","png","gif","webp");
    $file_extension = pathinfo($image_name, PATHINFO_EXTENSION);
  
  if($image_name) {
    if(in_array($file_extension,$extensions_arr)) {
      unlink('assets/images/'.$old_img);
      move_uploaded_file($image_tmp, $logo_path);
    }
    else {
      echo "<script>
          alert('Image Should be Valid Extension');
          window.location='insert_blogs.php?id=".$get_id."';
        </script>";
      exit;
    } 
  }
  else {
    $final_img=$old_img;
  }

  $sql="UPDATE `blogs` SET `title`='$title',`url`='$url',`image`='$final_img',`des`='$des',`meta`='$meta',`status`='$status' WHERE id='$get_id'";
  $query=mysqli_query($conn,$sql) or die(mysqli_error($conn));  
  if($query)
  {
	move_uploaded_file($image_tmp,$logo_path);
	echo "<script>alert('update succesfully');window.location='blog_table.php';</script>";
  }
}

}  // IF ISSET END
else {

?>	
  <div class="content-wrapper">
    <div class="container-fluid">

			<div class="row">
			<div class="col-lg-12">
			<div class="card">
				   <div class="card-header">
				   		<a href="blog_table.php" class="btn btn-success" style="float:right;">All Blogs</a>
				   		Add Blogs
				   </div>
				   <div class="card-body">
				   <hr>
				<form action="" method="POST" enctype="multipart/form-data">
				    <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Blog Name</label>
					<div class="col-sm-10">
					 	<input type="text" name="title" class="form-control" id="title">
					</div>
				  </div>
				    <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Page Url</label>
					<div class="col-sm-10">
					 	<input type="text" name="url" class="form-control" id="page_url" required="">
					</div>
				  </div>
				  
				<div class="form-group row">
                  <label for="input-8" class="col-sm-2 col-form-label">Image (<abbr title="Image Format Should be jpg,jpeg,png,gif">Format</abbr>)</label>
                  <div class="col-sm-4">
                    <input type="file" class="form-control" name="image" required>
                  </div>
                </div>

                <div class="form-group row">
					<label for="input-29" class="col-sm-2 col-form-label">Description</label>
					<div class="col-sm-10">
					<textarea id="summernoteEditor" name="des"></textarea>
					</div>
				 </div>
                <div class="form-group row">
					<label for="input-29" class="col-sm-2 col-form-label">Meta Keywords</label>
					<div class="col-sm-10">
					<textarea class="form-control" rows="5" name="meta" placeholder="Enter Meta Tags,Keywords"><title></title></textarea>
					</div>
				 </div>

				 <div class="form-group row">
					<label for="input-26" class="col-sm-2 col-form-label">Status</label>
		            <div class="col-sm-5">
		              <select name="status" class="form-control" required="">
		              		<!-- <option selected="" disabled="">--Select Status</option> -->
		              		<option>Active</option>
		                    <option>Deactive</option>
		              </select>
		            </div>
		          </div>
                				  
				 
				<div class="form-group row">
					<label class="col-sm-2 col-form-label"></label>
					<div class="col-sm-10">
					<button name="blog_submit" type="submit" class="btn btn-dark btn-round px-5"><i class="icon-lock"></i>Submit</button>
					</div>
				</div>
				   </form>
				 </div>
				</div>
			</div>
			</div>
			<?php

if(isset($_POST['blog_submit']))
{
    $title=mysqli_real_escape_string($conn,$_POST['title']);
    $url=mysqli_real_escape_string($conn,$_POST['url']);
    $des=mysqli_real_escape_string($conn,$_POST['des']);
    $meta=mysqli_real_escape_string($conn,$_POST['meta']);
    $status=mysqli_real_escape_string($conn,$_POST['status']);

    $date = date('d-M-Y');

	$image_name = $_FILES['image']['name'];
	$final_img = time().$image_name;
	$image_tmp = $_FILES['image']['tmp_name'];
	$logo_path = "assets/images/".$final_img;

	$extensions_arr = array("jpg","jpeg","png","gif","webp");
	$file_extension = pathinfo($image_name, PATHINFO_EXTENSION);	

	if(in_array($file_extension,$extensions_arr)) {
		if ($image_name!="") {
			$sql="INSERT INTO `blogs`(`title`,`url`,`meta`,`image`,`des`,`status`,`date`) VALUES ('$title','$url','$meta','$final_img','$des','$status','$date')";
			$query=mysqli_query($conn,$sql) or die(mysqli_error($conn));
			if($query)
			{
				move_uploaded_file($image_tmp,$logo_path);
				 echo("<script>alert('Insert succesfully');window.location='blog_table.php';</script>");
			}
		}
  	}
	else {
	   echo("<script>alert('Image Should be Valid Extension');</script>");
	}		
}

}  // ELSE CONDITION END

?>		
<?php include"include/footer.php"?>
		</div>
		
 
		
	