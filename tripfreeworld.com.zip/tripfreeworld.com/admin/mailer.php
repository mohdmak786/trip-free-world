<?php
include('include/config.php');

$select_about = "SELECT * FROM about";
$query_about = mysqli_query($conn,$select_about);
$row_about = mysqli_fetch_array($query_about);

$sender_email = $row_about['email'];
// $email = 'designer4uh@gmail.com';

if(isset($_POST['mail_send'])) {
    require 'smtp/PHPMailerAutoload.php';

    $mail = new PHPMailer;

    // $mail->SMTPDebug = 4;                               // Enable verbose debug output

    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = "designer4uh@gmail.com";                 // SMTP username
    $mail->Password = "Google@123#";                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    $mail->setFrom("designer4uh@gmail.com", $row_about['title']);
    $mail->addAddress($_POST['email']);     // Add a recipient

    $mail->addReplyTo("designer4uh@gmail.com");
    // print_r($_FILES['file']); exit;
    // for ($i=0; $i < count($_FILES['file']['tmp_name']) ; $i++) { 
    $mail->addAttachment($_FILES['file']['tmp_name'], $_FILES['file']['name']);
    // $mail->addAttachment($_FILES['file']['tmp_name'][$i], $_FILES['file']['name'][$i]);    // Optional name
    // }
    $mail->isHTML(true);                                  // Set email format to HTML

    $mail->Subject = $_POST['subject'];
    $mail->Body    = '<h4>Invoice Bill</h4>' . $_POST['message'];
    // $mail->AltBody = $_POST['message'];

    if(!$mail->send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    } else {
        echo "<script>alert('Mail has been sent');
        window.location='webmail.php';
        </script>";
    }
}

?>  