<?php 
include"include/config.php";
include"include/menu.php";

error_reporting(0);
if(isset($_GET['id'])) {
  $get_id = $_GET['id'];
  $q="SELECT * FROM `sub_category` WHERE `id`='$get_id'";
  $r=mysqli_query($conn,$q);
  $col=mysqli_fetch_assoc($r);
    $fetch_img = $col['image'];    

  $query = "DELETE FROM `sub_category` WHERE `id`= '$get_id'";
  $delte_query = mysqli_query($conn, $query);
  if ($delte_query) {
    unlink("assets/images/category/".$fetch_img);
    echo "<script>window.location='sub_category_table.php'</script>";
  }
}
?>
<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">


      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
                <a href="insert_sub_category.php" class="btn btn-success" style="float:right;">Insert Sub Category</a>
              <i class="fa fa-table"></i> Sub Categories
            </div>
            <div class="card-body">
              <div class="table-responsive">
              <table id="" class="table table-bordered">
                <thead>
                    <tr>
                         <th>S.No.</th>
                         <th>Name</th>
                         <th>Image</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
        
         <?php 
         $number=1;
    $query = "SELECT * FROM `sub_category` order by id DESC";
    $Product_data = mysqli_query($conn, $query) or die(mysqli_error($conn));
        while ($row = mysqli_fetch_array($Product_data))
      {
        $id=$row['id'];
        $title=$row['title'];
        $cat_id=$row['cat_id'];
        $image=$row['image'];
        $status=$row['status'];

        $select_cat = "SELECT * FROM category WHERE id='$cat_id'";
        $query_cat = mysqli_query($conn,$select_cat);
        $fetch_cat = mysqli_fetch_array($query_cat);
?>
                    <tr>                        
                         <td ><div><?php echo $number; ?></div></td>
                         <td ><div><?php echo $title; ?></div></td>
                         <td ><div><img src="assets/images/category/<?=$image; ?>" style="height:50px;"></div></td>
                         <td ><div><?php echo $fetch_cat['title']; ?></div></td>
                         <td>
                        <?php
                          if($status=="Active") {
                            echo "<span class='badge badge-success'>".$status."</span>";
                          }
                          else {
                            echo "<span class='badge badge-danger'>".$status."</span>";
                          }
                        ?>
                      </td> 
            <?php echo'
                        <td><a href="insert_sub_category.php?id='.$id.'"><i class="fa fa-pencil"></i></a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
            <a href="sub_category_table.php?id='.$id.'"><i class="fa fa-trash-o"></a></td>
                    </tr>';
    $number++;          
}
  
  ?>   
                    
                </tbody>
            </table>
            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
      </div>
  
<?php include"include/footer.php"?>
    </div>